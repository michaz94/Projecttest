# Inférence sur le projet (Edenia, nom provisoire) : cohérence, monde, histoire

*Fichier de travail du 7 octobre 2026. Les inférences sont de l'IA ; les réactions de l'utilisateur sont marquées **(U)**. Rien ici n'est décidé ni reporté dans le YAML, qui reste la source unique des statuts. Niveau de preuve : fiches du YAML et messages de l'utilisateur ; certaines œuvres ne sont connues de lui que partiellement ; le détail du folklore n'a pas été revérifié. Mis en accord le 8 oct. 2026 avec `fiches_references_projet_epure.yaml` : ce YAML ne contient plus de système de pouvoirs ni de liste de points « non tranchés » ; ce qui n'y figure pas n'est ni décidé ni envisagé.*

## 0. Ce qui n'émerge pas

Aucune histoire. Protagonistes, intrigue, cosmologie et « passage entre régions du même monde » ne figurent pas dans le YAML (ni décidés, ni envisagés). Ce qui se dégage est un **cadre de monde et un ton**, pas un récit.

## 1. Les cinq inférences

Chacune suit : abduction (meilleure explication de ce qui est dit), hypothèse (avec un test), proposition.

### 1.1 Un monde-mosaïque de régions
- **Abduction :** presque tout ce qui est retenu est attaché à un lieu : zone western et zone industrielle ; héritages « répartis par régions » ; créatures de la carte de France à ancrage régional (Ankou et Petit Homme rouge bretons, Mélusine du Poitou, Tarasque de Provence, Gayant du Nord, Barbegazi des Alpes, d'après les connaissances de l'IA, à vérifier) ; personnages d'inspiration asiatique ; images de pierres levées et de forêts.
- **Hypothèse :** la géographie serait une mosaïque où chaque région a un héritage dominant ; les régions de folklore pourraient reprendre des régions de France, élargies par d'autres héritages (gréco-égyptien, asiatique). *Test :* chaque région a-t-elle un héritage dominant, ou tout est-il mélangé partout ?
- **Proposition :** un tableau « région → héritage → créatures → paysage → tenues », rempli seulement avec ce que l'utilisateur a dit ; il montrerait ce qui manque (passage entre régions du même monde, région alpine pour les Barbegazi).
- **Réaction (U) :** « Un monde de régions de conte », oui.

### 1.2 Un monde de hiérarchies *(version corrigée : sans « conditions »)*
- **Abduction :** le Dictionnaire infernal est visé pour ses hiérarchies, le Dictionnaire féodal pour ses titres et fiefs, et plusieurs gimmicks sont institutionnels (licence de Hunter, guilde de Red Hood, Shinigami).
- **Hypothèse :** l'ordre social, l'ordre infernal et l'ordre des institutions suivraient la même logique de rangs. *Test :* les institutions ont-elles des grades ?
- **Proposition :** décider si la hiérarchie des démons envisagés (Gremory/Gomory, Furfur, Marbas, Stolas) double celle des institutions humaines, ou l'ignore.
- **Réaction (U) :** « Tenu par un ordre de hiérarchie », exact, « je pense ».
- **Correction :** la première version associait aussi les « conditions » des pouvoirs ; retiré (voir §3).

### 1.3 Un au-delà probablement structuré en fond
- **Abduction :** beaucoup d'éléments d'intérêt ou envisagés touchent l'au-delà : Limbo catholique, Limbo de Magik, enfer de *Dorohedoro*, *Inferno*, *Purgatorio*, purgatoire classique, Cour infernale, Chasse sauvage, Ankou, démons ; et les œuvres *Bleach*, *Yu Yu Hakusho*, *Jujutsu Kaisen*.
- **Hypothèse :** la cosmologie (non tranchée) tournerait autour d'un au-delà plus ou moins structuré. *Test :* une œuvre sans au-delà (*One Piece*, *Naruto*) suffit-elle ?
- **Proposition :** trois options : (a) au-delà hiérarchisé (Dante, Dictionnaire infernal) ; (b) esprits ou malédictions (*Jujutsu Kaisen*) ; (c) pas d'au-delà central, seulement une ambiance (comme l'occultisme).
- **Réaction (U) :** il hésite encore ; « présent en fond », potentiellement.

### 1.4 Un temps flou plutôt qu'une date
- **Abduction :** « un seul monde, une seule époque » ; plafond théorique 1950 hors technologie magique ; zone western et zone industrielle ; tenues « archaïques mais pas trop » ; inspirations (Radiant, Runeterra, *One Piece*, *Naruto*) aux époques mélangées ; limite vestimentaire qui dépend des fonctions et des statuts (U, 7 oct.).
- **Hypothèse :** « l'époque » est un temps de conte avec industrialisation partielle, où l'habit suit la fonction. *Test :* deux personnages de statuts différents dans la même ville portent-ils des tenues de périodes différentes ?
- **Proposition :** décrire le temps par régimes (ordinaire, magique, industriel) plutôt que par date ; lier les tenues à la fonction.
- **Réaction (U) :** pas discuté dans ce tour.

### 1.5 Un ton de conte relu, sérieux et pragmatique
- **Abduction :** ton visé plus proche de Red Hood et de *Hunter × Hunter* que de *Fullmetal Alchemist* ; *Shrek* et Red Hood associés à la relecture de contes ; trois personnages aux inspirations de personnages d'élan, de ruse et de savoir ; le nom de famille « Pandragon » de Brann a été retiré le 9 oct. (nouveau nom non décidé), donc cette piste est abandonnée ; deux modèles d'institution : l'académie (tenue envisagée) et la guilde ou association (HxH, Red Hood).
- **Proposition :** choisir quel modèle organise le monde : académie, guilde, ou académie puis guilde.
- **Réaction (U) :** âge « peut-être entre 15 et 19 ans ». Il avait dit « personnage qui passe des épreuves : oui » ; **il l'a retiré le 9 oct. 2026**.

## 2. Phrase de synthèse et réactions

**Version initiale (IA) :** « un monde de régions de conte, tenu par un ordre de hiérarchies et de conditions, où des jeunes formés par épreuves traversent des régions marquées par des héritages différents, au contact d'un au-delà probablement structuré. »

| Élément de la phrase | Réaction (U) |
|---|---|
| régions de conte | oui |
| tenu par un ordre de hiérarchies | exact, « je pense » |
| … et de conditions | d'abord « sans doute pas bon », précisé ensuite : trop contraignant comme règle générale, mais des conditions seront sans doute présentes naturellement ; degré de contrainte non dit |
| régions marquées par des héritages différents | oui, sans doute |
| personnages qui passent des épreuves | oui, **puis retiré le 9 oct. 2026** |
| jeunes | peut-être, entre 15 et 19 ans |
| au contact d'un au-delà probablement structuré | hésite encore ; présent en fond, potentiellement |
| ensemble « où des jeunes formés par épreuves traversent des régions… au contact d'un au-delà… » | « potentiellement » (la partie « formés par épreuves » est retirée depuis le 9 oct.) |

**Version corrigée (IA, à valider) :** un monde de régions de conte, tenu par un ordre de hiérarchies, où des personnages (peut-être de 15 à 19 ans) traversent des régions marquées par des héritages différents, au contact, potentiellement et en fond, d'un au-delà probablement structuré.

## 2bis. Illustration (réaction de l'utilisateur)

L'IA avait proposé, comme exemple pour comprendre (pas comme intrigue) : « Quelqu'un quitte une région de landes et de pierres levées. Il traverse un couloir de plantes et arrive dans une zone industrielle, où une institution le teste. Il doit respecter des conditions pour utiliser ses pouvoirs. Un démon dont le rang est connu lui parle d'un au-delà qui a ses propres règles. »

**(U), 7 oct. :** « C'est clairement une bonne inférence de mes idées et choix. » Ce jugement porte sur l'exemple comme inférence de ses idées ; ce n'est pas une décision de scénario. Précision de l'utilisateur : « bonne inférence » est à prendre entre guillemets ; l'exemple n'est qu'une illustration possible parmi d'autres de l'inférence sur le projet, construite par l'IA pour être la plus cohérente avec les éléments connus. Deux réserves de l'IA : la phrase sur les « conditions pour utiliser ses pouvoirs » suppose un degré de contrainte que l'utilisateur n'a pas fixé (voir §3), et l'au-delà reste « en fond, potentiellement ».

## 2ter. Illustration, version 3 (sans réserves dans le texte)

*Exemple pour comprendre, pas une intrigue ni une proposition de scénario. Les réserves sont dans le tableau, pas dans le texte.*

« Un jeune quitte une région de landes et de pierres levées. Il traverse un couloir de plantes et arrive dans une zone industrielle. »

| Élément | Appui | Statut |
|---|---|---|
| jeune | U : « peut-être entre 15 et 19 ans » | peut-être |
| landes, pierres levées | image de pierres levées (ambiance) | pierres : ambiance seulement ; « landes » : vocabulaire à préciser |
| couloir de plantes | « sans doute envisageable » (U) | cohérent, non décidé |
| zone industrielle | BioShock Infinite | décidée (3 oct.) |

**Retiré de la version 2, sur remarque de l'utilisateur :** la phrase sur les limites du pouvoir et la condition « sans qu'on dise si elle pèse beaucoup ou peu », et la phrase sur le rang infernal entendu « sans savoir si c'est une légende ou un fait » (cette dernière ajoutait un détail que l'utilisateur n'avait pas dit). Raison : des réserves écrites dans le texte d'un exemple sonnent faux ; elles relèvent du tableau.

## 3. Le point des « conditions » (retiré du YAML le 8 oct. 2026)

- Le bloc `projet.systeme_de_pouvoirs` a été retiré du YAML à la demande de l'utilisateur (8 oct.). Le YAML ne dit donc plus rien sur les limites des pouvoirs ni sur les « conditions » : ce sujet n'est ni décidé ni envisagé dans le YAML et ne doit pas être traité comme tel.
- Historique du 7 oct., conservé pour mémoire (ne vaut pas statut) : **(U)** avait d'abord dit que la partie « conditions » n'était « sans doute pas bonne », puis l'a précisée : comme règle générale (« plus puissant, plus de conditions ») elle lui semble contraignante, mais des conditions seront sans doute naturellement présentes dans le sujet ; il n'a pas dit comment elles seraient contraignantes ou non.
- Conséquence pour la synthèse : « conditions » reste hors de la phrase (l'ordre est de hiérarchies).

## 4. Points ouverts

- Passage entre régions du même monde : les régions appartiennent à un seul monde (U, tour 164 : « même monde »). Un liant supplémentaire (institution transversale, lois du monde, cosmologie commune) n'est pas nécessaire ; le passage peut être progressif ou marqué par une frontière (non tranché). Ancienne formulation : « ciment entre les zones » (IA, jugée trop lourde).
- Cosmologie : au-delà central ou ambiance.
- Académie, guilde ou les deux ; importance de l'école dans l'histoire (inconnue).
- Âge et statut des personnages (15-19 ans : peut-être ; non déclarés protagonistes).
- Le récit voyage-t-il entre les régions, ou reste-t-il dans un lieu ?

## 5. Mise à jour du 8 oct. 2026 (accord avec le YAML)

- Système de pouvoirs : retiré du YAML à la demande de l'utilisateur ; §1.2 et §3 ajustés.
- *Fullmetal Alchemist* et *La Horde du Contrevent* : statut « référence » (et non plus « influence »).
- Zone « Forêt de conte » ajoutée dans `ambiance_des_lieux` (statut décidé par l'utilisateur le 9 oct. ; nom et formulation rédigés par l'IA, à valider). Zone montagnarde : en attente d'images de l'utilisateur.

## 6. Mise à jour du 9 oct. 2026

- Le personnage qui passe des épreuves est retiré (demande de l'utilisateur) : §1.5, la version corrigée de la phrase de synthèse et l'illustration ont été ajustés. Rien dans le YAML n'en parlait.

## 7. Mise à jour du 11 oct. 2026 (accord avec le YAML)

*Source : tes validations par numéros (1 à 12) et tes corrections du 11 oct. Détail dans `fiches_references_projet.yaml`.*

- **Structure du monde (envisagée) :** un royaume principal, des cités-États et des royaumes adjacents, avec des régions différentes par culture et par régime. Cela précise §1.1 (monde-mosaïque) : les « régions de conte » ne sont plus seulement des héritages, elles peuvent avoir chacune un régime politique. L'échelle (ce que représente un domaine, un baron, une cité-État, un royaume) reste non précisée.
- **Modèle de monde :** mélange de *The Witcher 3*, de Runeterra et de *Fullmetal Alchemist* ; dosage non précisé. Ces trois œuvres ont des fiches dans le YAML.
- **Hiérarchies (§1.2) :** la structure ci-dessus ajoute des niveaux (domaine, cité-État, royaume) qui ne sont pas encore reliés aux rangs infernaux ou aux institutions ; rien n'est tranché.
- **Lieux arthuriens :** seuls Brocéliande et Le Lac sont décidés ; les six autres sont envisagés. Cela ne change pas §1.1, qui ne les citait pas.
- **Zones d'ambiance et inspirations issues de tes brouillons :** niveau « intérêt » ; zone marécageuse (bayou ou marais de Shrek) ; région désertique inspirée du Languedoc (non précisé). Pas de décision de scénario.
- **Académie et guilde (§1.5, §4) :** les brouillons mentionnent une école liée à Brocéliande, au niveau « intérêt » ; ce n'est pas une décision.
- Rien de cette section n'ajoute une histoire : §0 reste vrai.

## 8. Mise à jour du 12 oct. 2026 (technologie, armes à feu 1860 et ressources régionales)

*Source : tes précisions et réflexions dans la discussion (11-12 oct. 2026). Détail dans `fiches_references_projet.yaml` (blocs `projet.cadre_valide` et `projet.technologie`).*

- **Armes à feu plafonnées à 1860 (`decide`) :** tu as précisé que les armes à feu sont plafonnées à 1860. Elle écarte la mitrailleuse, la poudre sans fumée et les fusils modernes, ce qui rend le combat rapproché plus plausible que dans un monde de 1914. **Réserve ajoutée le 12 oct. après vérification :** 1860 n'est pas synonyme de « tir lent ». Les carabines à répétition Spencer (7 coups) et Henry (16 coups) existent dès 1860, et les fusils rayés de l'époque portent à plusieurs centaines de mètres. Que ces armes soient incluses dans ton plafond n'est pas précisé. Une première version de cette phrase s'appuyait aussi sur une « limite de vitesse décidée » pour les personnages ; je n'en trouve pas de trace dans le YAML (voir `discussion_autre_IA/verification_des_4_fichiers.md`).
- **Baisse envisagée du plafond technologique général de 1950 à 1914 (`envisage`) :** tu envisages d'abaisser le plafond technologique général (hors magie) à 1914. Cela précise §1.4 (*Un temps flou plutôt qu'une date*) : l'horizon industriel maximal correspondrait à la Belle Époque / début du XXe siècle (vapeur, rail, électricité naissante, acier, débuts de l'automobile), tandis que l'armement à feu reste bloqué à 1860.
- **Inégalité technologique régionale par les ressources (`envisage`) :** tu penses partir du principe que certaines régions sont plus avancées que d'autres et que les **ressources magiques et naturelles** ont un impact direct sur cet avancement, à l'image des modèles de référence étudiés (*Runeterra*, *The Witcher 3*, *Fullmetal Alchemist*, *One Piece*, *Mistborn Era 2 — Livre 1*). Cela enrichit directement §1.1 (*Un monde-mosaïque de régions*) : les régions ne diffèrent plus seulement par leur héritage culturel, leur folklore et leur régime politique, mais aussi par leur dotation en ressources et leur niveau d'équipement.


## 9. Mise à jour du 22 oct. 2026 (accord avec le YAML ; nouvelles inférences)

*Source : discussion des 21 et 22 oct. 2026. Statuts détaillés dans `fiches_references_projet.yaml` (mise à jour du 22 oct.).*

### 9.1 Reporté dans le YAML (tes décisions et corrections)

- **Anachronisme vestimentaire (`decide`, U, 15 oct.) :** esthétique plus moderne et anachronique, dans le style des 7 images de `references_visuelles`. Cela confirme §1.4 (l'habit suit la fonction, époque floue).
- **Zone western :** c'est un paysage ; le mode de vie n'est pas encore réfléchi (U, 12 oct.).
- **Zone mafieuse :** seule la structure sociale est gardée, jamais au-delà de 1914 (U, 12 oct.).
- **« Terre dévastée » :** proposition de l'IA, pas ton nom de brouillon (U, 12 oct.).
- **Harley Delphine :** nom provisoire ; personnage non défini pour l'instant (U, 12 oct.).
- **Couche gréco-égyptienne de l'Antiquité tardive (`interet`, U, 22 oct.) :** voir 9.3.
- **Ambiance de conte :** elle concerne l'ambiance des lieux (U, 22 oct.) ; c'était déjà noté, rien ne change.

### 9.2 Nouvelles inférences de l'IA (22 oct.)

**Réaction (U) :** « La plupart de tes points sont correctes » (sans préciser lesquels) ; les points 1 et 2 sont jugés bons et ont été développés à ta demande.

1. **Le merveilleux français comme cœur (confiance forte).** Arthurien en langue française (décidé), folklore régional de la carte de France, *Dictionnaire infernal*, Bibliothèque bleue, *Dictionnaire féodal*, ambiance de conte. **Abduction :** la Bibliothèque bleue (XVIIe-XIXe s.) réunissait romans de chevalerie (dont *Mélusine*), contes (Perrault, Mme d'Aulnoy) et almanachs, astrologie et magie ; tes trois piliers (chevalerie, conte, superstition) recomposent donc l'imaginaire populaire français de l'Ancien Régime. Le noyau est français, avec des cercles voisins (Grimm, Runeterra, démons de tradition latine). Précise §1.1.
2. **Le cadre temporel.** Le terme « Belle Époque » (employé ici en §8 et le 22 oct.) est **imprécis** : il désigne surtout une culture urbaine d'environ 1871-1914 et ne couvre ni les armes de 1860, ni le western, ni les éléments médiévaux. Termes plus justes : **« long XIXe siècle »** (1789-1914) ; étiquette de genre **« gaslamp fantasy »** (pas *steampunk*, qui invente des technologies). Ces termes ne valent que si le plafond de 1914 (`envisage`) est retenu ; avec le plafond officiel de 1950, aucun ne convient. **Anachronisme réparti sur la carte :** « une seule époque » (décidé) + inégalité technologique régionale (envisagé) : l'époque apparente varie selon la région, pas selon le temps (modèle Runeterra).
   - **Correction de l'IA :** le 22 oct., l'IA a écrit qu'avec le plafond de 1860 « les armes restent lentes ». C'est trop fort : la poudre sans fumée (1884), la Gatling (1862) et le Lebel (1886) sont bien exclus, mais les carabines à répétition Spencer et Henry existent dès 1860 (réserve du §8) ; leur inclusion dans ton plafond n'est pas précisée.
3. **Le trio reprend des rôles classiques (confiance moyenne) :** Brann héros moteur ; Cosmo ami ou rival virtuose ; Harley tête du groupe à face cachée possible (simple tendance de ses inspirations ; Harley n'est pas définie).
4. **L'emblème le mieux appuyé est le Chevalier (constat) :** goal de Brann (intérêt), Perceval, « Chevalier » chez Fabula Fantasia, arthurien décidé, tournois et titres féodaux des brouillons.
5. **Ton de conte qui peut devenir cruel (confiance moyenne) :** décors de conte lumineux contre violence ou ambiguïté morale (Red Hood, HxH, Worm, Tarantino). Précise §1.5.
6. **Une région, un genre (hypothèse) :** chaque région pourrait porter un arc d'un genre différent (comme les arcs de HxH ou les îles de One Piece). Prolonge §1.1.
7. **Préférence pour les pouvoirs à règles (constat) :** Nen, Bankai, alchimie, jujutsu, Sanderson ; exclusion des concepts métafictionnels. Le système de pouvoirs reste mis de côté.
8. **Risques :** proximité avec Radiant (manga français, fantasy européenne, tenues) ; tes références de ton ont mal tenu dans la durée (Red Hood arrêté après 3 tomes, HxH souvent en pause).

### 9.3 Couche gréco-égyptienne (vérification de l'IA)

- **Correction :** les papyrus grecs magiques (IIe s. av. - Ve s. apr. J.-C.) étaient inconnus à la Renaissance : achetés vers 1827, publiés en 1928-1931. Ce sont des cousins de la magie de la Renaissance, pas ses ancêtres directs.
- **Transmission réelle :** *Corpus Hermeticum* (traduit par Ficino en 1463, imprimé en 1471), néoplatonisme, *Picatrix* (utilisé par Ficino), tradition salomonienne (*Testament de Salomon* → liste de Weyer, 1577 → *Goetia*).
- **Points d'appui dans le YAML :** « Folklores gréco-égyptiens » (référence), Agrippa (décidé), Gremory, Furfur, Marbas et Stolas (envisagés), Renaissance (intérêt), occultisme comme ambiance de symboles.
- **Place proposée :** couche de fond (grimoires, symboles), pas un décor visible. Elle deviendrait forcée si elle apparaissait dans le décor (temples, toges) ou si elle fixait une doctrine de la magie.

### 9.4 Logiques générales de tes goûts (inférences de l'IA, 23 oct.)

**Ta méthode (U, 23 oct.) :** tu te fies à tes goûts et aux goûts et avis des autres pour créer ton manga. Tu as regardé beaucoup de tier lists et tu t'es basé sur les personnages les plus tagués sur r34 pour savoir lesquels plaisent le plus.

**Origine de l'inspiration occidentale (U, 24 oct.) :** ton choix de t'inspirer de personnages d'œuvres occidentales vient de *Rise of the Brave Tangled Dragons*, un crossover de fans qui réunit Raiponce, Mérida, Harold et Jack Frost. Ajouté au YAML (`references`). *Lecture de l'IA :* cela éclaire la place de Raiponce, d'Astrid et des deux Gwen dans ta tier list. Quand l'IA a relevé que tes goûts suivent le schéma « base connue, attitude marquée, dessin simple à refaire » (24 oct.), ta réaction a été : « oui je m'en suis rendu compte ».

| Logique proposée par l'IA | Réaction (U, 23 oct.) |
|---|---|
| Hybridation Occident et Japon (Nomura, Madureira, *Teen Titans*, *Spider-Verse*, *Arcane*, *Radiant*, Edenia) | **« Tu as raison »** |
| Merveilleux français comme cœur (9.2, point 1) | **Confirmé** |
| Versions alternatives de figures connues (contes revisités, Spider-Gwen, Raiponce à Poudlard) | pas de réaction |
| Époques mélangées dans une même image (design de Rook-D, anachronisme décidé) | pas de réaction |
| Héroïne intelligente, compétente, à part (Violet, Gwen Tennyson, Raven, Astrid, Purah ; Harley) | pas de réaction |
| Formes simples et encrage sale (lignée Disney et Timm ; Gachiakuta, JJK, Capullo) | pas de réaction |

§0 reste vrai : rien de cette section n'ajoute une histoire.
