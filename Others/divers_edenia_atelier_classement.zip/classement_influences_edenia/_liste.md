| Groupe (ton répertoire) | Influence | Statut dans le YAML | Trace documentée dans Edenia ? |
|---|---|---|---|
| Littérature, mythes et imaginaires | The Stormlight Archive | influence | oui |
| Littérature, mythes et imaginaires | Game of Thrones | influence | oui |
| Littérature, mythes et imaginaires | La légende arthurienne | — | oui |
| Littérature, mythes et imaginaires | Harry Potter | influence (films et livres) | oui |
| Littérature, mythes et imaginaires | H. P. Lovecraft | — | hypothèse IA seulement |
| Littérature, mythes et imaginaires | Le Seigneur des anneaux | influence | oui |
| Littérature, mythes et imaginaires | The Kingkiller Chronicle | influence | aucune trace documentée |
| Littérature, mythes et imaginaires | Mother of Learning | — | aucune trace documentée |
| Littérature, mythes et imaginaires | La Horde du Contrevent | référence (« sans doute un peu moins ») | aucune trace documentée |
| Littérature, mythes et imaginaires | Shakespeare | — | aucune trace documentée |
| Littérature, mythes et imaginaires | La Fondation SCP | — | oui |
| Littérature, mythes et imaginaires | The Magnus Archives | — | aucune trace documentée |
| Littérature, mythes et imaginaires | L'occultisme, l'ésotérisme | — | oui |
| Comics et super-héros | Worm / Parahumans | influence | oui |
| Comics et super-héros | Watchmen (comic, série) | — | oui |
| Comics et super-héros | X-Men | — | oui |
| Comics et super-héros | Batman | — | aucune trace documentée |
| Comics et super-héros | Spider-Man | — | oui |
| Comics et super-héros | Invincible | — | aucune trace documentée |
| Comics et super-héros | Hellboy | — | oui |
| Comics et super-héros | Deadly Class | — | aucune trace documentée |
| Comics et super-héros | Teen Titans | — | aucune trace documentée |
| Comics et super-héros | Joe Madureira | — | aucune trace documentée |
| Comics et super-héros | Marvel Rivals | — | aucune trace documentée |
| Manga et animation | Yu Yu Hakusho | influence | oui |
| Manga et animation | Hunter x Hunter | influence | oui |
| Manga et animation | Jujutsu Kaisen | influence | oui |
| Manga et animation | JoJo's Bizarre Adventure (parties 4 et 5) | — | aucune trace documentée |
| Manga et animation | Naruto | influence | oui |
| Manga et animation | L'Attaque des Titans | — | oui |
| Manga et animation | One Piece | influence | oui |
| Manga et animation | Dorohedoro | — | oui |
| Manga et animation | Solo Leveling | — | aucune trace documentée |
| Manga et animation | Fullmetal Alchemist | référence | oui |
| Manga et animation | The Hunters Guild: Red Hood | influence + référence | oui |
| Manga et animation | World Trigger | — | aucune trace documentée |
| Manga et animation | Magi | — | aucune trace documentée |
| Manga et animation | The Seven Deadly Sins | (repoussoir arthurien) | aucune trace documentée |
| Manga et animation | Steins;Gate | — | aucune trace documentée |
| Manga et animation | Bakemonogatari | — | aucune trace documentée |
| Manga et animation | Kekkai Sensen | — | aucune trace documentée |
| Manga et animation | Haikyu!! | — | aucune trace documentée |
| Manga et animation | Hayao Miyazaki | — | aucune trace documentée |
| Jeux vidéo et univers associés | World of Warcraft, Hearthstone | influence | oui |
| Jeux vidéo et univers associés | League of Legends, Legends of Runeterra, Arcane | influence | oui |
| Jeux vidéo et univers associés | The Witcher (surtout The Witcher 3) | référence | oui |
| Jeux vidéo et univers associés | BioShock (série) | influence (Infinite) | oui |
| Jeux vidéo et univers associés | Urban Rivals | référence | oui |
| Jeux vidéo et univers associés | Grand Theft Auto V | — | aucune trace documentée |
| Jeux vidéo et univers associés | Street Fighter, Marvel vs. Capcom, Capcom vs. SNK, SNK, Capcom | — | oui |
| Jeux vidéo et univers associés | Overwatch | — | oui |
| Jeux vidéo et univers associés | Final Fantasy | — | aucune trace documentée |
| Jeux vidéo et univers associés | Tekken | — | aucune trace documentée |
| Jeux vidéo et univers associés | Apex Legends | — | aucune trace documentée |
| Cinéma, séries et spectacle | Breaking Bad | — | aucune trace documentée |
| Cinéma, séries et spectacle | Quentin Tarantino | influence | oui |
| Cinéma, séries et spectacle | Doctor Who | — | aucune trace documentée |
| Cinéma, séries et spectacle | The X-Files | — | aucune trace documentée |
| Cinéma, séries et spectacle | Terminator (1 et 2) | — | aucune trace documentée |
| Cinéma, séries et spectacle | Alien | — | aucune trace documentée |
| Cinéma, séries et spectacle | Mad Max | — | aucune trace documentée |
| Cinéma, séries et spectacle | Disney et Pixar (dont La Princesse et la Grenouille, Frère des ours, Raiponce) | — | oui |
| Cinéma, séries et spectacle | Les Affranchis | — | aucune trace documentée |
| Cinéma, séries et spectacle | Fargo (saisons 1 et 2) | — | aucune trace documentée |
| Cinéma, séries et spectacle | Films d'arts martiaux | — | hypothèse IA seulement |
| Cinéma, séries et spectacle | Le catch | — | hypothèse IA seulement |

**Hors répertoire, mais présents dans le dépôt ou dits en conversation :**

| Influence | Où elle apparaît | Trace documentée dans Edenia ? |
|---|---|---|
| Dictionnaire infernal (Collin de Plancy) | YAML (source documentaire) ; extraits dans Pdfmd/ | oui |
| Folklore français (carte « Mythical Beasts of France ») | YAML, fiche créatures | oui |
| Dictionnaire féodal (1820) | YAML (source documentaire, apportée par le dépôt) | oui |
| Bibliothèque bleue | YAML | oui |
| Dante (Inferno, Purgatorio) | YAML (au-delà) | oui |
| Tradition catholique (Limbes, purgatoire) | YAML (au-delà) | oui |
| Folklores gréco-égyptiens | YAML (corpus de traditions) | oui |
| Contes européens (tradition) | YAML (ambiance des lieux) | oui |
| Renaissance (période) | YAML (brouillons) | oui |
| Moyen Âge, bas et milieu (période) | YAML (brouillons) | oui |
| Shrek | YAML (influence) ; DreamWorks, donc pas dans « Disney et Pixar » | oui |
| Radiant / Fabula Fantasia (Tony Valente) | YAML (référence, « un cas spécial ») ; Fabula Fantasia sans statut_relation | oui |
| Bleach | YAML (référence) | oui |
| Inspirations asiatiques (source non précisée) | YAML (envisagé) | oui |
| Ben 10 | conversation du 12 oct. (noms) | oui |
| Soul Eater | conversation du 12 oct. (Maka) | oui |
| Gigantic | récit de influences-atelier.md (projet de jeu) | oui |
| BioShock (premier du nom) | conversation du 12 oct. (zone mafieuse) | oui |
| Shadman | conversations du 12 et du 15 oct. (références de dessin) | oui |
| Quirkilicious (Drake Tsui) | conversations du 12 et du 15 oct. (références de dessin) ; doc. PixAI (« le style artistique que j'aime le plus ») | oui |
| atie1225 (鉄, illustrateur sur X) | conversation du 15 oct. (style artistique ; écrit d'abord « Att1e125 », corrigé en « atie1225 ») | oui |
| Gachiakuta (Kei Urana, graffitis d'Ando Hideyoshi) | conversation du 15 oct. (style artistique) ; doc. PixAI (LoRA préférés) | oui |
| DreamWorks Animation (style) | doc. PixAI « Arcana Art » (LoRA préférés) | oui |
| Kaneoya Sachiko (écrit « Kanoaya Sachiko ») | doc. PixAI « Arcana Art » (LoRA préférés) ; orthographe probable « Kaneoya », non confirmée | oui |
| Jomaro Kindred (concept artist, Hearthstone) | doc. PixAI « Arcana Art » (artistes aimés, sans LoRA) | oui |
| Joe Madureira | doc. PixAI « Arcana Art » (artistes aimés, sans LoRA) | oui |
| Tetsuya Nomura / Kingdom Hearts (style de personnages) | doc. PixAI « Arcana Art » (artistes aimés) ; test de Cosmo (Kingdom Hearts) | oui |
| The Boondocks | test PixAI de Cosmo Dumas | oui |

*30 entrées du répertoire sur 66 ont une trace documentée.*
