
### Monde : structure, zones, géographie politique (pôle B2)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Légende arthurienne (Perceval, Vulgate) | 6 | D×1 · E×1 · I×1 | Lieux décidés Brocéliande et Le Lac ; règle « lieux arthuriens français uniquement » ; Six lieux envisagés (Douloureuse Garde, Bénoïc, Gaunes, Trèbes, Montlair, Terre Déserte) ; Zone de brouillon « Brocéliande, forêt féerique avec une école » |
| 1 | Runeterra (LoL, Arcane, Legends of Runeterra) | 6 | E×1 · U×1 · I×2 | Note du dépôt : « Référence principale du monde. Edenia en est proche » ; Plan politique envisagé (royaume principal, cités-États, royaumes adjacents) ; modèle de monde « W3 + Runeterra + FMA » ; Zone de brouillon « Nouvelle-Orléans / Caraïbes » inspirée … |
| 3 | Folklore français (carte « Mythical Beasts of France ») | 5 | E×1 · U×1 · I×1 | Région montagnarde enneigée (décidée) avec les Barbegazi comme créature locale (envisagés) ; Héritage francophone gardé entre les zones ; Héritages « répartis par régions » (une des deux façons retenues) |
| 3 | The Witcher 3 | 5 | E×1 · U×1 · I×1 | Aspect visé : structure du monde (« U avait déjà cité The Witcher 3 comme modèle du monde ») ; Plan envisagé ; modèle de monde « W3 + Runeterra + FMA » ; Zone marais : le brouillon cite Velen |
| 5 | BioShock Infinite | 4 | D×1 · I×1 | Zone industrielle de type BioShock Infinite ; Zone de brouillon « Piltover / Columbia » |
| 6 | Fullmetal Alchemist | 3 | E×1 · I×1 | Plan envisagé ; modèle de monde « W3 + Runeterra + FMA » ; « FMA correspond au modèle un pays principal, avec des régions culturelles et des voisins » |
| 6 | Urban Rivals | 3 | U×1 · I×1 | « attrait […] pour les univers hétéroclites, avec des gangs et des designs reconnaissables » ; Aspect visé : plusieurs zones culturelles dans un même lieu |
| 8 | Fondation SCP (dont la Chicago Spirit) | 2 | U×1 | Chicago Spirit citée comme source de la zone mafieuse ; structure sociale gardée |
| 8 | La Princesse et la Grenouille (Disney, 2009) | 2 | I×2 | Les deux images vont à la zone marais (« style bayou ») ; Les deux images vont à la zone Nouvelle-Orléans / Caraïbes |
| 8 | Occultisme et ésotérisme | 2 | U×1 | Règle France, sinon Angleterre et Allemagne : « pays principaux de l'occultisme » |
| 11 | Warcraft / Hearthstone | 1.5 | I×1 · H×1 | Gadgetzan dans la liste de zones du brouillon (rapprochement déjà fait par toi) — *hyp. IA : Monde en mosaïque de factions hérité des jeux de cartes (principe P-D)* |
| 12 | BioShock (premier du nom) | 1 | I×1 | « Piltover-BioShock 1 / Gadgetzan » (brouillon) ; source de la zone mafieuse |
| 12 | Shrek | 1 | I×1 | Zone marais « style bayou ou marais de Shrek » |
| 12 | The Stormlight Archive | 1 | I×1 | Zone désertique pensée d'après les Plaines Brisées de Roshar |

### Technologie et époque (pôle B2)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Occultisme et ésotérisme | 2.5 | U×1 · H×1 | Occultisme des années 1890-1910 en tête ; « je ne veux pas dépasser 1914 » — *hyp. IA : 1914 ferme aussi la grande époque des sociétés occultes (Belle Époque)* |
| 2 | BioShock Infinite | 1.5 | I×1 · H×1 | Contrainte liée dans la fiche : le plafond technologique (1950, baisse à 1914 envisagée) — *hyp. IA : 1914 (envisagé) proche de 1912, date de BioShock Infinite* |
| 2 | Runeterra (LoL, Arcane, Legends of Runeterra) | 1.5 | I×1 · H×1 | Cadre temporel flou comme Runeterra — *hyp. IA : Inégalité régionale par les ressources « comme les autres modèles » (Piltover)* |
| 4 | BioShock (premier du nom) | 1 | I×1 | Gardé seulement pour ce qui tient sous 1914 |
| 4 | Fondation SCP (dont la Chicago Spirit) | 1 | I×1 | Chicago Spirit, organisation du début du XXᵉ siècle, gardée sous 1914 |
| 4 | Moyen Âge, bas et milieu (période) | 1 | I×1 | Bas et milieu Moyen Âge |
| 4 | Naruto | 1 | I×1 | Cadre temporel flou comme Naruto |
| 4 | One Piece | 1 | I×1 | Cadre temporel flou comme One Piece |
| 4 | Radiant / Fabula Fantasia (Tony Valente) | 1 | I×1 | Cadre temporel flou comme Radiant |
| 4 | Renaissance (période) | 1 | I×1 | Renaissance : science, folklore, superstitions, croyances, magie |

### Matière : folklore, légendes, occultisme, au-delà (pôle B)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Dictionnaire infernal (Collin de Plancy) | 11 | D×1 · E×4 · I×2 | Agrippa ; Gremory/Gomory ; Furfur ; Marbas ; Stolas ; Figures non précisées : Faust, Albert le Grand, Grandier, Merlin, Abel de Larue ; Cour infernale |
| 2 | Folklore français (carte « Mythical Beasts of France ») | 9 | E×4 · I×3 | Barbegazi ; Mélusine ; Ankou ; Mourioche, Petit Homme rouge, Gayant, Houeron, Tarasque ; Loup-garou, Vouivre, Fée… ; Gargouille, Dame verte, Chien noir de Pontgibaud… ; Les 24 créatures de la carte en intérêt |
| 3 | Légende arthurienne (Perceval, Vulgate) | 3 | D×1 | Personnages arthuriens : des inspirations seulement, sous d'autres noms |
| 4 | Dante (Inferno, Purgatorio) | 2 | I×2 | Inferno ; Purgatorio |
| 4 | Tradition catholique (Limbes, purgatoire) | 2 | I×2 | Limbo catholique ; Purgatoire classique |
| 6 | Bibliothèque bleue | 1.5 | I×1 · H×1 | Le contenu des livres de la Bibliothèque bleue — *hyp. IA : Matrice commune de la chevalerie, du conte et de la superstition* |
| 7 | Dorohedoro | 1 | I×1 | Enfer et démons de Dorohedoro |
| 7 | Folklores gréco-égyptiens | 1 | I×1 | Corpus cité, sans usage précisé |
| 7 | Hellboy | 1 | I×1 | Chasse sauvage, retrouvée dans Hellboy |
| 7 | Occultisme et ésotérisme | 1 | I×1 | Penche vers l'ambiance (symboles, décors, objets rituels) ; livres de sorts : « ce qui compte surtout : les symboles sur le livre » ; volontairement non tranché |
| 7 | Renaissance (période) | 1 | I×1 | Renaissance : folklore, superstitions, croyances, magie |
| 7 | The Witcher 3 | 1 | I×1 | Chasse sauvage, découverte avec The Witcher 3 |
| 7 | Urban Rivals | 1 | I×1 | Yétis (groupe), inspirés des Frozn |
| 7 | X-Men / Marvel (Magik) | 1 | I×1 | Limbo de Magik |
| 15 | La Princesse et la Grenouille (Disney, 2009) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Masques, statuettes et bougies du salon : l'occultisme d'ambiance vers lequel tu penches* |

### Société et institutions : rangs, titres, organisations (pôle B)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Dictionnaire infernal (Collin de Plancy) | 3.5 | U×1 · I×1 · H×1 | Aspect visé : les hiérarchies ; Cour infernale — *hyp. IA : L'enfer copie la monarchie humaine (Abigor, Adraméleck, Léonard dans tes extraits)* |
| 2 | Bleach | 2 | U×1 | Aspect visé : la structure du Gotei 13 |
| 2 | Fondation SCP (dont la Chicago Spirit) | 2 | U×1 | Zone mafieuse : seulement la structure sociale |
| 2 | Runeterra (LoL, Arcane, Legends of Runeterra) | 2 | E×1 | École ou académie à cadre vestimentaire imposé (envisagée) ; tenue Academy Ekko |
| 5 | Dictionnaire féodal (1820) | 1.5 | I×1 · H×1 | Source documentaire du dépôt (titres, chevalerie, champions) — *hyp. IA : Chevalerie interdite au roturier* |
| 6 | Harry Potter (films et livres) | 1 | I×1 | École de type Harry Potter à Brocéliande |
| 6 | Hunter × Hunter | 1 | I×1 | Gimmick Hunter : un statut délivré par une institution |
| 6 | Radiant / Fabula Fantasia (Tony Valente) | 1 | I×1 | Tenue Fabula Fantasia : « surtout pour des personnages de profession Chevalier » |
| 6 | Warcraft / Hearthstone | 1 | I×1 | Gadgetzan : ville tenue par des familles criminelles |
| 10 | Légende arthurienne (Perceval, Vulgate) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Goal « devenir chevalier » = goal d'ouverture de Perceval* |
| 10 | The Hunters Guild: Red Hood | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Modèle de la guilde* |

### Pouvoirs et gimmick (pôle B2, système)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Bleach | 3 | U×1 · I×1 | Aspect visé : le Bankai ; Gimmick Shinigami |
| 1 | Fullmetal Alchemist | 3 | U×1 · I×1 | Aspect visé : les deux traditions d'alchimie ; Gimmick Alchimiste |
| 3 | Hunter × Hunter | 1 | I×1 | Gimmick Hunter |
| 3 | Naruto | 1 | I×1 | Gimmick Ninja |
| 3 | One Piece | 1 | I×1 | Gimmick Pirate |
| 6 | Dictionnaire infernal (Collin de Plancy) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Grandier comme matière du gimmick Exorciste ; rites à conditions* |
| 6 | Jujutsu Kaisen | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : « Version améliorée et modernisée de Bleach et de YYH » (ton jugement, pas un usage)* |
| 6 | Légende arthurienne (Perceval, Vulgate) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : « Chevalier » comme gimmick latent* |

### Personnages (pôle C)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Harry Potter (films et livres) | 5 | U×2 · I×1 | Hermione, inspiration de Harley ; Luna Lovegood, personnalité visée pour Harley ; Le nom « Harley » rapproche d'Hermione |
| 2 | Hunter × Hunter | 2.5 | U×1 · H×1 | Killua, inspiration de Cosmo — *hyp. IA : Cosmo construit comme le « second aimé »* |
| 2 | Légende arthurienne (Perceval, Vulgate) | 2.5 | U×1 · H×1 | Perceval, inspiration de Brann — *hyp. IA : Goal de Brann = goal d'ouverture de Perceval* |
| 4 | Ben 10 | 2 | I×2 | Gwen Tennyson : prénom et modèle d'origine de Harley ; « Bran » rapproché de Ben 10 |
| 4 | Fullmetal Alchemist | 2 | U×1 | Edward, inspiration de Brann |
| 4 | Naruto | 2 | U×1 | Shisui, inspiration de Cosmo |
| 4 | One Piece | 2 | U×1 | Luffy, inspiration de Brann |
| 4 | Runeterra (LoL, Arcane, Legends of Runeterra) | 2 | U×1 | Ekko, inspiration de Cosmo |
| 4 | Soul Eater | 2 | U×1 | Maka Albarn, personnalité visée pour Harley |
| 4 | The Stormlight Archive | 2 | U×1 | Shallan, inspiration de Harley |
| 4 | Worm | 2 | U×1 | Tattletale, inspiration de Harley |
| 4 | X-Men / Marvel (Magik) | 2 | U×1 | Magik, inspiration de Harley |
| 4 | Yu Yu Hakusho | 2 | U×1 | Yusuke, inspiration de Brann |
| 14 | Game of Thrones | 1 | I×1 | Le nom « Bran » vient de GoT |
| 14 | Warcraft / Hearthstone | 1 | I×1 | « Brann » vient de Hearthstone |

### Visuel : trait et style de dessin (pôle A1)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Quirkilicious (Drake Tsui) | 7 | U×3 · I×1 | « Mes autres références en termes de dessin » ; « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; « Quirikilicious surtout son style sur S.I.N est le style artistique que j'aime le plus » ; « Lora Préféré : Shadman, Gachiakuta, … |
| 2 | Disney / Pixar (style d'animation) | 5 | U×2 · I×1 | « Disney Pixar est le style que je cherche à atteindre » ; « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, Quirkilicious, Disney Pixar, DreamWorks » |
| 2 | Gachiakuta (Kei Urana, graffitis d'Ando Hideyoshi) | 5 | U×2 · I×1 | « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; « Gachiakuta (il y a deux modèles que j'utilise), c'est le deuxième Lora qui me sert de base » ; « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, Quirkilicious, … |
| 2 | Shadman | 5 | U×2 · I×1 | « Mes autres références en termes de dessin » ; « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, Quirkilicious, Disney Pixar, DreamWorks » |
| 2 | atie1225 (鉄, illustrateur sur X) | 5 | U×2 · I×1 | « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; « Atie1225 me sert plus comme un Lora de base » (le mot « sketchy », jugé trop fort, retiré par toi le 15 oct.) ; « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, … |
| 6 | Jujutsu Kaisen | 4 | U×2 | « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) ; Tag positif habituel : « Jujutsu Kaisen Style (et ces dérivés) » |
| 7 | Cartoon semi-réaliste (famille de styles) | 2 | U×1 | « J'aime bien le style semi-realistic cartoon, je trouve que ça peut rendre bien en manga » |
| 7 | Codes du manga (yeux, forme du visage) | 2 | U×1 | « légèrement différent, pour qu'il soit plus manga compatible, c'est surtout pour les yeux et la forme du visage » |
| 7 | Naruto | 2 | U×1 | « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) |
| 7 | Spider-Verse (films d'animation Spider-Man) | 2 | U×1 | « Je crois que mon style artistique se trouve dans […] » (liste de 8 noms) |
| 11 | Capcom / Street Fighter (jeux de combat) | 1 | I×1 | Tags habituels : « parfois Street Fighters Characters » |
| 11 | DreamWorks Animation (style) | 1 | I×1 | « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, Quirkilicious, Disney Pixar, DreamWorks » |
| 11 | Joe Madureira | 1 | I×1 | « Artiste non loraisé mais que j'aime bien : Jomaro Kindred, Joe Madureira, Tetsuya Nomura » |
| 11 | Jomaro Kindred (concept artist, Hearthstone) | 1 | I×1 | « Artiste non loraisé mais que j'aime bien : Jomaro Kindred, Joe Madureira, Tetsuya Nomura » |
| 11 | Kaneoya Sachiko (écrit « Kanoaya Sachiko ») | 1 | I×1 | « Lora Préféré : Shadman, Gachiakuta, Attie, Kanoaya Sachiko, Quirkilicious, Disney Pixar, DreamWorks » |
| 11 | Raiponce / Tangled (Disney, 2010) | 1 | I×1 | Cinq dessins de Raiponce donnés comme exemples du style cherché |
| 11 | Runeterra (LoL, Arcane, Legends of Runeterra) | 1 | I×1 | Art de Runeterra perçu comme « plus semi-réaliste stylisé et plus compatible avec le manga shōnen » |
| 11 | Tetsuya Nomura / Kingdom Hearts (style de personnages) | 1 | I×1 | « Artiste non loraisé mais que j'aime bien : Jomaro Kindred, Joe Madureira, Tetsuya Nomura » |

### Visuel : chara-design et tenues (pôle A3)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Radiant / Fabula Fantasia (Tony Valente) | 7 | D×1 · U×2 | « Archaïque mais pas trop » (décidé), inspiré de Radiant et de Runeterra ; Emprunt de tenue : « style copié/inspiré de Radiant » ; Fabula Fantasia : tenue de Brann (« moins claire ») |
| 2 | Runeterra (LoL, Arcane, Legends of Runeterra) | 5 | D×1 · U×1 | « Archaïque mais pas trop » (décidé), inspiré de Radiant et de Runeterra ; Emprunt de tenue : Academy Ekko, « tenue qui l'inspire le plus » (Cosmo) |
| 3 | Capcom / Street Fighter (jeux de combat) | 3 | U×1 · I×1 | Projet de jeu à 16 ans : « esthétique Capcom de Street Fighter », légèrement transféré dans tes mangas ; Cosmo, test de design : « street fighter Characters style » |
| 3 | Harry Potter (films et livres) | 3 | E×1 · I×1 | Harry Potter (films) : aspect visé esthétique et visuels ; Test de tenue « proche de Harry Potter », dont tu aimes beaucoup le rendu |
| 3 | Inspirations asiatiques (source non précisée) | 3 | E×1 · I×1 | Personnages d'inspiration asiatique ; Objets bouddhiques japonais |
| 6 | Raiponce / Tangled (Disney, 2010) | 2.5 | U×1 · H×1 | Harley : « pour moi son apparence ressemble à Raiponce de Tangled » — *hyp. IA : Raiponce est un conte des Grimm, donc allemand : cohérent avec ta règle France, Angleterre, Allemagne* |
| 7 | Dictionnaire infernal (Collin de Plancy) | 2 | U×1 | Gremory, Furfur, Marbas et Stolas sont choisis « surtout pour leur design et leur représentation artistique » |
| 7 | Jujutsu Kaisen | 2 | I×2 | Même test de tenue : « un peu de Jujutsu Kaisen » ; Cosmo, test de design : « Jujutsu Kaisen Character style » |
| 7 | Urban Rivals | 2 | U×1 | « des designs reconnaissables » ; designs du projet de jeu |
| 10 | Naruto | 1.5 | I×1 · H×1 | Cosmo, test de design : « shisui uchiha », « blue tunic, baggy pants, leg bandages » — *hyp. IA : Ch. 679 : tenues d'aventuriers de fantasy européenne (cotte de mailles, cape, chapeau de mage)* |
| 11 | Overwatch | 1 | I×1 | Designs du projet de jeu |
| 11 | Tetsuya Nomura / Kingdom Hearts (style de personnages) | 1 | I×1 | Cosmo, test de design : « kingdom hearts Character style » |
| 11 | The Boondocks | 1 | I×1 | Cosmo, test de design : « (the boondocks:1.2) » |

### Visuel : décors et ambiance (pôle A2)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Shrek | 11 | D×1 · E×6 · I×2 | Forêt de conte (décidée) : 3 des 5 images de décor sont des peintures de développement de Shrek ; Ambiance des lieux (envisagée) : peinture de développement de Shrek n° 1 (planche d'origine) ; Ambiance des lieux : peinture de développement de Shrek n° 2 … |
| 2 | La Princesse et la Grenouille (Disney, 2009) | 4 | E×2 | Ambiance des lieux : marais bleu, bateau coincé dans un cyprès (arbre de Mama Odie) ; Ambiance des lieux : salon du sorcier (« Dr. Duvalier », masques, bougies, cartes) |
| 3 | Naruto | 3 | E×1 · I×1 | Forêt de conte : 1 des 5 images (ch. 679) ; Ambiance des lieux (envisagée) : double page couleur du ch. 679 |
| 4 | Warcraft / Hearthstone | 2.5 | U×1 · H×1 | « grande influence sur l'esthétique […] surtout les paysages forestiers » — *hyp. IA : The Witchwood : forêt corrompue, loups-garous* |
| 5 | Contes européens (tradition) | 2 | U×1 | « atmosphère de conte européen au sens large (tous types de contes) » |
| 5 | Frère des ours (Disney, 2003) | 2 | E×1 | Ambiance des lieux : vallée, rivière et montagnes |
| 5 | Runeterra (LoL, Arcane, Legends of Runeterra) | 2 | U×1 | « Mais en vrai, l'esthétique d'Edenia est beaucoup plus proche de Runeterra » (dit à propos des paysages) |
| 8 | Occultisme et ésotérisme | 1 | I×1 | Cosmo, test de design : « (Occultism aesthetic), esoterism » |
| 9 | BioShock Infinite | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Le « type BioShock Infinite » de la zone industrielle est aussi un modèle visuel* |

### Narration : structure et intrigue (pôle D1-D2)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | The Stormlight Archive | 4 | U×1 · I×2 | Seule œuvre citée sans protagoniste central ; « peut avoir des répercussions sur comment [tu traites] Edenia » ; Narration différente de celle du Seigneur des anneaux ; « cette impression de maîtrise » |
| 2 | Hunter × Hunter | 3 | U×1 · I×1 | « l'exposition est une épreuve » (ton addendum) ; Pas de schéma répété ; exception tardive au protagoniste central |
| 2 | One Piece | 3 | U×1 · I×1 | « montrée, pas dite » (ton addendum) ; Schéma répété |
| 4 | Bleach | 2 | U×1 | Aspect visé : « la narration sur le Gotei 13 » |
| 5 | Game of Thrones | 1 | I×1 | Pas de protagoniste central (ta correction) |
| 5 | L'Attaque des Titans | 1 | I×1 | « impression de maîtrise » |
| 5 | Le Seigneur des anneaux | 1 | I×1 | Schéma répété |
| 5 | Légende arthurienne (Perceval, Vulgate) | 1 | I×1 | Vulgate : pas de protagoniste central |
| 5 | Worm | 1 | I×1 | « surtout à partir de l'arc 3, où ils font un braquage » ; « déconstruction du genre » |
| 10 | Quentin Tarantino | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Le lieu de convergence installé tôt (Inglourious Basterds)* |

### Narration : ton et émotion (pôle D3)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | The Hunters Guild: Red Hood | 3 | U×1 · I×1 | Ton visé « plus proche de Red Hood / HxH que de FMA » ; Relecture de contes (associée à Shrek, 3 oct.) |
| 2 | Hunter × Hunter | 2 | U×1 | Ton visé « plus proche de Red Hood / HxH que de FMA » |
| 3 | Game of Thrones | 1 | I×1 | « plus sérieux » |
| 3 | L'Attaque des Titans | 1 | I×1 | « tellement différent » ; « plus sérieux » |
| 3 | Quentin Tarantino | 1 | I×1 | « c'est plus Tarantino, son style et sa filmographie complète » (l'élément visé n'est pas précisé ; rangé ici par l'IA) |
| 3 | Shrek | 1 | I×1 | Relecture de contes (3 oct.) |
| 3 | The Stormlight Archive | 1 | I×1 | « ancré dans le réel (grounded) et réaliste, avec des enjeux élevés où l'on ressent la tension » |
| 3 | Watchmen | 1 | I×1 | Une de tes œuvres préférées ; Worm = « HxH + Watchmen » |
| 3 | Worm | 1 | I×1 | « rationnel et réaliste » |

### Action et combats (pôle E)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | The Stormlight Archive | 2 | U×1 | « des combats stratégiques » |
| 1 | Worm | 2 | U×1 | « J'adore les combats tactiques » |
| 3 | Capcom / Street Fighter (jeux de combat) | 1 | I×1 | Projet de jeu : personnages de mêlée à combos, légèrement transféré dans tes mangas |
| 3 | Gigantic | 1 | I×1 | Projet de jeu : modèle Gigantic (mêlée et tireurs) |
| 3 | Hunter × Hunter | 1 | I×1 | « À peu près tout ce que je dis sur Worm […] se retrouve dans Hunter x Hunter » |
| 6 | Catch (WWE, NJPW, AEW) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Dans ton répertoire (et les Huracan d'Urban Rivals), sans usage dit* |
| 6 | Dictionnaire infernal (Collin de Plancy) | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Mélye : l'épée bat l'enchantement (rejoint le plafond 1860)* |
| 6 | Films d'arts martiaux | 0.5 | H×1 | *(hypothèse IA seulement)* — *hyp. IA : Dans ton répertoire, sans usage dit* |

### Poids biographique : ce que tu dis de toi (hors œuvre)

| Rang | Influence | Score | Détail | Preuves principales |
|---:|---|---:|---|---|
| 1 | Warcraft / Hearthstone | 5 | U×2 · I×1 | « t'a donné l'envie de créer cette œuvre de fantasy » ; « grande influence sur l'esthétique d'Edenia » ; Environ huit ans de jeu (2015-2023) |
| 2 | Fondation SCP (dont la Chicago Spirit) | 2 | U×1 | « source d'inspiration première, celle qui relie énormément de choses » (surtout Arcana) |
| 2 | The Stormlight Archive | 2 | U×1 | Rangé dans les « inspirations majeures » |
| 2 | Urban Rivals | 2 | U×1 | « une énorme source d'inspiration » ; « une grande part d'influence » |
| 2 | Worm | 2 | U×1 | Rangé dans les « inspirations majeures » |
| 6 | Capcom / Street Fighter (jeux de combat) | 1 | I×1 | Projet de jeu vers 16 ans |
| 6 | H. P. Lovecraft | 1 | I×1 | « mon auteur de romans préféré » |
| 6 | Hunter × Hunter | 1 | I×1 | A détrôné One Piece vers 14 ans |
| 6 | L'Attaque des Titans | 1 | I×1 | « passé devant » |
| 6 | One Piece | 1 | I×1 | Manga préféré vers 11 ans |
| 6 | Watchmen | 1 | I×1 | « une de mes œuvres préférées » |

### Synthèse par pôle de ta grille (pôle D toujours présent)

| Pôle | 1ᵉʳ | 2ᵉ | 3ᵉ | 4ᵉ | 5ᵉ |
|---|---|---|---|---|---|
| **D — Narration / Scénario** | Hunter × Hunter (5) | The Stormlight Archive (5) | One Piece (3) | The Hunters Guild: Red Hood (3) | Bleach (2) |
| **C — Personnages** | Harry Potter (films et livres) (5) | Hunter × Hunter (2.5) | Légende arthurienne (Perceval, Vulgate) (2.5) | Ben 10 (2) | Fullmetal Alchemist (2) |
| **A — Visuel** | Shrek (11) | Runeterra (LoL, Arcane, Legends of Runeterra) (8) | Quirkilicious (Drake Tsui) (7) | Radiant / Fabula Fantasia (Tony Valente) (7) | Naruto (6.5) |
| **B — Monde / Système** | Dictionnaire infernal (Collin de Plancy) (15) | Folklore français (carte « Mythical Beasts of France ») (14) | Légende arthurienne (Perceval, Vulgate) (10) | Runeterra (LoL, Arcane, Legends of Runeterra) (9.5) | Fullmetal Alchemist (6) |
| **E — Action / Tactique** | The Stormlight Archive (2) | Worm (2) | Capcom / Street Fighter (jeux de combat) (1) | Gigantic (1) | Hunter × Hunter (1) |

### Classement général sur l'œuvre (somme des 12 éléments, hors biographie)

| Rang | Influence | Score total | Nombre d'éléments touchés (sur 12) | Éléments |
|---:|---|---:|---:|---|
| 1 | Runeterra (LoL, Arcane, Legends of Runeterra) | 19.5 | 7 | MONDE, TECH, SOCIETE, PERSO, TRAIT, CHARA, DECORS |
| 2 | Dictionnaire infernal (Collin de Plancy) | 17.5 | 5 | MATIERE, SOCIETE, POUVOIRS, CHARA, ACTION |
| 3 | Folklore français (carte « Mythical Beasts of France ») | 14 | 2 | MONDE, MATIERE |
| 4 | Légende arthurienne (Perceval, Vulgate) | 13.5 | 6 | MONDE, MATIERE, SOCIETE, POUVOIRS, PERSO, NARR |
| 5 | Shrek | 13 | 3 | MONDE, DECORS, TON |
| 6 | Hunter × Hunter | 10.5 | 6 | SOCIETE, POUVOIRS, PERSO, NARR, TON, ACTION |
| 6 | Naruto | 10.5 | 6 | TECH, POUVOIRS, PERSO, TRAIT, CHARA, DECORS |
| 8 | The Stormlight Archive | 10 | 5 | MONDE, PERSO, NARR, TON, ACTION |
| 9 | Harry Potter (films et livres) | 9 | 3 | SOCIETE, PERSO, CHARA |
| 9 | Radiant / Fabula Fantasia (Tony Valente) | 9 | 3 | TECH, SOCIETE, CHARA |
| 11 | Fullmetal Alchemist | 8 | 3 | MONDE, POUVOIRS, PERSO |
| 12 | One Piece | 7 | 4 | TECH, POUVOIRS, PERSO, NARR |
| 12 | Bleach | 7 | 3 | SOCIETE, POUVOIRS, NARR |
| 12 | Quirkilicious (Drake Tsui) | 7 | 1 | TRAIT |
| 15 | Occultisme et ésotérisme | 6.5 | 4 | MONDE, TECH, MATIERE, DECORS |
| 15 | Jujutsu Kaisen | 6.5 | 3 | POUVOIRS, TRAIT, CHARA |
| 15 | La Princesse et la Grenouille (Disney, 2009) | 6.5 | 3 | MONDE, MATIERE, DECORS |
| 18 | Warcraft / Hearthstone | 6 | 4 | MONDE, SOCIETE, PERSO, DECORS |
| 18 | Worm | 6 | 4 | PERSO, NARR, TON, ACTION |
| 18 | BioShock Infinite | 6 | 3 | MONDE, TECH, DECORS |

### Test de robustesse du classement général (8 premiers)

| Variante | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| Barème de base (D3 E2 U2 I1 H0,5, plafond 3) | Runeterra | Dictionnaire infernal | Folklore français | Légende arthurienne | Shrek | Hunter × Hunter | Naruto | The Stormlight Archive |
| Sans les hypothèses de l'IA | Runeterra | Dictionnaire infernal | Folklore français | Shrek | Légende arthurienne | Hunter × Hunter | Naruto | The Stormlight Archive |
| Décisions très lourdes (D5 E2 U2 I1) | Runeterra | Dictionnaire infernal | Légende arthurienne | Shrek | Folklore français | Radiant / Fabula Fantasia | Hunter × Hunter | Naruto |
| Barème plat (toute preuve = 1) | Runeterra | Dictionnaire infernal | Folklore français | Shrek | Hunter × Hunter | Naruto | The Stormlight Archive | Harry Potter |
| Sans plafond | Runeterra | Shrek | Dictionnaire infernal | Folklore français | Légende arthurienne | Hunter × Hunter | Naruto | The Stormlight Archive |

### Repoussoirs (non comptés dans les scores)

| Influence | Ce qu'on évite | Source |
|---|---|---|
| Radiant / Fabula Fantasia (Tony Valente) | « distance à maintenir » sur les autres aspects, non précisés (6 oct. ; « ne porte plus nécessairement sur tout ») ; se détacher de Radiant sur le plan arthurien (décidé, portée non précisée) | YAML |
| The Seven Deadly Sins | se détacher de SDS sur le plan arthurien (décidé, portée non précisée) | YAML |
| Fullmetal Alchemist | cadre militaire : « distance à maintenir », « pour l'instant » (7 oct.) ; ton visé « plus proche de Red Hood / HxH que de FMA » | YAML |
| The Hunters Guild: Red Hood | « explication par l'antagoniste (critiquée) » | structures… §2 |
| Warcraft / Hearthstone | Warcraft perçu comme « hard rock / solennel » (une perception, pas un rejet) | Benchmark Oeuvre/01_CONTEXTE_ET_SUITE |