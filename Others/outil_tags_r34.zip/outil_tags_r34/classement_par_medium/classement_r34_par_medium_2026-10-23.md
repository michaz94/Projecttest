# Classement rule34 par médium : personnages féminins

*Relevé du 23 octobre 2026. Base : les 172 personnages féminins de `selection_172_personnages_feminins_2026-10-23.csv`, relevés dans la liste des tags rule34.xxx jusqu'à la page 250 (environ 9 600 publications au minimum). Les compteurs sont ceux de `comparaison_sites_195_personnages_2026-10-23.csv`, mis à jour le 23 octobre.*

**Règle de classement :** chaque personnage est rangé selon le médium où il a été créé. C'est généralement celui de sa franchise ; quand ce n'est pas le cas, c'est indiqué dans la colonne Note. L'Animanga regroupe le manga, l'anime et les light novels.

**Furry :** ce classement est séparé des autres. Les personnages qui y figurent sont retirés de leur médium d'origine, qui reste indiqué dans la colonne Note. Deux critères sont exigés : (1) le personnage est un animal anthropomorphe ou une créature animale (y compris les poneys de My Little Pony, les animatroniques animaux de Five Nights at Freddy's et les insectes de Hollow Knight) ; (2) son indice e621 est d'au moins 2. L'indice e621 compare la part du personnage sur e621, le booru spécialisé furry, à sa part sur rule34. Les indices observés présentent un écart net : les 22 personnages retenus sont entre 2,33 et 8,02, tous les autres sont à 1,45 ou moins. Seule exception, Midna (indice 2,74) n'est pas un animal ; elle reste en jeux vidéo. Les personnages humains à oreilles animales (Ahri, Miruko, Blake…) ne sont pas comptés comme furry.

## Synthèse

| Médium | Personnages | Publications cumulées | Part | Moyenne par personnage |
|---|---|---|---|---|
| Animanga | 53 | 1 061 402 | 32.1 % | 20 026 |
| Jeux vidéo | 65 | 1 231 198 | 37.2 % | 18 942 |
| Comics | 11 | 198 407 | 6.0 % | 18 037 |
| Cartoons / films d'animation occidentaux | 20 | 282 855 | 8.6 % | 14 143 |
| Furry | 22 | 489 929 | 14.8 % | 22 270 |
| Hors des 4 médiums | 1 | 41 502 | 1.3 % | 41 502 |
| **Total** | **172** | **3 305 293** | 100 % | |

## Animanga (53)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 1 | Nami | One Piece | 58 235 |  |
| 2 | 5 | Hinata Hyûga | Naruto | 44 131 |  |
| 3 | 11 | Tsunade | Naruto | 40 352 |  |
| 4 | 12 | Sakura Haruno | Naruto | 40 007 |  |
| 5 | 17 | Nico Robin | One Piece | 35 054 |  |
| 6 | 18 | Makima | Chainsaw Man | 34 359 |  |
| 7 | 19 | Ochako Uraraka | My Hero Academia | 33 611 |  |
| 8 | 22 | Yor Forger (Briar) | Spy×Family | 31 098 |  |
| 9 | 24 | C-18 | Dragon Ball | 30 855 |  |
| 10 | 27 | Marin Kitagawa | My Dress-Up Darling | 28 918 |  |
| 11 | 28 | Frieren | Frieren | 28 736 |  |
| 12 | 29 | Miruko | My Hero Academia | 26 875 |  |
| 13 | 36 | Tatsumaki | One Punch Man | 24 163 |  |
| 14 | 42 | Nagatoro | Arrête de me chauffer, Nagatoro | 22 645 |  |
| 15 | 46 | Yoruichi | Bleach | 21 905 |  |
| 16 | 47 | Bulma | Dragon Ball | 21 867 |  |
| 17 | 54 | Boa Hancock | One Piece | 19 864 |  |
| 18 | 55 | Aqua | Konosuba | 19 835 |  |
| 19 | 56 | Fern | Frieren | 19 564 |  |
| 20 | 62 | Orihime Inoue | Bleach | 19 204 |  |
| 21 | 63 | Asuka Langley | Evangelion | 19 150 |  |
| 22 | 65 | Momo Yaoyorozu | My Hero Academia | 18 694 |  |
| 23 | 67 | Lucy Heartfilia | Fairy Tail | 18 248 |  |
| 24 | 72 | Rangiku Matsumoto | Bleach | 17 738 |  |
| 25 | 74 | Mina Ashido | My Hero Academia | 17 367 |  |
| 26 | 75 | Erza Scarlet | Fairy Tail | 17 357 |  |
| 27 | 76 | Rias Gremory | High School DxD | 17 236 |  |
| 28 | 82 | Ino Yamanaka | Naruto | 16 445 |  |
| 29 | 83 | Power | Chainsaw Man | 16 178 |  |
| 30 | 86 | Mitsuri Kanroji | Demon Slayer | 15 748 |  |
| 31 | 91 | Himiko Toga | My Hero Academia | 15 262 |  |
| 32 | 93 | Megumin | KonoSuba | 15 204 |  |
| 33 | 101 | Nobara Kugisaki | Jujutsu Kaisen | 14 758 |  |
| 34 | 103 | Fubuki | One-Punch Man | 14 448 |  |
| 35 | 104 | Chichi | Dragon Ball | 14 435 |  |
| 36 | 106 | Shinobu Kocho | Demon Slayer | 14 346 |  |
| 37 | 111 | Sarada Uchiha | Naruto / Boruto | 13 790 |  |
| 38 | 114 | Ryuko Matoi | Kill la Kill | 13 694 |  |
| 39 | 115 | Mikasa Ackerman | L'Attaque des Titans | 13 546 |  |
| 40 | 117 | Tsuyu Asui | My Hero Academia | 13 001 |  |
| 41 | 122 | Rukia Kuchiki | Bleach | 12 548 |  |
| 42 | 131 | Darkness | KonoSuba | 11 769 |  |
| 43 | 132 | Emilia | Re:Zero | 11 694 |  |
| 44 | 133 | Yamato | One Piece | 11 681 |  |
| 45 | 134 | Jessie (Team Rocket) | Pokémon | 11 615 | créée dans l'anime Pokémon (1997), absente des jeux d'origine |
| 46 | 136 | Shouko Komi | Komi cherche ses mots | 11 482 |  |
| 47 | 138 | Momo Ayase | Dandadan | 11 272 |  |
| 48 | 142 | Akeno Himejima | High School DxD | 10 952 |  |
| 49 | 149 | Albedo | Overlord | 10 586 |  |
| 50 | 160 | Kushina Uzumaki | Naruto | 10 276 |  |
| 51 | 164 | Videl | Dragon Ball | 9 995 |  |
| 52 | 168 | Rei Ayanami | Neon Genesis Evangelion | 9 879 |  |
| 53 | 170 | Rem | Re:Zero | 9 730 |  |

## Jeux vidéo (65)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 2 | Tifa Lockhart | Final Fantasy VII | 54 497 |  |
| 2 | 3 | Princesse Peach | Super Mario | 50 540 |  |
| 3 | 6 | 2B | NieR: Automata | 43 042 |  |
| 4 | 10 | Chun-Li | Street Fighter | 40 998 |  |
| 5 | 14 | Princesse Zelda | The Legend of Zelda | 39 552 |  |
| 6 | 15 | Samus Aran | Metroid | 37 241 |  |
| 7 | 16 | D.Va | Overwatch | 35 755 |  |
| 8 | 20 | Lara Croft | Tomb Raider | 32 857 |  |
| 9 | 21 | Widowmaker | Overwatch | 31 965 |  |
| 10 | 25 | Mercy | Overwatch | 30 457 |  |
| 11 | 26 | Ahri | League of Legends | 29 823 |  |
| 12 | 33 | Raiden Shogun | Genshin Impact | 25 746 |  |
| 13 | 34 | Jill Valentine | Resident Evil | 25 547 |  |
| 14 | 35 | Harmonie (Rosalina) | Super Mario | 24 439 |  |
| 15 | 39 | Ada Wong | Resident Evil | 23 269 |  |
| 16 | 40 | Tracer | Overwatch | 23 061 |  |
| 17 | 44 | Mai Shiranui | Fatal Fury / King of Fighters | 22 129 |  |
| 18 | 45 | Cynthia | Pokémon | 22 055 |  |
| 19 | 51 | Daisy | Super Mario | 20 747 |  |
| 20 | 52 | Ciri | The Witcher | 20 511 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 21 | 60 | Artoria Pendragon | Fate | 19 239 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo |
| 22 | 61 | Girlfriend | Friday Night Funkin' | 19 238 |  |
| 23 | 64 | Cammy | Street Fighter | 18 733 |  |
| 24 | 68 | Jinx | League of Legends / Arcane | 18 139 | personnage du jeu (2013), repris dans la série Arcane |
| 25 | 69 | May (Flora en VF) | Pokémon | 18 103 |  |
| 26 | 70 | Misty (Ondine en VF) | Pokémon | 18 081 | personnage des jeux Pokémon Rouge/Vert (1996), aussi héroïne de l'anime |
| 27 | 77 | Juri Han | Street Fighter | 17 122 |  |
| 28 | 80 | Yae Miko | Genshin Impact | 16 470 |  |
| 29 | 81 | Ganyu | Genshin Impact | 16 464 |  |
| 30 | 85 | Aerith Gainsborough | Final Fantasy VII | 15 795 |  |
| 31 | 88 | Rosa | Pokémon | 15 544 |  |
| 32 | 89 | Hilda | Pokémon | 15 536 |  |
| 33 | 90 | Lumine | Genshin Impact | 15 313 |  |
| 34 | 92 | Pharah | Overwatch | 15 241 |  |
| 35 | 96 | Midna | The Legend of Zelda | 15 085 | indice e621 2,74 mais personnage non animal (Twili) : laissée en jeux vidéo |
| 36 | 102 | Mona | Genshin Impact | 14 643 |  |
| 37 | 108 | Hu Tao | Genshin Impact | 14 051 |  |
| 38 | 109 | Dawn (Aurore en VF) | Pokémon | 14 047 |  |
| 39 | 110 | Mei | Overwatch | 13 901 |  |
| 40 | 116 | Pyra | Xenoblade Chronicles 2 | 13 518 |  |
| 41 | 118 | Yennefer | The Witcher | 12 855 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 42 | 123 | Monika | Doki Doki Literature Club | 12 511 |  |
| 43 | 124 | Claire Redfield | Resident Evil | 12 503 |  |
| 44 | 128 | Shantae | Shantae | 11 862 |  |
| 45 | 129 | Elizabeth | BioShock Infinite | 11 857 |  |
| 46 | 130 | Lady Dimitrescu | Resident Evil Village | 11 843 |  |
| 47 | 135 | Asuna | Blue Archive | 11 607 |  |
| 48 | 139 | Morrigan Aensland | Darkstalkers | 11 256 |  |
| 49 | 141 | Ashley Graham | Resident Evil 4 | 11 186 |  |
| 50 | 143 | Byleth (version féminine) | Fire Emblem | 10 952 |  |
| 51 | 144 | Triss Merigold | The Witcher | 10 951 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 52 | 148 | Ellie | The Last of Us | 10 767 |  |
| 53 | 150 | Eula | Genshin Impact | 10 554 |  |
| 54 | 151 | Ann Takamaki | Persona 5 | 10 520 |  |
| 55 | 153 | Nessa (Donna en VF) | Pokémon | 10 468 |  |
| 56 | 154 | Furina | Genshin Impact | 10 422 |  |
| 57 | 156 | Liara T'Soni | Mass Effect | 10 343 |  |
| 58 | 157 | Jane Doe | Zenless Zone Zero | 10 339 |  |
| 59 | 159 | Marina | Splatoon | 10 290 |  |
| 60 | 161 | Sombra | Overwatch | 10 222 |  |
| 61 | 163 | Shadowheart (Cœur-Ombre) | Baldur's Gate 3 | 10 031 |  |
| 62 | 165 | Kiriko | Overwatch | 9 984 |  |
| 63 | 166 | Reimu Hakurei | Touhou Project | 9 981 |  |
| 64 | 169 | Ellen Joe | Zenless Zone Zero | 9 743 |  |
| 65 | 171 | Mythra (Homura, autre forme de Pyra) | Xenoblade Chronicles 2 | 9 657 |  |

## Comics (11)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 13 | Raven | DC Comics | 39 701 | créée dans les comics (1980), très popularisée par la série Teen Titans |
| 2 | 41 | Wonder Woman | DC Comics | 22 972 |  |
| 3 | 48 | Starfire | DC Comics | 21 783 | créée dans les comics (1980), très popularisée par la série Teen Titans |
| 4 | 53 | Emma Frost | Marvel | 20 038 |  |
| 5 | 59 | Gwen Stacy | Marvel | 19 315 |  |
| 6 | 95 | Black Cat (Felicia Hardy) | Marvel | 15 114 |  |
| 7 | 105 | Supergirl | DC Comics | 14 415 |  |
| 8 | 113 | Power Girl | DC Comics | 13 709 |  |
| 9 | 147 | Femme invisible (Sue Storm) | Marvel (Les 4 Fantastiques) | 10 813 |  |
| 10 | 155 | Black Widow (Natasha Romanoff) | Marvel | 10 382 |  |
| 11 | 162 | Catwoman (Selina Kyle) | DC Comics | 10 165 |  |

## Cartoons / films d'animation occidentaux (20)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 32 | Harley Quinn | DC Comics | 25 769 | créée dans Batman : la série animée (1992), intégrée aux comics ensuite |
| 2 | 49 | Gwen Tennyson | Ben 10 | 21 459 |  |
| 3 | 71 | Yang Xiao Long | RWBY | 17 949 | RWBY : websérie américaine (Rooster Teeth) au style anime |
| 4 | 84 | Helen Parr (Elastigirl) | Les Indestructibles | 15 949 |  |
| 5 | 87 | Ruby Rose | RWBY | 15 698 |  |
| 6 | 97 | Velma Dinkley | Scooby-Doo | 14 933 |  |
| 7 | 99 | Elsa | La Reine des neiges | 14 888 |  |
| 8 | 100 | Ahsoka Tano | Star Wars | 14 806 | créée pour le film d'animation The Clone Wars (2008) |
| 9 | 107 | Weiss Schnee | RWBY | 14 098 |  |
| 10 | 112 | Korra | La Légende de Korra | 13 753 |  |
| 11 | 120 | Pomni | The Amazing Digital Circus | 12 589 |  |
| 12 | 121 | Azula | Avatar, le dernier maître de l'air | 12 586 |  |
| 13 | 125 | Kim Possible | Kim Possible | 12 436 |  |
| 14 | 126 | Jessica Rabbit | Qui veut la peau de Roger Rabbit | 12 176 | apparaît d'abord dans un roman (1981), rendue célèbre par le film de 1988 |
| 15 | 127 | Katara | Avatar, le dernier maître de l'air | 12 083 |  |
| 16 | 145 | Blake Belladonna | RWBY | 10 876 |  |
| 17 | 146 | Chel | La Route d'Eldorado (DreamWorks) | 10 864 |  |
| 18 | 158 | Charlie Morningstar | Hazbin Hotel | 10 328 |  |
| 19 | 167 | Princesse Chewing-gum | Adventure Time | 9 973 |  |
| 20 | 172 | Toph Beifong | Avatar, le dernier maître de l'air | 9 642 |  |

## Furry (22)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 4 | Rouge the Bat | Sonic the Hedgehog | 45 404 | médium d'origine : Jeux vidéo ; e621 34625 publications, indice e621 3.82 |
| 2 | 7 | Loona | Helluva Boss | 43 037 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32882 publications, indice e621 3.83 |
| 3 | 8 | Amy Rose | Sonic the Hedgehog | 41 819 | médium d'origine : Jeux vidéo ; e621 26097 publications, indice e621 3.13 |
| 4 | 23 | Twilight Sparkle | My Little Pony | 30 889 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 42232 publications, indice e621 6.85 |
| 5 | 30 | Fluttershy | My Little Pony | 26 441 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32442 publications, indice e621 6.14 |
| 6 | 31 | Judy Hopps | Zootopie | 26 153 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 41872 publications, indice e621 8.02 |
| 7 | 37 | Toriel | Undertale | 24 135 | médium d'origine : Jeux vidéo ; e621 22899 publications, indice e621 4.75 |
| 8 | 38 | Rainbow Dash | My Little Pony | 23 921 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 31071 publications, indice e621 6.5 |
| 9 | 43 | Rarity | My Little Pony | 22 555 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 27460 publications, indice e621 6.1 |
| 10 | 50 | Marie (Isabelle) | Animal Crossing | 20 827 | médium d'origine : Jeux vidéo ; e621 18943 publications, indice e621 4.55 |
| 11 | 57 | Pinkie Pie | My Little Pony | 19 482 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 26743 publications, indice e621 6.87 |
| 12 | 58 | Krystal | Star Fox | 19 385 | médium d'origine : Jeux vidéo ; e621 19983 publications, indice e621 5.16 |
| 13 | 66 | Applejack | My Little Pony | 18 411 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 23052 publications, indice e621 6.27 |
| 14 | 73 | Ankha | Animal Crossing | 17 722 | médium d'origine : Jeux vidéo ; e621 11936 publications, indice e621 3.37 |
| 15 | 78 | Princesse Celestia | My Little Pony | 17 046 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 22781 publications, indice e621 6.69 |
| 16 | 79 | Princesse Luna | My Little Pony | 16 859 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 21739 publications, indice e621 6.46 |
| 17 | 94 | Blaze the Cat | Sonic | 15 167 | médium d'origine : Jeux vidéo ; e621 12634 publications, indice e621 4.17 |
| 18 | 98 | Toy Chica | Five Nights at Freddy's | 14 895 | médium d'origine : Jeux vidéo ; e621 6923 publications, indice e621 2.33 |
| 19 | 119 | Hornet | Hollow Knight | 12 628 | médium d'origine : Jeux vidéo ; e621 9003 publications, indice e621 3.57 |
| 20 | 137 | Roxanne Wolf | Five Nights at Freddy's | 11 401 | médium d'origine : Jeux vidéo ; e621 8703 publications, indice e621 3.82 |
| 21 | 140 | Vanilla | Sonic | 11 234 | médium d'origine : Jeux vidéo ; e621 8234 publications, indice e621 3.67 |
| 22 | 152 | Cream the Rabbit | Sonic | 10 518 | médium d'origine : Jeux vidéo ; e621 9983 publications, indice e621 4.75 |

## Hors des 4 médiums (1)

| # | Rang général (sur 172) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 9 | Hatsune Miku | Vocaloid | 41 502 | logiciel de synthèse vocale (mascotte), ni jeu ni anime à l'origine |
