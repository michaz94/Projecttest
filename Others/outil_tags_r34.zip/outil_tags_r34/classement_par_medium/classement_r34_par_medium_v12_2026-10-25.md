# Classement rule34 par médium : personnages féminins (v12, audit des doublons, pages 1-390)

*Relevés des 24 et 25 octobre 2026. Base : les 388 personnages féminins de `doublons/selection_388_dedupliquee_audit_2026-10-25.csv` (liste des tags rule34.xxx, pages 1 à 390, soit environ 5 000 publications au minimum). Compteurs du 24/10 pour les pages 1 à 330, du 25/10 pour les pages 331 à 390 ; audit complet des doublons : base = compteur du tag principal (liste des tags), plus le gain réel d’union (posts portant un alias ou une version sans le tag principal, mesurés par recherche négative) quand il dépasse 150.*

**Règle de classement :** chaque personnage est rangé selon le médium où il a été créé (exceptions indiquées en Note ; Raven et Starfire, créées dans les comics, sont rangées en dessins animés occidentaux à ta demande, pour la série Teen Titans de 2003). L'Animanga regroupe le manga, l'anime et les light novels.

**Furry :** classement séparé ; ses personnages sont retirés de leur médium d'origine (indiqué en Note). Critères : (1) animal anthropomorphe ou créature animale ; (2) indice e621 d'au moins 2 (part sur e621 rapportée à la part sur rule34). Midna (2,74), Poppy (2,60, yordle humanoïde), Felicia (2,28, femme-chat humanoïde) et Bowsette restent hors Furry (personnages humanoïdes).

## Synthèse

| Médium | Personnages | Publications cumulées | Part | Moyenne par personnage |
|---|---|---|---|---|
| Animanga | 99 | 1 393 921 | 28.8 % | 14 080 |
| Jeux vidéo | 169 | 1 959 781 | 40.5 % | 11 596 |
| Comics | 18 | 210 174 | 4.3 % | 11 676 |
| Cartoons / films d'animation occidentaux | 50 | 527 628 | 10.9 % | 10 553 |
| Furry | 43 | 641 765 | 13.3 % | 14 925 |
| Hors des 4 médiums | 9 | 101 207 | 2.1 % | 11 245 |
| **Total** | **388** | **4 834 476** | 100 % | |

## Animanga (99)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 1 | Nami | One Piece | 58 263 |  |
| 2 | 5 | Hinata Hyûga | Naruto | 44 141 |  |
| 3 | 11 | Tsunade | Naruto | 40 786 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 4 | 12 | Sakura Haruno | Naruto | 40 018 |  |
| 5 | 17 | Ochako Uraraka | My Hero Academia | 35 111 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 6 | 18 | Nico Robin | One Piece | 35 080 |  |
| 7 | 19 | Makima | Chainsaw Man | 34 383 |  |
| 8 | 21 | Yor Forger (Briar) | Spy×Family | 32 882 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 9 | 23 | Miruko | My Hero Academia | 31 266 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 10 | 25 | C-18 | Dragon Ball | 30 868 |  |
| 11 | 28 | Marin Kitagawa | My Dress-Up Darling | 29 857 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 29 | Frieren | Frieren | 28 757 |  |
| 13 | 36 | Tatsumaki | One Punch Man | 24 182 |  |
| 14 | 42 | Nagatoro | Arrête de me chauffer, Nagatoro | 22 674 |  |
| 15 | 45 | Bulma | Dragon Ball | 22 100 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 16 | 47 | Yoruichi | Bleach | 21 936 |  |
| 17 | 55 | Boa Hancock | One Piece | 19 886 |  |
| 18 | 56 | Aqua | Konosuba | 19 839 |  |
| 19 | 59 | Fern | Frieren | 19 574 |  |
| 20 | 62 | Orihime Inoue | Bleach | 19 208 |  |
| 21 | 63 | Asuka Langley | Evangelion | 19 150 |  |
| 22 | 64 | Momo Yaoyorozu | My Hero Academia | 18 872 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 23 | 67 | Lucy Heartfilia | Fairy Tail | 18 255 |  |
| 24 | 72 | Rangiku Matsumoto | Bleach | 17 804 |  |
| 25 | 73 | Mina Ashido | My Hero Academia | 17 795 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 26 | 75 | Erza Scarlet | Fairy Tail | 17 363 |  |
| 27 | 76 | Rias Gremory | High School DxD | 17 248 |  |
| 28 | 80 | Mitsuri Kanroji | Demon Slayer | 16 655 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 29 | 83 | Ino Yamanaka | Naruto | 16 449 |  |
| 30 | 85 | Power | Chainsaw Man | 16 185 |  |
| 31 | 88 | Himiko Toga | My Hero Academia | 15 704 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 32 | 94 | Megumin | KonoSuba | 15 208 |  |
| 33 | 98 | Nobara Kugisaki | Jujutsu Kaisen | 14 940 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 34 | 104 | Shinobu Kocho | Demon Slayer | 14 569 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 35 | 105 | Chichi | Dragon Ball | 14 479 |  |
| 36 | 106 | Fubuki | One-Punch Man | 14 451 |  |
| 37 | 113 | Sarada Uchiha | Naruto / Boruto | 13 790 |  |
| 38 | 115 | Ryuko Matoi | Kill la Kill | 13 701 |  |
| 39 | 116 | Mikasa Ackerman | L'Attaque des Titans | 13 552 |  |
| 40 | 117 | Tsuyu Asui | My Hero Academia | 13 349 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 41 | 122 | Rukia Kuchiki | Bleach | 12 551 |  |
| 42 | 131 | Darkness | KonoSuba | 11 774 |  |
| 43 | 132 | Emilia | Re:Zero | 11 705 |  |
| 44 | 133 | Yamato | One Piece | 11 696 |  |
| 45 | 134 | Jessie (Team Rocket) | Pokémon | 11 620 | créée dans l'anime Pokémon (1997), absente des jeux d'origine |
| 46 | 136 | Shouko Komi | Komi cherche ses mots | 11 489 |  |
| 47 | 139 | Momo Ayase | Dandadan | 11 292 |  |
| 48 | 143 | Akeno Himejima | High School DxD | 11 126 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 49 | 149 | Kushina Uzumaki | Naruto | 10 657 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 50 | 152 | Albedo | Overlord | 10 587 |  |
| 51 | 163 | Asuna Yuuki | Sword Art Online | 10 270 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 52 | 167 | Rei Ayanami | Neon Genesis Evangelion | 10 047 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 53 | 170 | Videl | Dragon Ball | 9 996 |  |
| 54 | 175 | Nezuko Kamado | Demon Slayer | 9 754 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 55 | 177 | Rem | Re:Zero | 9 733 |  |
| 56 | 178 | Ilulu | Miss Kobayashi's Dragon Maid | 9 655 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 57 | 185 | Rebecca | Cyberpunk: Edgerunners | 9 371 | créée pour l'anime Cyberpunk: Edgerunners (2022), univers du jeu Cyberpunk 2077 |
| 58 | 187 | Reze | Chainsaw Man | 9 293 |  |
| 59 | 189 | Satsuki Kiryuin | Kill la Kill | 9 215 |  |
| 60 | 191 | Kobeni Higashiyama | Chainsaw Man | 9 184 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 61 | 206 | Lucoa (Quetzalcoatl) | Miss Kobayashi's Dragon Maid | 8 672 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 62 | 211 | Hana Uzaki | Uzaki-chan veut traîner ! | 8 621 |  |
| 63 | 215 | Stocking Anarchy | Panty & Stocking with Garterbelt | 8 450 |  |
| 64 | 223 | Magicienne des Ténèbres (Dark Magician Girl) | Yu-Gi-Oh! | 8 007 | apparaît dans le manga Yu-Gi-Oh! (1996) et le jeu de cartes, classée en animanga |
| 65 | 228 | Usagi Tsukino (Sailor Moon) | Sailor Moon | 7 906 | 14 ans au début de la série ; union avec le tag sailor_moon (son identité de guerrière) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 66 | 233 | Noelle Silva | Black Clover | 7 773 | 15 ans au début de la série |
| 67 | 244 | Kyoka Jiro | My Hero Academia | 7 493 | lycéenne (15-16 ans), comme Ochaco et Momo |
| 68 | 245 | Kefla | Dragon Ball | 7 491 | fusion de Kale et Caulifla, créée pour Dragon Ball Super (2017) |
| 69 | 247 | Zero Two | Darling in the Franxx | 7 392 | anime original (2018, Trigger / A-1 Pictures) |
| 70 | 250 | Nino Nakano | The Quintessential Quintuplets | 7 314 |  |
| 71 | 251 | Maki Zen’in | Jujutsu Kaisen | 7 312 | élève de 2e année de l'école d'exorcisme (16 ans) |
| 72 | 255 | Hitori Gotō | Bocchi the Rock! | 7 250 | lycéenne (15-16 ans) |
| 73 | 261 | Caulifla | Dragon Ball | 7 120 |  |
| 74 | 269 | Temari | Naruto | 7 018 |  |
| 75 | 270 | Nejire Hado | My Hero Academia | 7 003 |  |
| 76 | 280 | Tsuki Uzaki (mère de Hana) | Uzaki-chan veut traîner ! | 6 896 | mère de Hana Uzaki |
| 77 | 282 | Yoko Littner | Gurren Lagann | 6 881 |  |
| 78 | 305 | Hanabi Hyūga | Naruto | 6 341 | petite sœur de Hinata : enfant dans Naruto, adolescente dans The Last et Boruto |
| 79 | 313 | Misato Katsuragi | Evangelion | 6 164 |  |
| 80 | 315 | Tenten | Naruto | 6 132 | adolescente dans Naruto, adulte dans Boruto |
| 81 | 318 | Hestia | DanMachi | 6 063 | déesse du light novel DanMachi (2013), connue surtout par l'anime |
| 82 | 322 | Mitsuki Bakugo | My Hero Academia | 5 948 | mère de Katsuki Bakugo |
| 83 | 323 | Kallen Stadtfeld (Kozuki) | Code Geass | 5 920 |  |
| 84 | 328 | Lucy (Lucyna Kushinada) | Cyberpunk: Edgerunners | 5 815 | créée pour l'anime Cyberpunk: Edgerunners (2022), univers du jeu Cyberpunk 2077 |
| 85 | 330 | Shuuko Komi (mère de Shouko) | Komi cherche ses mots | 5 778 | mère de Shouko Komi |
| 86 | 334 | Esdeath | Akame ga Kill! | 5 750 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 87 | 337 | Ghislaine Dedoldia | Mushoku Tensei | 5 699 | light novel Mushoku Tensei (web novel 2012), connue surtout par l'anime |
| 88 | 344 | Chika Fujiwara | Kaguya-sama: Love is War | 5 609 | lycéenne |
| 89 | 348 | Suguha Kirigaya (Leafa) | Sword Art Online | 5 543 | union avec leafa (son avatar dans ALfheim Online) ; collégienne puis lycéenne (15 ans) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 90 | 349 | Samui | Naruto | 5 534 |  |
| 91 | 351 | Miku Nakano | The Quintessential Quintuplets | 5 515 | lycéenne |
| 92 | 358 | Tohru | Miss Kobayashi's Dragon Maid | 5 408 | dragonne sous forme humaine ; indice e621 0,44 (470), non furry |
| 93 | 360 | Annie Leonhart | L'Attaque des Titans | 5 392 | 15 ans au début de la série |
| 94 | 366 | Kaguya Shinomiya | Kaguya-sama: Love is War | 5 313 | lycéenne |
| 95 | 367 | Jolyne Cujoh (Kujo) | JoJo's Bizarre Adventure | 5 302 |  |
| 96 | 369 | Retsu Unohana | Bleach | 5 262 |  |
| 97 | 372 | Ranma-chan (Ranma sous sa forme féminine) | Ranma ½ | 5 228 | forme féminine de Ranma Saotome (manga de Rumiko Takahashi, 1987) ; le tag ranma_saotome (genre non défini) n'est pas additionné |
| 98 | 378 | Alisa Mikhailovna Kujou (Alya) | Roshidere | 5 173 | lycéenne ; light novel Roshidere (2021), connue surtout par l'anime |
| 99 | 382 | Seiko Ayase (grand-mère de Momo) | Dandadan | 5 088 | grand-mère de Momo Ayase |

## Jeux vidéo (169)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 2 | Tifa Lockhart | Final Fantasy VII | 54 505 |  |
| 2 | 3 | Princesse Peach | Super Mario | 50 552 |  |
| 3 | 7 | 2B | NieR: Automata | 43 048 |  |
| 4 | 10 | Chun-Li | Street Fighter | 41 013 |  |
| 5 | 13 | Princesse Zelda | The Legend of Zelda | 39 792 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 6 | 15 | Samus Aran | Metroid | 37 248 |  |
| 7 | 16 | D.Va | Overwatch | 35 763 |  |
| 8 | 20 | Lara Croft | Tomb Raider | 32 891 |  |
| 9 | 22 | Widowmaker | Overwatch | 31 976 |  |
| 10 | 26 | Mercy | Overwatch | 30 462 |  |
| 11 | 27 | Ahri | League of Legends | 29 877 |  |
| 12 | 33 | Raiden Shogun | Genshin Impact | 25 757 |  |
| 13 | 34 | Jill Valentine | Resident Evil | 25 551 |  |
| 14 | 35 | Harmonie (Rosalina) | Super Mario | 24 442 |  |
| 15 | 39 | Ada Wong | Resident Evil | 23 269 |  |
| 16 | 40 | Tracer | Overwatch | 23 060 |  |
| 17 | 44 | Mai Shiranui | Fatal Fury / King of Fighters | 22 135 |  |
| 18 | 46 | Cynthia | Pokémon | 22 058 |  |
| 19 | 51 | Daisy | Super Mario | 20 747 |  |
| 20 | 52 | Artoria Pendragon | Fate | 20 563 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 21 | 53 | Ciri | The Witcher | 20 518 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 22 | 61 | Girlfriend | Friday Night Funkin' | 19 251 |  |
| 23 | 65 | Cammy | Street Fighter | 18 735 |  |
| 24 | 68 | Jinx | League of Legends / Arcane | 18 144 | personnage du jeu (2013), repris dans la série Arcane |
| 25 | 69 | May (Flora en VF) | Pokémon | 18 104 |  |
| 26 | 70 | Misty (Ondine en VF) | Pokémon | 18 082 | personnage des jeux Pokémon Rouge/Vert (1996), aussi héroïne de l'anime |
| 27 | 77 | Juri Han | Street Fighter | 17 124 |  |
| 28 | 81 | Yae Miko | Genshin Impact | 16 483 |  |
| 29 | 82 | Ganyu | Genshin Impact | 16 468 |  |
| 30 | 87 | Aerith Gainsborough | Final Fantasy VII | 15 799 |  |
| 31 | 90 | Rosa | Pokémon | 15 546 |  |
| 32 | 91 | Hilda | Pokémon | 15 539 |  |
| 33 | 92 | Lumine | Genshin Impact | 15 314 |  |
| 34 | 93 | Pharah | Overwatch | 15 243 |  |
| 35 | 97 | Midna | The Legend of Zelda | 15 085 | indice e621 2,74 mais personnage non animal (Twili) : laissée en jeux vidéo |
| 36 | 103 | Mona | Genshin Impact | 14 667 |  |
| 37 | 107 | Pyra | Xenoblade Chronicles 2 | 14 259 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 38 | 109 | Hu Tao | Genshin Impact | 14 055 |  |
| 39 | 110 | Dawn (Aurore en VF) | Pokémon | 14 047 |  |
| 40 | 112 | Mei | Overwatch | 13 901 |  |
| 41 | 118 | Yennefer | The Witcher | 12 861 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 42 | 123 | Monika | Doki Doki Literature Club | 12 511 |  |
| 43 | 124 | Claire Redfield | Resident Evil | 12 505 |  |
| 44 | 128 | Shantae | Shantae | 11 863 |  |
| 45 | 129 | Lady Dimitrescu | Resident Evil Village | 11 846 |  |
| 46 | 130 | Elizabeth | BioShock Infinite | 11 845 |  |
| 47 | 135 | Asuna | Blue Archive | 11 612 |  |
| 48 | 140 | Morrigan Aensland | Darkstalkers | 11 260 |  |
| 49 | 142 | Ashley Graham | Resident Evil 4 | 11 193 |  |
| 50 | 144 | Triss Merigold | The Witcher | 10 955 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 51 | 145 | Byleth (version féminine) | Fire Emblem | 10 952 |  |
| 52 | 148 | Ellie | The Last of Us | 10 765 |  |
| 53 | 151 | Mythra (Homura, autre forme de Pyra) | Xenoblade Chronicles 2 | 10 602 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 54 | 153 | Reimu Hakurei | Touhou Project | 10 571 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 55 | 154 | Eula | Genshin Impact | 10 554 |  |
| 56 | 155 | Ann Takamaki | Persona 5 | 10 521 |  |
| 57 | 157 | Nessa (Donna en VF) | Pokémon | 10 470 |  |
| 58 | 158 | Furina | Genshin Impact | 10 424 |  |
| 59 | 160 | Jane Doe | Zenless Zone Zero | 10 356 |  |
| 60 | 161 | Liara T'Soni | Mass Effect | 10 343 |  |
| 61 | 162 | Marina | Splatoon | 10 291 |  |
| 62 | 164 | Sombra | Overwatch | 10 224 |  |
| 63 | 168 | Shadowheart (Cœur-Ombre) | Baldur's Gate 3 | 10 035 |  |
| 64 | 171 | Kiriko | Overwatch | 9 985 |  |
| 65 | 173 | Akali | League of Legends | 9 947 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 66 | 176 | Ellen Joe | Zenless Zone Zero | 9 754 |  |
| 67 | 181 | Belle | Zenless Zone Zero | 9 531 |  |
| 68 | 183 | Kafka | Honkai: Star Rail | 9 473 |  |
| 69 | 184 | Arlecchino | Genshin Impact | 9 440 |  |
| 70 | 190 | Rosemary (Marnie) | Pokémon | 9 208 |  |
| 71 | 192 | Nicole Demara | Zenless Zone Zero | 9 149 |  |
| 72 | 193 | Serena | Pokémon | 9 105 |  |
| 73 | 194 | Sona | League of Legends | 9 097 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 74 | 196 | Elsa-Mina (Lusamine) | Pokémon | 9 049 |  |
| 75 | 197 | Bowsette (version féminine de Bowser, création de fans, 2018) | Super Mario | 8 977 | création de fans (2018) à partir de Super Mario ; indice e621 1,33 (bowsette_meme), personnage humanoïde |
| 76 | 198 | Minamoto no Raikou | Fate | 8 975 | créée pour le jeu mobile Fate/Grand Order (2015) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 77 | 199 | Yelan | Genshin Impact | 8 929 |  |
| 78 | 200 | Natsuki | Doki Doki Literature Club | 8 919 |  |
| 79 | 201 | Lucina | Fire Emblem | 8 865 |  |
| 80 | 203 | Kasumi | Dead or Alive | 8 751 |  |
| 81 | 205 | Makoto Niijima | Persona 5 | 8 698 |  |
| 82 | 207 | Shenhe | Genshin Impact | 8 671 |  |
| 83 | 208 | Lilie (Lillie) | Pokémon | 8 651 |  |
| 84 | 210 | Mash Kyrielight | Fate | 8 624 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 85 | 212 | Rin Tohsaka | Fate | 8 612 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo |
| 86 | 214 | Yuri | Doki Doki Literature Club | 8 466 |  |
| 87 | 217 | Palutena | Kid Icarus | 8 318 |  |
| 88 | 219 | Eve | Stellar Blade | 8 265 |  |
| 89 | 220 | C-21 (Android 21) | Dragon Ball | 8 209 | créée pour le jeu de combat Dragon Ball FighterZ (2018), absente du manga et des anime |
| 90 | 221 | Marie Rose | Dead or Alive | 8 052 | Dead or Alive 5 (2012) ; 18 ans selon le jeu |
| 91 | 225 | Camilla | Fire Emblem | 7 940 |  |
| 92 | 226 | Loba | Apex Legends | 7 917 |  |
| 93 | 227 | Marie | Splatoon | 7 911 |  |
| 94 | 231 | Panam Palmer | Cyberpunk 2077 | 7 822 | jeu Cyberpunk 2077 (2020) |
| 95 | 232 | Keqing | Genshin Impact | 7 793 |  |
| 96 | 234 | Commandant Shepard (version féminine) | Mass Effect | 7 700 | version féminine du Commandant Shepard (héros au choix du joueur, Mass Effect) ; le tag ne désigne que la version féminine |
| 97 | 235 | Sonia | Pokémon | 7 693 |  |
| 98 | 237 | Lux | League of Legends | 7 671 |  |
| 99 | 239 | Miranda Lawson | Mass Effect | 7 641 |  |
| 100 | 241 | Soraka | League of Legends | 7 538 |  |
| 101 | 243 | Brigitte | Overwatch | 7 504 |  |
| 102 | 248 | Karin (Kakudate Karin) | Blue Archive | 7 334 |  |
| 103 | 252 | Colette | Brawl Stars | 7 293 | jeu mobile Brawl Stars (Supercell) |
| 104 | 254 | Zhu Yuan | Zenless Zone Zero | 7 274 |  |
| 105 | 257 | Sanae Kochiya | Touhou Project | 7 227 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 106 | 258 | Sakuya Izayoi | Touhou Project | 7 173 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 107 | 259 | Kamisato Ayaka | Genshin Impact | 7 125 |  |
| 108 | 260 | Mileena | Mortal Kombat | 7 123 |  |
| 109 | 262 | Caitlyn Kiramman | League of Legends / Arcane | 7 117 | championne de League of Legends (2011), aussi dans la série Arcane (2021) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 110 | 265 | Rio (Tsukatsuki Rio) | Blue Archive | 7 060 |  |
| 111 | 272 | Evelyn Chevalier | Zenless Zone Zero | 6 964 |  |
| 112 | 276 | Poppy | League of Legends | 6 933 | yordle (League of Legends) ; indice e621 2,60 (poppy_(lol) 3 606) mais personnage humanoïde, laissée en jeux vidéo comme Midna |
| 113 | 277 | Mère de Lana (Néphie en VF) | Pokémon | 6 923 |  |
| 114 | 278 | Ashley | WarioWare | 6 921 | jeune sorcière de WarioWare (2005) ; âge non précisé, apparence d'enfant |
| 115 | 279 | Bea (Faïza en VF) | Pokémon | 6 916 |  |
| 116 | 283 | Burnice White | Zenless Zone Zero | 6 871 |  |
| 117 | 284 | Callie | Splatoon | 6 865 |  |
| 118 | 285 | Bayonetta | Bayonetta | 6 850 | le tag de licence bayonetta (7 435) n'est pas additionné |
| 119 | 286 | Miss Fortune (Sarah Fortune) | League of Legends | 6 820 |  |
| 120 | 287 | Judy Alvarez | Cyberpunk 2077 | 6 752 |  |
| 121 | 289 | Lisa | Genshin Impact | 6 659 |  |
| 122 | 290 | Evelynn | League of Legends | 6 637 |  |
| 123 | 291 | Jean Gunnhildr | Genshin Impact | 6 610 |  |
| 124 | 292 | Nemona | Pokémon | 6 592 | élève de l'académie (Pokémon Écarlate et Violet, 2022), adolescente |
| 125 | 293 | Skyla (Carolina en VF) | Pokémon | 6 588 |  |
| 126 | 295 | Ayane | Dead or Alive | 6 531 |  |
| 127 | 296 | Ashe | Overwatch | 6 446 |  |
| 128 | 297 | Tristana | League of Legends | 6 442 | yordle (League of Legends) : personnage humanoïde, laissée en jeux vidéo comme Poppy |
| 129 | 300 | Vi | League of Legends / Arcane | 6 411 | championne de League of Legends (2012), surtout connue par la série Arcane (2021) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 130 | 303 | Bridget | Guilty Gear | 6 349 | Guilty Gear XX (2002) ; présentée comme une femme trans depuis Guilty Gear Strive (2022) |
| 131 | 306 | Honoka | Dead or Alive | 6 332 |  |
| 132 | 307 | Futaba Sakura | Persona 5 | 6 319 | lycéenne (15-16 ans) |
| 133 | 309 | Reine Marika l’Éternelle | Elden Ring | 6 277 |  |
| 134 | 310 | Miyabi Hoshimi | Zenless Zone Zero | 6 264 |  |
| 135 | 311 | Ivy Valentine (Isabella Valentine) | Soulcalibur | 6 191 |  |
| 136 | 316 | Felicia | Darkstalkers | 6 117 | femme-chat de Darkstalkers (1994) ; indice e621 2,28 (felicia_(darkstalkers) 2 781) mais personnage humanoïde, laissée en jeux vidéo comme Midna |
| 137 | 319 | Max Caulfield | Life is Strange | 6 042 |  |
| 138 | 320 | Sayori | Doki Doki Literature Club | 6 010 | visual novel Doki Doki Literature Club! (2017), lycéenne |
| 139 | 324 | Melony (Lona) | Pokémon | 5 911 |  |
| 140 | 327 | Chara (version féminine) | Undertale | 5 842 | version féminine de Chara (personnage au genre non défini d'Undertale) ; le tag chara (genre au choix) n'est pas additionné |
| 141 | 329 | Katarina | League of Legends | 5 811 |  |
| 142 | 331 | Firefly | Honkai: Star Rail | 5 770 |  |
| 143 | 332 | Taihou | Azur Lane | 5 769 |  |
| 144 | 333 | Edelgard von Hresvelg | Fire Emblem | 5 756 |  |
| 145 | 335 | Mavuika | Genshin Impact | 5 748 |  |
| 146 | 336 | Patchouli Knowledge | Touhou Project | 5 736 |  |
| 147 | 339 | Tharja | Fire Emblem | 5 693 |  |
| 148 | 345 | Juno | Overwatch | 5 599 |  |
| 149 | 346 | Sakura Kasugano | Street Fighter | 5 587 |  |
| 150 | 347 | Marisa Kirisame | Touhou Project | 5 585 | série de jeux Touhou Project (1997) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 151 | 350 | Jaina Proudmoore | Warcraft | 5 532 |  |
| 152 | 352 | Luna Snow (Seol Hee) | Marvel | 5 510 | créée pour le jeu mobile Marvel Future Fight (2019, Netmarble), puis reprise dans les comics et Marvel Rivals |
| 153 | 353 | Corrin (version féminine) | Fire Emblem | 5 496 | version féminine de Corrin (héros au choix du joueur, Fire Emblem Fates, 2015) |
| 154 | 355 | Gloria | Pokémon | 5 465 | héroïne de Pokémon Épée et Bouclier (2019), adolescente |
| 155 | 356 | Kai'Sa | League of Legends | 5 448 |  |
| 156 | 359 | Riesz | Trials of Mana (Seiken Densetsu 3) | 5 402 | Seiken Densetsu 3 (1995), refait sous le nom Trials of Mana (2020) |
| 157 | 361 | Poison | Final Fight | 5 362 | Final Fight (1989) ; genre présenté différemment selon les versions de Capcom (femme trans selon certaines sources officielles japonaises), classée en féminin comme Bridget |
| 158 | 365 | Yukari Yakumo | Touhou Project | 5 327 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 159 | 368 | Gwen | League of Legends | 5 283 |  |
| 160 | 371 | Irelia | League of Legends | 5 234 |  |
| 161 | 373 | Reisen Udongein Inaba | Touhou Project | 5 217 |  |
| 162 | 374 | Amber | Genshin Impact | 5 210 |  |
| 163 | 377 | Xayah | League of Legends | 5 186 |  |
| 164 | 379 | Vex | League of Legends | 5 165 |  |
| 165 | 381 | Purah | The Legend of Zelda | 5 114 | The Legend of Zelda: Breath of the Wild (2017) : apparence d'enfant dans BotW (rajeunie), adulte dans Tears of the Kingdom (2023) |
| 166 | 383 | V (version féminine, Valerie) | Cyberpunk 2077 | 5 080 | version féminine de V (héros au choix du joueur, Cyberpunk 2077, 2020), comme Femshep |
| 167 | 384 | Hilda Valentine Goneril | Fire Emblem | 5 056 |  |
| 168 | 387 | Haru Okumura | Persona 5 | 5 036 | lycéenne |
| 169 | 388 | Haydee | Haydee | 5 011 | jeu vidéo Haydee (2016) ; le tag de licence haydee_(game) n'est pas additionné |

## Comics (18)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 41 | Wonder Woman | DC Comics | 22 974 |  |
| 2 | 54 | Emma Frost | Marvel | 20 269 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 58 | Gwen Stacy | Marvel | 19 716 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 4 | 84 | Supergirl | DC Comics | 16 375 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 5 | 96 | Black Cat (Felicia Hardy) | Marvel | 15 119 |  |
| 6 | 111 | Power Girl | DC Comics | 13 942 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 7 | 147 | Femme invisible (Sue Storm) | Marvel (Les 4 Fantastiques) | 10 816 |  |
| 8 | 159 | Black Widow (Natasha Romanoff) | Marvel | 10 379 |  |
| 9 | 165 | Catwoman (Selina Kyle) | DC Comics | 10 167 |  |
| 10 | 166 | Squirrel Girl | Marvel | 10 093 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 11 | 169 | Psylocke (Betsy Braddock / Kwannon) | Marvel | 10 006 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 209 | Malicia (Rogue) | Marvel | 8 641 | créée dans les comics (1981), aussi très connue par la série X-Men (1992) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 13 | 229 | Batgirl (Barbara Gordon) | DC Comics | 7 875 | Barbara Gordon seule (décision du 24/10) : publications taguées Cassandra Cain ou Stephanie Brown retirées |
| 14 | 236 | She-Hulk | Marvel | 7 675 |  |
| 15 | 240 | Mary Jane Watson | Marvel | 7 592 |  |
| 16 | 246 | Poison Ivy | DC Comics | 7 409 | créée dans les comics Batman (1966) |
| 17 | 342 | Magik (Illyana Rasputin) | Marvel | 5 651 | créée dans les comics X-Men (1975), personnage jouable de Marvel Rivals (2024) |
| 18 | 354 | April O'Neil | Les Tortues Ninja | 5 475 | créée dans les comics Mirage (1984) ; 72 % de ses publications ont aussi le tag de la série animée de 1987 (april_o'neil_(tmnt_1987) : 3 952) |

## Cartoons / films d'animation occidentaux (50)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 14 | Raven | DC Comics | 39 707 | créée dans les comics (1980) ; déplacée ici à ta demande car sa popularité vient surtout de la série Teen Titans (2003) : 52 % de ses publications ont le tag purple_hair (look de la série), 2,5 % black_hair sans purple_hair |
| 2 | 31 | Harley Quinn | DC Comics | 26 362 | créée dans Batman : la série animée (1992), intégrée aux comics ensuite ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 48 | Starfire | DC Comics | 21 791 | créée dans les comics (1980) ; déplacée ici à ta demande comme Raven (série Teen Titans, 2003) ; tags de version : starfire_(teen_titans) 2 442, starfire_(comics) 1 773 |
| 4 | 49 | Gwen Tennyson | Ben 10 | 21 472 |  |
| 5 | 71 | Yang Xiao Long | RWBY | 17 965 | RWBY : websérie américaine (Rooster Teeth) au style anime |
| 6 | 86 | Helen Parr (Elastigirl) | Les Indestructibles | 15 935 |  |
| 7 | 89 | Ruby Rose | RWBY | 15 701 |  |
| 8 | 99 | Velma Dinkley | Scooby-Doo | 14 935 |  |
| 9 | 101 | Elsa | La Reine des neiges | 14 890 |  |
| 10 | 102 | Ahsoka Tano | Star Wars | 14 807 | créée pour le film d'animation The Clone Wars (2008) |
| 11 | 108 | Weiss Schnee | RWBY | 14 113 |  |
| 12 | 114 | Korra | La Légende de Korra | 13 757 |  |
| 13 | 120 | Pomni | The Amazing Digital Circus | 12 589 |  |
| 14 | 121 | Azula | Avatar, le dernier maître de l'air | 12 587 |  |
| 15 | 125 | Kim Possible | Kim Possible | 12 439 |  |
| 16 | 126 | Jessica Rabbit | Qui veut la peau de Roger Rabbit | 12 174 | apparaît d'abord dans un roman (1981), rendue célèbre par le film de 1988 |
| 17 | 127 | Katara | Avatar, le dernier maître de l'air | 12 083 |  |
| 18 | 138 | Chel | La Route d'Eldorado (DreamWorks) | 11 392 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 19 | 146 | Blake Belladonna | RWBY | 10 881 |  |
| 20 | 150 | Charlie Morningstar | Hazbin Hotel | 10 604 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 21 | 172 | Princesse Chewing-gum | Adventure Time | 9 974 |  |
| 22 | 179 | Toph Beifong | Avatar, le dernier maître de l'air | 9 643 |  |
| 23 | 216 | Mavis Dracula | Hôtel Transylvanie | 8 447 | créée pour le film d'animation Hôtel Transylvanie (2012, Sony Pictures Animation) |
| 24 | 218 | Marceline | Adventure Time | 8 284 |  |
| 25 | 222 | Marge Simpson | Les Simpson | 8 044 |  |
| 26 | 230 | Shego | Kim Possible | 7 856 |  |
| 27 | 238 | Violette Parr | Les Indestructibles | 7 665 | 14 ans dans le film (2004) |
| 28 | 242 | Jasmine | Aladdin | 7 518 | film d'animation Disney Aladdin (1992) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 29 | 256 | Luz Noceda | Luz à Osville (The Owl House) | 7 228 | 14 ans au début de la série (2020) |
| 30 | 268 | Péridot | Steven Universe | 7 018 |  |
| 31 | 273 | Daphné Blake | Scooby-Doo | 6 963 |  |
| 32 | 281 | Jenny Wakeman (XJ-9) | Ma vie de robot ado | 6 893 | robot (XJ-9), série Nickelodeon (2003) |
| 33 | 288 | Frankie Foster | Foster, la maison des amis imaginaires | 6 704 |  |
| 34 | 294 | Ariel | La Petite Sirène (Disney) | 6 586 | film d'animation Disney La Petite Sirène (1989) ; le tag ariel est ambigu ; union avec ariel_(the_little_mermaid) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 35 | 298 | Marinette Dupain-Cheng (Ladybug) | Miraculous | 6 437 | série animée française Miraculous (2015) ; collégienne puis lycéenne (13-15 ans) |
| 36 | 299 | Amity Blight | Luz à Osville (The Owl House) | 6 411 | 14 ans au début de la série (2020), comme Luz |
| 37 | 301 | Anna | La Reine des neiges | 6 383 | film d'animation Disney La Reine des neiges (2013) |
| 38 | 302 | Lois Griffin | Les Griffin (Family Guy) | 6 381 |  |
| 39 | 304 | Raiponce (Rapunzel) | Raiponce (Disney) | 6 348 | film d'animation Disney Raiponce (2010) ; le tag rapunzel est ambigu (aussi Rapunzel de NIKKE, 347, et le conte) ; union avec rapunzel_(tangled) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 40 | 308 | Ragatha | The Amazing Digital Circus | 6 289 | série web animée Glitch Productions (2023) |
| 41 | 321 | Vaggie | Hazbin Hotel | 5 958 |  |
| 42 | 326 | Lapis Lazuli | Steven Universe | 5 844 | Gemme de Steven Universe (2013) |
| 43 | 338 | Star Butterfly | Star vs. les forces du mal | 5 697 | 14 ans au début de la série (2015) |
| 44 | 341 | Ty Lee | Avatar, le dernier maître de l'air | 5 660 | 14 ans dans la série (2005) |
| 45 | 357 | La mère de Dexter | Le Laboratoire de Dexter | 5 439 | série Cartoon Network Le Laboratoire de Dexter (1996) |
| 46 | 363 | Perle (Pearl) | Steven Universe | 5 347 |  |
| 47 | 376 | Pyrrha Nikos | RWBY | 5 207 |  |
| 48 | 380 | Astrid Hofferson | Dragons (DreamWorks) | 5 127 | film d'animation DreamWorks Dragons (2010), d'après les livres de Cressida Cowell |
| 49 | 385 | Fionna | Adventure Time | 5 055 | version féminine de Finn créée dans l'épisode Fionna et Cake (2011) |
| 50 | 386 | Wendy Corduroy | Gravity Falls | 5 038 | 15 ans dans la série (2012) |

## Furry (43)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 4 | Rouge the Bat | Sonic the Hedgehog | 45 414 | médium d'origine : Jeux vidéo ; e621 34625 publications, indice e621 3.82 |
| 2 | 6 | Loona | Helluva Boss | 43 049 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32882 publications, indice e621 3.83 |
| 3 | 8 | Amy Rose | Sonic the Hedgehog | 41 846 | médium d'origine : Jeux vidéo ; e621 26097 publications, indice e621 3.13 |
| 4 | 24 | Twilight Sparkle | My Little Pony | 30 892 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 42232 publications, indice e621 6.85 |
| 5 | 30 | Fluttershy | My Little Pony | 26 448 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32442 publications, indice e621 6.14 |
| 6 | 32 | Judy Hopps | Zootopie | 26 160 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 41872 publications, indice e621 8.02 |
| 7 | 37 | Toriel | Undertale | 24 145 | médium d'origine : Jeux vidéo ; e621 22899 publications, indice e621 4.75 |
| 8 | 38 | Rainbow Dash | My Little Pony | 23 923 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 31071 publications, indice e621 6.5 |
| 9 | 43 | Rarity | My Little Pony | 22 555 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 27460 publications, indice e621 6.1 |
| 10 | 50 | Marie (Isabelle) | Animal Crossing | 20 826 | médium d'origine : Jeux vidéo ; e621 18943 publications, indice e621 4.55 |
| 11 | 57 | Krystal | Star Fox | 19 783 | médium d'origine : Jeux vidéo ; e621 19983 publications, indice e621 5.16 ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 60 | Pinkie Pie | My Little Pony | 19 483 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 26743 publications, indice e621 6.87 |
| 13 | 66 | Applejack | My Little Pony | 18 411 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 23052 publications, indice e621 6.27 |
| 14 | 74 | Ankha | Animal Crossing | 17 729 | médium d'origine : Jeux vidéo ; e621 11936 publications, indice e621 3.37 |
| 15 | 78 | Princesse Celestia | My Little Pony | 17 047 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 22781 publications, indice e621 6.69 |
| 16 | 79 | Princesse Luna | My Little Pony | 16 864 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 21739 publications, indice e621 6.46 |
| 17 | 95 | Blaze the Cat | Sonic | 15 169 | médium d'origine : Jeux vidéo ; e621 12634 publications, indice e621 4.17 |
| 18 | 100 | Toy Chica | Five Nights at Freddy's | 14 905 | médium d'origine : Jeux vidéo ; e621 6923 publications, indice e621 2.33 |
| 19 | 119 | Hornet | Hollow Knight | 12 634 | médium d'origine : Jeux vidéo ; e621 9003 publications, indice e621 3.57 |
| 20 | 137 | Roxanne Wolf | Five Nights at Freddy's | 11 401 | médium d'origine : Jeux vidéo ; e621 8703 publications, indice e621 3.82 |
| 21 | 141 | Vanilla | Sonic | 11 235 | médium d'origine : Jeux vidéo ; e621 8234 publications, indice e621 3.67 |
| 22 | 156 | Cream the Rabbit | Sonic | 10 519 | médium d'origine : Jeux vidéo ; e621 9983 publications, indice e621 4.75 |
| 23 | 180 | Sally Acorn | Sonic the Hedgehog | 9 562 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 7447 publications, indice e621 3.90 |
| 24 | 182 | Susie | Deltarune | 9 501 | médium d'origine : Jeux vidéo ; e621 9305 publications, indice e621 4.90 |
| 25 | 186 | Nicole Watterson | Le Monde incroyable de Gumball | 9 366 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 8221 publications, indice e621 4.40 |
| 26 | 195 | Millie | Helluva Boss | 9 057 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5190 publications, indice e621 2.87 ; diablotine (imp) et non animal : rangée en Furry comme Toriel, à confirmer |
| 27 | 202 | Agneau (Lamb, moitié féminine de Kindred) | League of Legends | 8 777 | médium d'origine : Jeux vidéo ; pas de tag séparé sur e621, indice estimé à 3,08 via le tag commun kindred_(lol) (5 730) |
| 28 | 204 | Coco Bandicoot | Crash Bandicoot | 8 730 | médium d'origine : Jeux vidéo ; e621 7078 publications, indice e621 4.06 |
| 29 | 213 | Lola Bunny | Looney Tunes | 8 547 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5877 publications, indice e621 3.44 |
| 30 | 249 | Reine Chrysalis | My Little Pony | 7 334 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 9521 publications, indice e621 6.50 |
| 31 | 253 | Noelle Holiday | Deltarune | 7 286 | médium d'origine : Jeux vidéo ; e621 7082 publications, indice e621 4.87 |
| 32 | 266 | Meow Skulls | Fortnite | 7 049 | médium d'origine : Jeux vidéo ; e621 5773 publications, indice e621 4.35 ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 33 | 267 | Diane Foxington | Les Bad Guys | 7 036 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 7994 publications, indice e621 5.69 |
| 34 | 271 | Chica | Five Nights at Freddy's | 6 995 | médium d'origine : Jeux vidéo ; e621 4304 publications, indice e621 3.08 |
| 35 | 275 | Princesse Cadance | My Little Pony | 6 936 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 8104 publications, indice e621 5.85 |
| 36 | 314 | Trixie Lulamoon | My Little Pony | 6 137 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 8055 publications, indice e621 6.57 |
| 37 | 317 | Kit (Kit Bodega) | Gameoverse | 6 069 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 4216 publications, indice e621 3.48 |
| 38 | 325 | Raven Team Leader | Fortnite | 5 862 | médium d'origine : Jeux vidéo ; e621 3182 publications, indice e621 2.72 |
| 39 | 340 | Muffet | Undertale | 5 667 | médium d'origine : Jeux vidéo ; e621 3774 publications, indice e621 3.33 |
| 40 | 343 | Surge the Tenrec | Sonic | 5 619 | médium d'origine : Comics ; e621 4342 publications, indice e621 3.87 |
| 41 | 364 | Tawna Bandicoot | Crash Bandicoot | 5 343 | médium d'origine : Jeux vidéo ; e621 2640 publications, indice e621 2.47 |
| 42 | 370 | Undyne | Undertale | 5 244 | médium d'origine : Jeux vidéo ; e621 6331 publications, indice e621 6.05 |
| 43 | 375 | Maître Tigresse | Kung Fu Panda | 5 210 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5263 publications, indice e621 5.06 |

## Hors des 4 médiums (9)

| # | Rang général (sur 388) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 9 | Hatsune Miku | Vocaloid | 41 506 | logiciel de synthèse vocale (mascotte), ni jeu ni anime à l'origine |
| 2 | 174 | Sadako Yamamura | Ring (roman et films) | 9 788 | roman de Kōji Suzuki (1991) puis films ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 188 | Kasane Teto | UTAU / Synthesizer V | 9 269 | voix de synthèse UTAU (2008), comme Hatsune Miku pour Vocaloid |
| 4 | 224 | Ouro Kronii | Hololive | 7 959 | VTuber de l'agence hololive (2021) : personnage-avatar incarné par une personne réelle |
| 5 | 263 | Mori Calliope | Hololive | 7 114 | VTuber de l'agence hololive (2020) : personnage-avatar incarné par une personne réelle |
| 6 | 264 | Houshou Marine | Hololive | 7 105 | VTuber de l'agence hololive (2019) : personnage-avatar incarné par une personne réelle |
| 7 | 274 | Hermione Granger | Harry Potter | 6 949 | romans de J. K. Rowling (1997) puis films : ni manga, ni jeu, ni comics, ni dessin animé ; élève de Poudlard (11 à 18 ans selon les tomes) |
| 8 | 312 | Gawr Gura | Hololive | 6 164 | VTuber de l'agence hololive (2020) : personnage-avatar incarné par une personne réelle |
| 9 | 362 | Rey | Star Wars | 5 353 | film en prises de vues réelles Star Wars : Le Réveil de la Force (2015) ; le tag rey est ambigu (rey_(star_wars) : 540) |
