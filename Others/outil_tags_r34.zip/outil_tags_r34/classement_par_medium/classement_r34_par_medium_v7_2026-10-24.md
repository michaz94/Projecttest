# Classement rule34 par médium : personnages féminins (v7, audit des doublons du 24/10, pages 1-300)

*Relevé du 24 octobre 2026. Base : les 243 personnages féminins de `doublons/selection_243_dedupliquee_audit_2026-10-24.csv` (liste des tags rule34.xxx, pages 1 à 300, soit environ 7 490 publications au minimum). Tous les compteurs datent du 24/10 ; audit complet des doublons : base = compteur du tag principal (liste des tags), plus le gain réel d’union (posts portant un alias ou une version sans le tag principal, mesurés par recherche négative) quand il dépasse 150.*

**Règle de classement :** chaque personnage est rangé selon le médium où il a été créé (exceptions indiquées en Note ; Raven et Starfire, créées dans les comics, sont rangées en dessins animés occidentaux à ta demande, pour la série Teen Titans de 2003). L'Animanga regroupe le manga, l'anime et les light novels.

**Furry :** classement séparé ; ses personnages sont retirés de leur médium d'origine (indiqué en Note). Critères : (1) animal anthropomorphe ou créature animale ; (2) indice e621 d'au moins 2 (part sur e621 rapportée à la part sur rule34). Midna (2,74) et Bowsette restent hors Furry (personnages humanoïdes).

## Synthèse

| Médium | Personnages | Publications cumulées | Part | Moyenne par personnage |
|---|---|---|---|---|
| Animanga | 67 | 1 197 852 | 30.4 % | 17 878 |
| Jeux vidéo | 101 | 1 542 482 | 39.1 % | 15 272 |
| Comics | 15 | 192 946 | 4.9 % | 12 863 |
| Cartoons / films d'animation occidentaux | 27 | 386 097 | 9.8 % | 14 300 |
| Furry | 29 | 553 978 | 14.1 % | 19 103 |
| Hors des 4 médiums | 4 | 68 522 | 1.7 % | 17 130 |
| **Total** | **243** | **3 941 877** | 100 % | |

## Animanga (67)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 1 | Nami | One Piece | 58 263 |  |
| 2 | 5 | Hinata Hyûga | Naruto | 44 141 |  |
| 3 | 11 | Tsunade | Naruto | 40 786 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 4 | 12 | Sakura Haruno | Naruto | 40 018 |  |
| 5 | 17 | Ochako Uraraka | My Hero Academia | 35 111 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 6 | 18 | Nico Robin | One Piece | 35 080 |  |
| 7 | 19 | Makima | Chainsaw Man | 34 383 |  |
| 8 | 21 | Yor Forger (Briar) | Spy×Family | 32 882 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 9 | 23 | Miruko | My Hero Academia | 31 266 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 10 | 25 | C-18 | Dragon Ball | 30 868 |  |
| 11 | 28 | Marin Kitagawa | My Dress-Up Darling | 29 857 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 29 | Frieren | Frieren | 28 757 |  |
| 13 | 36 | Tatsumaki | One Punch Man | 24 182 |  |
| 14 | 42 | Nagatoro | Arrête de me chauffer, Nagatoro | 22 674 |  |
| 15 | 45 | Bulma | Dragon Ball | 22 100 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 16 | 47 | Yoruichi | Bleach | 21 936 |  |
| 17 | 55 | Boa Hancock | One Piece | 19 886 |  |
| 18 | 56 | Aqua | Konosuba | 19 839 |  |
| 19 | 59 | Fern | Frieren | 19 574 |  |
| 20 | 62 | Orihime Inoue | Bleach | 19 208 |  |
| 21 | 63 | Asuka Langley | Evangelion | 19 150 |  |
| 22 | 64 | Momo Yaoyorozu | My Hero Academia | 18 872 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 23 | 67 | Lucy Heartfilia | Fairy Tail | 18 255 |  |
| 24 | 72 | Rangiku Matsumoto | Bleach | 17 804 |  |
| 25 | 73 | Mina Ashido | My Hero Academia | 17 795 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 26 | 75 | Erza Scarlet | Fairy Tail | 17 363 |  |
| 27 | 76 | Rias Gremory | High School DxD | 17 248 |  |
| 28 | 80 | Mitsuri Kanroji | Demon Slayer | 16 655 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 29 | 83 | Ino Yamanaka | Naruto | 16 449 |  |
| 30 | 85 | Power | Chainsaw Man | 16 185 |  |
| 31 | 88 | Himiko Toga | My Hero Academia | 15 704 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 32 | 94 | Megumin | KonoSuba | 15 208 |  |
| 33 | 98 | Nobara Kugisaki | Jujutsu Kaisen | 14 940 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 34 | 104 | Shinobu Kocho | Demon Slayer | 14 569 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 35 | 105 | Chichi | Dragon Ball | 14 479 |  |
| 36 | 106 | Fubuki | One-Punch Man | 14 451 |  |
| 37 | 113 | Sarada Uchiha | Naruto / Boruto | 13 790 |  |
| 38 | 115 | Ryuko Matoi | Kill la Kill | 13 701 |  |
| 39 | 116 | Mikasa Ackerman | L'Attaque des Titans | 13 552 |  |
| 40 | 117 | Tsuyu Asui | My Hero Academia | 13 349 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 41 | 122 | Rukia Kuchiki | Bleach | 12 551 |  |
| 42 | 131 | Darkness | KonoSuba | 11 774 |  |
| 43 | 132 | Emilia | Re:Zero | 11 705 |  |
| 44 | 133 | Yamato | One Piece | 11 696 |  |
| 45 | 134 | Jessie (Team Rocket) | Pokémon | 11 620 | créée dans l'anime Pokémon (1997), absente des jeux d'origine |
| 46 | 136 | Shouko Komi | Komi cherche ses mots | 11 489 |  |
| 47 | 139 | Momo Ayase | Dandadan | 11 292 |  |
| 48 | 143 | Akeno Himejima | High School DxD | 11 126 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 49 | 149 | Kushina Uzumaki | Naruto | 10 657 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 50 | 152 | Albedo | Overlord | 10 587 |  |
| 51 | 163 | Asuna Yuuki | Sword Art Online | 10 270 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 52 | 167 | Rei Ayanami | Neon Genesis Evangelion | 10 047 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 53 | 170 | Videl | Dragon Ball | 9 996 |  |
| 54 | 175 | Nezuko Kamado | Demon Slayer | 9 754 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 55 | 177 | Rem | Re:Zero | 9 733 |  |
| 56 | 178 | Ilulu | Miss Kobayashi's Dragon Maid | 9 655 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 57 | 185 | Rebecca | Cyberpunk: Edgerunners | 9 371 | créée pour l'anime Cyberpunk: Edgerunners (2022), univers du jeu Cyberpunk 2077 |
| 58 | 187 | Reze | Chainsaw Man | 9 293 |  |
| 59 | 189 | Satsuki Kiryuin | Kill la Kill | 9 215 |  |
| 60 | 191 | Kobeni Higashiyama | Chainsaw Man | 9 184 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 61 | 207 | Lucoa (Quetzalcoatl) | Miss Kobayashi's Dragon Maid | 8 672 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 62 | 212 | Hana Uzaki | Uzaki-chan veut traîner ! | 8 621 |  |
| 63 | 216 | Stocking Anarchy | Panty & Stocking with Garterbelt | 8 450 |  |
| 64 | 224 | Magicienne des Ténèbres (Dark Magician Girl) | Yu-Gi-Oh! | 8 007 | apparaît dans le manga Yu-Gi-Oh! (1996) et le jeu de cartes, classée en animanga |
| 65 | 232 | Noelle Silva | Black Clover | 7 773 | 15 ans au début de la série |
| 66 | 242 | Kyoka Jiro | My Hero Academia | 7 493 | lycéenne (15-16 ans), comme Ochaco et Momo |
| 67 | 243 | Kefla | Dragon Ball | 7 491 | fusion de Kale et Caulifla, créée pour Dragon Ball Super (2017) |

## Jeux vidéo (101)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 2 | Tifa Lockhart | Final Fantasy VII | 54 505 |  |
| 2 | 3 | Princesse Peach | Super Mario | 50 552 |  |
| 3 | 7 | 2B | NieR: Automata | 43 048 |  |
| 4 | 10 | Chun-Li | Street Fighter | 41 013 |  |
| 5 | 13 | Princesse Zelda | The Legend of Zelda | 39 792 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 6 | 15 | Samus Aran | Metroid | 37 248 |  |
| 7 | 16 | D.Va | Overwatch | 35 763 |  |
| 8 | 20 | Lara Croft | Tomb Raider | 32 891 |  |
| 9 | 22 | Widowmaker | Overwatch | 31 976 |  |
| 10 | 26 | Mercy | Overwatch | 30 462 |  |
| 11 | 27 | Ahri | League of Legends | 29 877 |  |
| 12 | 33 | Raiden Shogun | Genshin Impact | 25 757 |  |
| 13 | 34 | Jill Valentine | Resident Evil | 25 551 |  |
| 14 | 35 | Harmonie (Rosalina) | Super Mario | 24 442 |  |
| 15 | 39 | Ada Wong | Resident Evil | 23 269 |  |
| 16 | 40 | Tracer | Overwatch | 23 060 |  |
| 17 | 44 | Mai Shiranui | Fatal Fury / King of Fighters | 22 135 |  |
| 18 | 46 | Cynthia | Pokémon | 22 058 |  |
| 19 | 51 | Daisy | Super Mario | 20 747 |  |
| 20 | 52 | Artoria Pendragon | Fate | 20 563 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 21 | 53 | Ciri | The Witcher | 20 518 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 22 | 61 | Girlfriend | Friday Night Funkin' | 19 251 |  |
| 23 | 65 | Cammy | Street Fighter | 18 735 |  |
| 24 | 68 | Jinx | League of Legends / Arcane | 18 144 | personnage du jeu (2013), repris dans la série Arcane |
| 25 | 69 | May (Flora en VF) | Pokémon | 18 104 |  |
| 26 | 70 | Misty (Ondine en VF) | Pokémon | 18 082 | personnage des jeux Pokémon Rouge/Vert (1996), aussi héroïne de l'anime |
| 27 | 77 | Juri Han | Street Fighter | 17 124 |  |
| 28 | 81 | Yae Miko | Genshin Impact | 16 483 |  |
| 29 | 82 | Ganyu | Genshin Impact | 16 468 |  |
| 30 | 87 | Aerith Gainsborough | Final Fantasy VII | 15 799 |  |
| 31 | 90 | Rosa | Pokémon | 15 546 |  |
| 32 | 91 | Hilda | Pokémon | 15 539 |  |
| 33 | 92 | Lumine | Genshin Impact | 15 314 |  |
| 34 | 93 | Pharah | Overwatch | 15 243 |  |
| 35 | 97 | Midna | The Legend of Zelda | 15 085 | indice e621 2,74 mais personnage non animal (Twili) : laissée en jeux vidéo |
| 36 | 103 | Mona | Genshin Impact | 14 667 |  |
| 37 | 107 | Pyra | Xenoblade Chronicles 2 | 14 259 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 38 | 109 | Hu Tao | Genshin Impact | 14 055 |  |
| 39 | 110 | Dawn (Aurore en VF) | Pokémon | 14 047 |  |
| 40 | 112 | Mei | Overwatch | 13 901 |  |
| 41 | 118 | Yennefer | The Witcher | 12 861 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 42 | 123 | Monika | Doki Doki Literature Club | 12 511 |  |
| 43 | 124 | Claire Redfield | Resident Evil | 12 505 |  |
| 44 | 128 | Shantae | Shantae | 11 863 |  |
| 45 | 129 | Lady Dimitrescu | Resident Evil Village | 11 846 |  |
| 46 | 130 | Elizabeth | BioShock Infinite | 11 845 |  |
| 47 | 135 | Asuna | Blue Archive | 11 612 |  |
| 48 | 140 | Morrigan Aensland | Darkstalkers | 11 260 |  |
| 49 | 142 | Ashley Graham | Resident Evil 4 | 11 193 |  |
| 50 | 144 | Triss Merigold | The Witcher | 10 955 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 51 | 145 | Byleth (version féminine) | Fire Emblem | 10 952 |  |
| 52 | 148 | Ellie | The Last of Us | 10 765 |  |
| 53 | 151 | Mythra (Homura, autre forme de Pyra) | Xenoblade Chronicles 2 | 10 602 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 54 | 153 | Reimu Hakurei | Touhou Project | 10 571 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 55 | 154 | Eula | Genshin Impact | 10 554 |  |
| 56 | 155 | Ann Takamaki | Persona 5 | 10 521 |  |
| 57 | 157 | Nessa (Donna en VF) | Pokémon | 10 470 |  |
| 58 | 158 | Furina | Genshin Impact | 10 424 |  |
| 59 | 160 | Jane Doe | Zenless Zone Zero | 10 356 |  |
| 60 | 161 | Liara T'Soni | Mass Effect | 10 343 |  |
| 61 | 162 | Marina | Splatoon | 10 291 |  |
| 62 | 164 | Sombra | Overwatch | 10 224 |  |
| 63 | 168 | Shadowheart (Cœur-Ombre) | Baldur's Gate 3 | 10 035 |  |
| 64 | 171 | Kiriko | Overwatch | 9 985 |  |
| 65 | 173 | Akali | League of Legends | 9 947 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 66 | 176 | Ellen Joe | Zenless Zone Zero | 9 754 |  |
| 67 | 181 | Belle | Zenless Zone Zero | 9 531 |  |
| 68 | 183 | Kafka | Honkai: Star Rail | 9 473 |  |
| 69 | 184 | Arlecchino | Genshin Impact | 9 440 |  |
| 70 | 190 | Rosemary (Marnie) | Pokémon | 9 208 |  |
| 71 | 193 | Nicole Demara | Zenless Zone Zero | 9 149 |  |
| 72 | 194 | Serena | Pokémon | 9 105 |  |
| 73 | 195 | Sona | League of Legends | 9 097 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 74 | 197 | Elsa-Mina (Lusamine) | Pokémon | 9 049 |  |
| 75 | 198 | Bowsette (version féminine de Bowser, création de fans, 2018) | Super Mario | 8 977 | création de fans (2018) à partir de Super Mario ; indice e621 1,33 (bowsette_meme), personnage humanoïde |
| 76 | 199 | Minamoto no Raikou | Fate | 8 975 | créée pour le jeu mobile Fate/Grand Order (2015) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 77 | 200 | Yelan | Genshin Impact | 8 929 |  |
| 78 | 201 | Natsuki | Doki Doki Literature Club | 8 919 |  |
| 79 | 202 | Lucina | Fire Emblem | 8 865 |  |
| 80 | 204 | Kasumi | Dead or Alive | 8 751 |  |
| 81 | 206 | Makoto Niijima | Persona 5 | 8 698 |  |
| 82 | 208 | Shenhe | Genshin Impact | 8 671 |  |
| 83 | 209 | Lilie (Lillie) | Pokémon | 8 651 |  |
| 84 | 211 | Mash Kyrielight | Fate | 8 624 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 85 | 213 | Rin Tohsaka | Fate | 8 612 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo |
| 86 | 215 | Yuri | Doki Doki Literature Club | 8 466 |  |
| 87 | 218 | Palutena | Kid Icarus | 8 318 |  |
| 88 | 220 | Eve | Stellar Blade | 8 265 |  |
| 89 | 221 | C-21 (Android 21) | Dragon Ball | 8 209 | créée pour le jeu de combat Dragon Ball FighterZ (2018), absente du manga et des anime |
| 90 | 222 | Marie Rose | Dead or Alive | 8 052 | Dead or Alive 5 (2012) ; 18 ans selon le jeu |
| 91 | 226 | Camilla | Fire Emblem | 7 940 |  |
| 92 | 227 | Loba | Apex Legends | 7 917 |  |
| 93 | 228 | Marie | Splatoon | 7 911 |  |
| 94 | 230 | Panam Palmer | Cyberpunk 2077 | 7 822 | jeu Cyberpunk 2077 (2020) |
| 95 | 231 | Keqing | Genshin Impact | 7 793 |  |
| 96 | 233 | Commandant Shepard (version féminine) | Mass Effect | 7 700 | version féminine du Commandant Shepard (héros au choix du joueur, Mass Effect) ; le tag ne désigne que la version féminine |
| 97 | 234 | Sonia | Pokémon | 7 693 |  |
| 98 | 236 | Lux | League of Legends | 7 671 |  |
| 99 | 238 | Miranda Lawson | Mass Effect | 7 641 |  |
| 100 | 240 | Soraka | League of Legends | 7 538 |  |
| 101 | 241 | Brigitte | Overwatch | 7 504 |  |

## Comics (15)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 41 | Wonder Woman | DC Comics | 22 974 |  |
| 2 | 54 | Emma Frost | Marvel | 20 269 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 58 | Gwen Stacy | Marvel | 19 716 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 4 | 84 | Supergirl | DC Comics | 16 375 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 5 | 96 | Black Cat (Felicia Hardy) | Marvel | 15 119 |  |
| 6 | 111 | Power Girl | DC Comics | 13 942 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 7 | 147 | Femme invisible (Sue Storm) | Marvel (Les 4 Fantastiques) | 10 816 |  |
| 8 | 159 | Black Widow (Natasha Romanoff) | Marvel | 10 379 |  |
| 9 | 165 | Catwoman (Selina Kyle) | DC Comics | 10 167 |  |
| 10 | 166 | Squirrel Girl | Marvel | 10 093 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 11 | 169 | Psylocke (Betsy Braddock / Kwannon) | Marvel | 10 006 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 192 | Batgirl | DC Comics | 9 182 | tag de costume partagé par plusieurs héroïnes (Barbara Gordon surtout, aussi Cassandra Cain, Stephanie Brown) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 13 | 210 | Malicia (Rogue) | Marvel | 8 641 | créée dans les comics (1981), aussi très connue par la série X-Men (1992) ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 14 | 235 | She-Hulk | Marvel | 7 675 |  |
| 15 | 239 | Mary Jane Watson | Marvel | 7 592 |  |

## Cartoons / films d'animation occidentaux (27)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 14 | Raven | DC Comics | 39 707 | créée dans les comics (1980) ; déplacée ici à ta demande car sa popularité vient surtout de la série Teen Titans (2003) : 52 % de ses publications ont le tag purple_hair (look de la série), 2,5 % black_hair sans purple_hair |
| 2 | 31 | Harley Quinn | DC Comics | 26 362 | créée dans Batman : la série animée (1992), intégrée aux comics ensuite ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 48 | Starfire | DC Comics | 21 791 | créée dans les comics (1980) ; déplacée ici à ta demande comme Raven (série Teen Titans, 2003) ; tags de version : starfire_(teen_titans) 2 442, starfire_(comics) 1 773 |
| 4 | 49 | Gwen Tennyson | Ben 10 | 21 472 |  |
| 5 | 71 | Yang Xiao Long | RWBY | 17 965 | RWBY : websérie américaine (Rooster Teeth) au style anime |
| 6 | 86 | Helen Parr (Elastigirl) | Les Indestructibles | 15 935 |  |
| 7 | 89 | Ruby Rose | RWBY | 15 701 |  |
| 8 | 99 | Velma Dinkley | Scooby-Doo | 14 935 |  |
| 9 | 101 | Elsa | La Reine des neiges | 14 890 |  |
| 10 | 102 | Ahsoka Tano | Star Wars | 14 807 | créée pour le film d'animation The Clone Wars (2008) |
| 11 | 108 | Weiss Schnee | RWBY | 14 113 |  |
| 12 | 114 | Korra | La Légende de Korra | 13 757 |  |
| 13 | 120 | Pomni | The Amazing Digital Circus | 12 589 |  |
| 14 | 121 | Azula | Avatar, le dernier maître de l'air | 12 587 |  |
| 15 | 125 | Kim Possible | Kim Possible | 12 439 |  |
| 16 | 126 | Jessica Rabbit | Qui veut la peau de Roger Rabbit | 12 174 | apparaît d'abord dans un roman (1981), rendue célèbre par le film de 1988 |
| 17 | 127 | Katara | Avatar, le dernier maître de l'air | 12 083 |  |
| 18 | 138 | Chel | La Route d'Eldorado (DreamWorks) | 11 392 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 19 | 146 | Blake Belladonna | RWBY | 10 881 |  |
| 20 | 150 | Charlie Morningstar | Hazbin Hotel | 10 604 | tag + gain d’union mesuré (doublons, audit 24/10) |
| 21 | 172 | Princesse Chewing-gum | Adventure Time | 9 974 |  |
| 22 | 179 | Toph Beifong | Avatar, le dernier maître de l'air | 9 643 |  |
| 23 | 217 | Mavis Dracula | Hôtel Transylvanie | 8 447 | créée pour le film d'animation Hôtel Transylvanie (2012, Sony Pictures Animation) |
| 24 | 219 | Marceline | Adventure Time | 8 284 |  |
| 25 | 223 | Marge Simpson | Les Simpson | 8 044 |  |
| 26 | 229 | Shego | Kim Possible | 7 856 |  |
| 27 | 237 | Violette Parr | Les Indestructibles | 7 665 | 14 ans dans le film (2004) |

## Furry (29)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 4 | Rouge the Bat | Sonic the Hedgehog | 45 414 | médium d'origine : Jeux vidéo ; e621 34625 publications, indice e621 3.82 |
| 2 | 6 | Loona | Helluva Boss | 43 049 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32882 publications, indice e621 3.83 |
| 3 | 8 | Amy Rose | Sonic the Hedgehog | 41 846 | médium d'origine : Jeux vidéo ; e621 26097 publications, indice e621 3.13 |
| 4 | 24 | Twilight Sparkle | My Little Pony | 30 892 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 42232 publications, indice e621 6.85 |
| 5 | 30 | Fluttershy | My Little Pony | 26 448 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32442 publications, indice e621 6.14 |
| 6 | 32 | Judy Hopps | Zootopie | 26 160 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 41872 publications, indice e621 8.02 |
| 7 | 37 | Toriel | Undertale | 24 145 | médium d'origine : Jeux vidéo ; e621 22899 publications, indice e621 4.75 |
| 8 | 38 | Rainbow Dash | My Little Pony | 23 923 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 31071 publications, indice e621 6.5 |
| 9 | 43 | Rarity | My Little Pony | 22 555 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 27460 publications, indice e621 6.1 |
| 10 | 50 | Marie (Isabelle) | Animal Crossing | 20 826 | médium d'origine : Jeux vidéo ; e621 18943 publications, indice e621 4.55 |
| 11 | 57 | Krystal | Star Fox | 19 783 | médium d'origine : Jeux vidéo ; e621 19983 publications, indice e621 5.16 ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 12 | 60 | Pinkie Pie | My Little Pony | 19 483 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 26743 publications, indice e621 6.87 |
| 13 | 66 | Applejack | My Little Pony | 18 411 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 23052 publications, indice e621 6.27 |
| 14 | 74 | Ankha | Animal Crossing | 17 729 | médium d'origine : Jeux vidéo ; e621 11936 publications, indice e621 3.37 |
| 15 | 78 | Princesse Celestia | My Little Pony | 17 047 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 22781 publications, indice e621 6.69 |
| 16 | 79 | Princesse Luna | My Little Pony | 16 864 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 21739 publications, indice e621 6.46 |
| 17 | 95 | Blaze the Cat | Sonic | 15 169 | médium d'origine : Jeux vidéo ; e621 12634 publications, indice e621 4.17 |
| 18 | 100 | Toy Chica | Five Nights at Freddy's | 14 905 | médium d'origine : Jeux vidéo ; e621 6923 publications, indice e621 2.33 |
| 19 | 119 | Hornet | Hollow Knight | 12 634 | médium d'origine : Jeux vidéo ; e621 9003 publications, indice e621 3.57 |
| 20 | 137 | Roxanne Wolf | Five Nights at Freddy's | 11 401 | médium d'origine : Jeux vidéo ; e621 8703 publications, indice e621 3.82 |
| 21 | 141 | Vanilla | Sonic | 11 235 | médium d'origine : Jeux vidéo ; e621 8234 publications, indice e621 3.67 |
| 22 | 156 | Cream the Rabbit | Sonic | 10 519 | médium d'origine : Jeux vidéo ; e621 9983 publications, indice e621 4.75 |
| 23 | 180 | Sally Acorn | Sonic the Hedgehog | 9 562 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 7447 publications, indice e621 3.90 |
| 24 | 182 | Susie | Deltarune | 9 501 | médium d'origine : Jeux vidéo ; e621 9305 publications, indice e621 4.90 |
| 25 | 186 | Nicole Watterson | Le Monde incroyable de Gumball | 9 366 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 8221 publications, indice e621 4.40 |
| 26 | 196 | Millie | Helluva Boss | 9 057 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5190 publications, indice e621 2.87 ; diablotine (imp) et non animal : rangée en Furry comme Toriel, à confirmer |
| 27 | 203 | Agneau (Lamb, moitié féminine de Kindred) | League of Legends | 8 777 | médium d'origine : Jeux vidéo ; pas de tag séparé sur e621, indice estimé à 3,08 via le tag commun kindred_(lol) (5 730) |
| 28 | 205 | Coco Bandicoot | Crash Bandicoot | 8 730 | médium d'origine : Jeux vidéo ; e621 7078 publications, indice e621 4.06 |
| 29 | 214 | Lola Bunny | Looney Tunes | 8 547 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5877 publications, indice e621 3.44 |

## Hors des 4 médiums (4)

| # | Rang général (sur 243) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 9 | Hatsune Miku | Vocaloid | 41 506 | logiciel de synthèse vocale (mascotte), ni jeu ni anime à l'origine |
| 2 | 174 | Sadako Yamamura | Ring (roman et films) | 9 788 | roman de Kōji Suzuki (1991) puis films ; tag + gain d’union mesuré (doublons, audit 24/10) |
| 3 | 188 | Kasane Teto | UTAU / Synthesizer V | 9 269 | voix de synthèse UTAU (2008), comme Hatsune Miku pour Vocaloid |
| 4 | 225 | Ouro Kronii | Hololive | 7 959 | VTuber de l'agence hololive (2021) : personnage-avatar incarné par une personne réelle |
