# Classement rule34 par médium : personnages féminins (v3)

*Relevé du 24 octobre 2026. Base : les 205 personnages féminins de `doublons/selection_205_dedupliquee_2026-10-24.csv` (liste des tags rule34.xxx, pages 1 à 270, soit environ 8 650 publications au minimum). Tous les compteurs datent du 24/10 ; les personnages ayant plusieurs tags sont comptés par union (recherche OU), sans double comptage.*

**Règle de classement :** chaque personnage est rangé selon le médium où il a été créé (exceptions indiquées en Note ; Raven et Starfire, créées dans les comics, sont rangées en dessins animés occidentaux à ta demande, pour la série Teen Titans de 2003). L'Animanga regroupe le manga, l'anime et les light novels.

**Furry :** classement séparé ; ses personnages sont retirés de leur médium d'origine (indiqué en Note). Critères : (1) animal anthropomorphe ou créature animale ; (2) indice e621 d'au moins 2 (part sur e621 rapportée à la part sur rule34). Midna (2,74) et Bowsette restent hors Furry (personnages humanoïdes).

## Synthèse

| Médium | Personnages | Publications cumulées | Part | Moyenne par personnage |
|---|---|---|---|---|
| Animanga | 60 | 1 147 910 | 31.5 % | 19 132 |
| Jeux vidéo | 82 | 1 391 461 | 38.2 % | 16 969 |
| Comics | 10 | 149 654 | 4.1 % | 14 965 |
| Cartoons / films d'animation occidentaux | 22 | 344 465 | 9.5 % | 15 658 |
| Furry | 28 | 545 174 | 15.0 % | 19 470 |
| Hors des 4 médiums | 3 | 60 540 | 1.7 % | 20 180 |
| **Total** | **205** | **3 639 204** | 100 % | |

## Animanga (60)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 1 | Nami | One Piece | 58 263 |  |
| 2 | 4 | Hinata Hyûga | Naruto | 50 127 | compté par union de tags (doublons) |
| 3 | 9 | Sakura Haruno | Naruto | 41 727 | compté par union de tags (doublons) |
| 4 | 12 | Tsunade | Naruto | 40 366 |  |
| 5 | 17 | Ochako Uraraka | My Hero Academia | 35 175 | compté par union de tags (doublons) |
| 6 | 18 | Nico Robin | One Piece | 35 080 |  |
| 7 | 19 | Makima | Chainsaw Man | 34 383 |  |
| 8 | 21 | Yor Forger (Briar) | Spy×Family | 32 865 | compté par union de tags (doublons) |
| 9 | 23 | Miruko | My Hero Academia | 31 353 | compté par union de tags (doublons) |
| 10 | 25 | C-18 | Dragon Ball | 30 868 |  |
| 11 | 28 | Marin Kitagawa | My Dress-Up Darling | 28 933 |  |
| 12 | 29 | Frieren | Frieren | 28 757 |  |
| 13 | 35 | Yoruichi | Bleach | 25 389 | compté par union de tags (doublons) |
| 14 | 37 | Tatsumaki | One Punch Man | 24 182 |  |
| 15 | 44 | Nagatoro | Arrête de me chauffer, Nagatoro | 22 674 |  |
| 16 | 48 | Bulma | Dragon Ball | 21 869 |  |
| 17 | 55 | Boa Hancock | One Piece | 19 886 |  |
| 18 | 56 | Aqua | Konosuba | 19 839 |  |
| 19 | 58 | Fern | Frieren | 19 574 |  |
| 20 | 63 | Orihime Inoue | Bleach | 19 208 |  |
| 21 | 64 | Asuka Langley | Evangelion | 19 150 |  |
| 22 | 66 | Momo Yaoyorozu | My Hero Academia | 18 704 |  |
| 23 | 68 | Lucy Heartfilia | Fairy Tail | 18 255 |  |
| 24 | 73 | Rangiku Matsumoto | Bleach | 17 804 |  |
| 25 | 74 | Mina Ashido | My Hero Academia | 17 375 |  |
| 26 | 75 | Erza Scarlet | Fairy Tail | 17 363 |  |
| 27 | 76 | Rias Gremory | High School DxD | 17 248 |  |
| 28 | 82 | Ino Yamanaka | Naruto | 16 449 |  |
| 29 | 84 | Power | Chainsaw Man | 16 185 |  |
| 30 | 87 | Mitsuri Kanroji | Demon Slayer | 15 752 |  |
| 31 | 92 | Himiko Toga | My Hero Academia | 15 263 |  |
| 32 | 94 | Megumin | KonoSuba | 15 208 |  |
| 33 | 102 | Nobara Kugisaki | Jujutsu Kaisen | 14 772 |  |
| 34 | 104 | Chichi | Dragon Ball | 14 479 |  |
| 35 | 105 | Fubuki | One-Punch Man | 14 451 |  |
| 36 | 106 | Shinobu Kocho | Demon Slayer | 14 338 |  |
| 37 | 112 | Sarada Uchiha | Naruto / Boruto | 13 790 |  |
| 38 | 114 | Ryuko Matoi | Kill la Kill | 13 701 |  |
| 39 | 115 | Mikasa Ackerman | L'Attaque des Titans | 13 552 |  |
| 40 | 117 | Tsuyu Asui | My Hero Academia | 13 013 |  |
| 41 | 122 | Rukia Kuchiki | Bleach | 12 551 |  |
| 42 | 131 | Darkness | KonoSuba | 11 774 |  |
| 43 | 132 | Emilia | Re:Zero | 11 705 |  |
| 44 | 133 | Yamato | One Piece | 11 696 |  |
| 45 | 134 | Jessie (Team Rocket) | Pokémon | 11 620 | créée dans l'anime Pokémon (1997), absente des jeux d'origine |
| 46 | 136 | Shouko Komi | Komi cherche ses mots | 11 489 |  |
| 47 | 138 | Momo Ayase | Dandadan | 11 292 |  |
| 48 | 142 | Akeno Himejima | High School DxD | 10 958 |  |
| 49 | 149 | Albedo | Overlord | 10 587 |  |
| 50 | 153 | Asuna Yuuki | Sword Art Online | 10 479 | compté par union de tags (doublons) |
| 51 | 161 | Kushina Uzumaki | Naruto | 10 279 |  |
| 52 | 165 | Videl | Dragon Ball | 9 996 |  |
| 53 | 171 | Rei Ayanami | Neon Genesis Evangelion | 9 879 |  |
| 54 | 172 | Nezuko Kamado | Demon Slayer | 9 807 | compté par union de tags (doublons) |
| 55 | 175 | Rem | Re:Zero | 9 733 |  |
| 56 | 178 | Ilulu | Miss Kobayashi's Dragon Maid | 9 639 | compté par union de tags (doublons) |
| 57 | 184 | Rebecca | Cyberpunk: Edgerunners | 9 371 | créée pour l'anime Cyberpunk: Edgerunners (2022), univers du jeu Cyberpunk 2077 |
| 58 | 186 | Reze | Chainsaw Man | 9 293 |  |
| 59 | 188 | Satsuki Kiryuin | Kill la Kill | 9 215 |  |
| 60 | 190 | Kobeni Higashiyama | Chainsaw Man | 9 177 | compté par union de tags (doublons) |

## Jeux vidéo (82)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 2 | Tifa Lockhart | Final Fantasy VII | 54 505 |  |
| 2 | 3 | Princesse Peach | Super Mario | 50 552 |  |
| 3 | 7 | 2B | NieR: Automata | 43 048 |  |
| 4 | 11 | Chun-Li | Street Fighter | 41 013 |  |
| 5 | 13 | Princesse Zelda | The Legend of Zelda | 39 879 | compté par union de tags (doublons) |
| 6 | 15 | Samus Aran | Metroid | 37 359 | compté par union de tags (doublons) |
| 7 | 16 | D.Va | Overwatch | 35 763 |  |
| 8 | 20 | Lara Croft | Tomb Raider | 32 865 | compté par union de tags (doublons) |
| 9 | 22 | Widowmaker | Overwatch | 31 976 |  |
| 10 | 26 | Mercy | Overwatch | 30 462 |  |
| 11 | 27 | Ahri | League of Legends | 29 877 |  |
| 12 | 33 | Raiden Shogun | Genshin Impact | 25 757 |  |
| 13 | 34 | Jill Valentine | Resident Evil | 25 557 | compté par union de tags (doublons) |
| 14 | 36 | Harmonie (Rosalina) | Super Mario | 24 442 |  |
| 15 | 40 | Ada Wong | Resident Evil | 23 269 |  |
| 16 | 41 | Misty (Ondine en VF) | Pokémon | 23 163 | personnage des jeux Pokémon Rouge/Vert (1996), aussi héroïne de l'anime ; compté par union de tags (doublons) |
| 17 | 43 | Tracer | Overwatch | 23 060 |  |
| 18 | 46 | Mai Shiranui | Fatal Fury / King of Fighters | 22 135 |  |
| 19 | 47 | Cynthia | Pokémon | 22 058 |  |
| 20 | 52 | Daisy | Super Mario | 20 747 |  |
| 21 | 53 | Ciri | The Witcher | 20 518 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 22 | 61 | Girlfriend | Friday Night Funkin' | 19 251 |  |
| 23 | 62 | Artoria Pendragon | Fate | 19 240 | Fate/stay night est un visual novel (2004), donc classé jeu vidéo |
| 24 | 65 | Cammy | Street Fighter | 18 735 |  |
| 25 | 69 | Jinx | League of Legends / Arcane | 18 144 | personnage du jeu (2013), repris dans la série Arcane |
| 26 | 70 | May (Flora en VF) | Pokémon | 18 104 |  |
| 27 | 77 | Juri Han | Street Fighter | 17 124 |  |
| 28 | 80 | Yae Miko | Genshin Impact | 16 483 |  |
| 29 | 81 | Ganyu | Genshin Impact | 16 468 |  |
| 30 | 86 | Aerith Gainsborough | Final Fantasy VII | 15 799 |  |
| 31 | 89 | Rosa | Pokémon | 15 546 |  |
| 32 | 90 | Hilda | Pokémon | 15 539 |  |
| 33 | 91 | Lumine | Genshin Impact | 15 314 |  |
| 34 | 93 | Pharah | Overwatch | 15 243 |  |
| 35 | 97 | Midna | The Legend of Zelda | 15 099 | indice e621 2,74 mais personnage non animal (Twili) : laissée en jeux vidéo ; compté par union de tags (doublons) |
| 36 | 103 | Mona | Genshin Impact | 14 667 |  |
| 37 | 108 | Hu Tao | Genshin Impact | 14 055 |  |
| 38 | 109 | Dawn (Aurore en VF) | Pokémon | 14 047 |  |
| 39 | 111 | Mei | Overwatch | 13 901 |  |
| 40 | 116 | Pyra | Xenoblade Chronicles 2 | 13 524 |  |
| 41 | 118 | Yennefer | The Witcher | 12 861 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 42 | 123 | Monika | Doki Doki Literature Club | 12 511 |  |
| 43 | 124 | Claire Redfield | Resident Evil | 12 505 |  |
| 44 | 128 | Shantae | Shantae | 11 863 |  |
| 45 | 129 | Lady Dimitrescu | Resident Evil Village | 11 846 |  |
| 46 | 130 | Elizabeth | BioShock Infinite | 11 845 |  |
| 47 | 135 | Asuna | Blue Archive | 11 612 |  |
| 48 | 139 | Morrigan Aensland | Darkstalkers | 11 260 |  |
| 49 | 141 | Ashley Graham | Resident Evil 4 | 11 193 |  |
| 50 | 143 | Triss Merigold | The Witcher | 10 955 | personnage des romans d'Andrzej Sapkowski ; classé en jeux vidéo à ta demande |
| 51 | 144 | Byleth (version féminine) | Fire Emblem | 10 952 |  |
| 52 | 148 | Ellie | The Last of Us | 10 731 | compté par union de tags (doublons) |
| 53 | 150 | Eula | Genshin Impact | 10 554 |  |
| 54 | 151 | Ann Takamaki | Persona 5 | 10 521 |  |
| 55 | 154 | Nessa (Donna en VF) | Pokémon | 10 470 |  |
| 56 | 155 | Furina | Genshin Impact | 10 424 |  |
| 57 | 157 | Jane Doe | Zenless Zone Zero | 10 356 |  |
| 58 | 158 | Liara T'Soni | Mass Effect | 10 343 |  |
| 59 | 160 | Marina | Splatoon | 10 291 |  |
| 60 | 162 | Sombra | Overwatch | 10 224 |  |
| 61 | 164 | Shadowheart (Cœur-Ombre) | Baldur's Gate 3 | 10 035 |  |
| 62 | 166 | Kiriko | Overwatch | 9 985 |  |
| 63 | 167 | Reimu Hakurei | Touhou Project | 9 983 |  |
| 64 | 170 | Akali | League of Legends | 9 933 | compté par union de tags (doublons) |
| 65 | 174 | Ellen Joe | Zenless Zone Zero | 9 754 |  |
| 66 | 176 | Mythra (Homura, autre forme de Pyra) | Xenoblade Chronicles 2 | 9 657 |  |
| 67 | 180 | Belle | Zenless Zone Zero | 9 531 |  |
| 68 | 182 | Kafka | Honkai: Star Rail | 9 473 |  |
| 69 | 183 | Arlecchino | Genshin Impact | 9 440 |  |
| 70 | 189 | Rosemary (Marnie) | Pokémon | 9 208 |  |
| 71 | 191 | Nicole Demara | Zenless Zone Zero | 9 149 |  |
| 72 | 192 | Serena | Pokémon | 9 105 |  |
| 73 | 193 | Sona | League of Legends | 9 093 | compté par union de tags (doublons) |
| 74 | 195 | Elsa-Mina (Lusamine) | Pokémon | 9 049 |  |
| 75 | 196 | Bowsette (version féminine de Bowser, création de fans, 2018) | Super Mario | 8 977 | création de fans (2018) à partir de Super Mario ; indice e621 1,33 (bowsette_meme), personnage humanoïde |
| 76 | 197 | Yelan | Genshin Impact | 8 929 |  |
| 77 | 198 | Natsuki | Doki Doki Literature Club | 8 919 |  |
| 78 | 199 | Lucina | Fire Emblem | 8 865 |  |
| 79 | 201 | Kasumi | Dead or Alive | 8 751 |  |
| 80 | 203 | Makoto Niijima | Persona 5 | 8 698 |  |
| 81 | 204 | Shenhe | Genshin Impact | 8 671 |  |
| 82 | 205 | Lilie (Lillie) | Pokémon | 8 651 |  |

## Comics (10)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 42 | Wonder Woman | DC Comics | 23 079 | compté par union de tags (doublons) |
| 2 | 54 | Emma Frost | Marvel | 20 223 | compté par union de tags (doublons) |
| 3 | 57 | Gwen Stacy | Marvel | 19 635 | compté par union de tags (doublons) |
| 4 | 83 | Supergirl | DC Comics | 16 359 | compté par union de tags (doublons) |
| 5 | 96 | Black Cat (Felicia Hardy) | Marvel | 15 099 | compté par union de tags (doublons) |
| 6 | 110 | Power Girl | DC Comics | 13 923 | compté par union de tags (doublons) |
| 7 | 147 | Femme invisible (Sue Storm) | Marvel (Les 4 Fantastiques) | 10 815 | compté par union de tags (doublons) |
| 8 | 156 | Black Widow (Natasha Romanoff) | Marvel | 10 379 |  |
| 9 | 163 | Catwoman (Selina Kyle) | DC Comics | 10 167 |  |
| 10 | 168 | Psylocke (Betsy Braddock / Kwannon) | Marvel | 9 975 | compté par union de tags (doublons) |

## Cartoons / films d'animation occidentaux (22)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 14 | Raven | DC Comics | 39 711 | créée dans les comics (1980) ; déplacée ici à ta demande car sa popularité vient surtout de la série Teen Titans (2003) : 52 % de ses publications ont le tag purple_hair (look de la série), 2,5 % black_hair sans purple_hair ; compté par union de tags (doublons) |
| 2 | 32 | Harley Quinn | DC Comics | 25 774 | créée dans Batman : la série animée (1992), intégrée aux comics ensuite |
| 3 | 49 | Starfire | DC Comics | 21 791 | créée dans les comics (1980) ; déplacée ici à ta demande comme Raven (série Teen Titans, 2003) ; tags de version : starfire_(teen_titans) 2 442, starfire_(comics) 1 773 |
| 4 | 50 | Gwen Tennyson | Ben 10 | 21 472 |  |
| 5 | 71 | Yang Xiao Long | RWBY | 17 965 | RWBY : websérie américaine (Rooster Teeth) au style anime |
| 6 | 85 | Helen Parr (Elastigirl) | Les Indestructibles | 15 981 | compté par union de tags (doublons) |
| 7 | 88 | Ruby Rose | RWBY | 15 701 |  |
| 8 | 98 | Velma Dinkley | Scooby-Doo | 14 935 |  |
| 9 | 100 | Elsa | La Reine des neiges | 14 890 |  |
| 10 | 101 | Ahsoka Tano | Star Wars | 14 807 | créée pour le film d'animation The Clone Wars (2008) |
| 11 | 107 | Weiss Schnee | RWBY | 14 113 |  |
| 12 | 113 | Korra | La Légende de Korra | 13 757 |  |
| 13 | 120 | Pomni | The Amazing Digital Circus | 12 589 |  |
| 14 | 121 | Azula | Avatar, le dernier maître de l'air | 12 587 |  |
| 15 | 125 | Kim Possible | Kim Possible | 12 439 |  |
| 16 | 126 | Jessica Rabbit | Qui veut la peau de Roger Rabbit | 12 174 | apparaît d'abord dans un roman (1981), rendue célèbre par le film de 1988 |
| 17 | 127 | Katara | Avatar, le dernier maître de l'air | 12 083 |  |
| 18 | 145 | Blake Belladonna | RWBY | 10 881 |  |
| 19 | 146 | Chel | La Route d'Eldorado (DreamWorks) | 10 867 |  |
| 20 | 159 | Charlie Morningstar | Hazbin Hotel | 10 331 |  |
| 21 | 169 | Princesse Chewing-gum | Adventure Time | 9 974 |  |
| 22 | 177 | Toph Beifong | Avatar, le dernier maître de l'air | 9 643 |  |

## Furry (28)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 5 | Rouge the Bat | Sonic the Hedgehog | 45 414 | médium d'origine : Jeux vidéo ; e621 34625 publications, indice e621 3.82 |
| 2 | 6 | Loona | Helluva Boss | 43 049 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32882 publications, indice e621 3.83 |
| 3 | 8 | Amy Rose | Sonic the Hedgehog | 41 846 | médium d'origine : Jeux vidéo ; e621 26097 publications, indice e621 3.13 |
| 4 | 24 | Twilight Sparkle | My Little Pony | 30 892 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 42232 publications, indice e621 6.85 |
| 5 | 30 | Fluttershy | My Little Pony | 26 448 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 32442 publications, indice e621 6.14 |
| 6 | 31 | Judy Hopps | Zootopie | 26 160 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 41872 publications, indice e621 8.02 |
| 7 | 38 | Toriel | Undertale | 24 145 | médium d'origine : Jeux vidéo ; e621 22899 publications, indice e621 4.75 |
| 8 | 39 | Rainbow Dash | My Little Pony | 23 923 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 31071 publications, indice e621 6.5 |
| 9 | 45 | Rarity | My Little Pony | 22 555 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 27460 publications, indice e621 6.1 |
| 10 | 51 | Marie (Isabelle) | Animal Crossing | 20 826 | médium d'origine : Jeux vidéo ; e621 18943 publications, indice e621 4.55 |
| 11 | 59 | Pinkie Pie | My Little Pony | 19 483 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 26743 publications, indice e621 6.87 |
| 12 | 60 | Krystal | Star Fox | 19 384 | médium d'origine : Jeux vidéo ; e621 19983 publications, indice e621 5.16 |
| 13 | 67 | Applejack | My Little Pony | 18 411 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 23052 publications, indice e621 6.27 |
| 14 | 72 | Ankha | Animal Crossing | 17 871 | médium d'origine : Jeux vidéo ; e621 11936 publications, indice e621 3.37 ; compté par union de tags (doublons) |
| 15 | 78 | Princesse Celestia | My Little Pony | 17 047 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 22781 publications, indice e621 6.69 |
| 16 | 79 | Princesse Luna | My Little Pony | 16 864 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 21739 publications, indice e621 6.46 |
| 17 | 95 | Blaze the Cat | Sonic | 15 169 | médium d'origine : Jeux vidéo ; e621 12634 publications, indice e621 4.17 |
| 18 | 99 | Toy Chica | Five Nights at Freddy's | 14 905 | médium d'origine : Jeux vidéo ; e621 6923 publications, indice e621 2.33 |
| 19 | 119 | Hornet | Hollow Knight | 12 634 | médium d'origine : Jeux vidéo ; e621 9003 publications, indice e621 3.57 |
| 20 | 137 | Roxanne Wolf | Five Nights at Freddy's | 11 401 | médium d'origine : Jeux vidéo ; e621 8703 publications, indice e621 3.82 |
| 21 | 140 | Vanilla | Sonic | 11 235 | médium d'origine : Jeux vidéo ; e621 8234 publications, indice e621 3.67 |
| 22 | 152 | Cream the Rabbit | Sonic | 10 519 | médium d'origine : Jeux vidéo ; e621 9983 publications, indice e621 4.75 |
| 23 | 179 | Sally Acorn | Sonic the Hedgehog | 9 562 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 7447 publications, indice e621 3.90 |
| 24 | 181 | Susie | Deltarune | 9 501 | médium d'origine : Jeux vidéo ; e621 9305 publications, indice e621 4.90 |
| 25 | 185 | Nicole Watterson | Le Monde incroyable de Gumball | 9 366 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 8221 publications, indice e621 4.40 |
| 26 | 194 | Millie | Helluva Boss | 9 057 | médium d'origine : Cartoons / films d'animation occidentaux ; e621 5190 publications, indice e621 2.87 ; diablotine (imp) et non animal : rangée en Furry comme Toriel, à confirmer |
| 27 | 200 | Agneau (Lamb, moitié féminine de Kindred) | League of Legends | 8 777 | médium d'origine : Jeux vidéo ; pas de tag séparé sur e621, indice estimé à 3,08 via le tag commun kindred_(lol) (5 730) |
| 28 | 202 | Coco Bandicoot | Crash Bandicoot | 8 730 | médium d'origine : Jeux vidéo ; e621 7078 publications, indice e621 4.06 |

## Hors des 4 médiums (3)

| # | Rang général (sur 205) | Personnage | Œuvre | Publications | Note |
|---|---|---|---|---|---|
| 1 | 10 | Hatsune Miku | Vocaloid | 41 506 | logiciel de synthèse vocale (mascotte), ni jeu ni anime à l'origine |
| 2 | 173 | Sadako Yamamura | Ring (roman et films) | 9 765 | roman de Kōji Suzuki (1991) puis films ; compté par union de tags (doublons) |
| 3 | 187 | Kasane Teto | UTAU / Synthesizer V | 9 269 | voix de synthèse UTAU (2008), comme Hatsune Miku pour Vocaloid |
