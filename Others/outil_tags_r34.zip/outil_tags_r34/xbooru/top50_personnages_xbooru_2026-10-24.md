# Top 50 des personnages sur Xbooru (2026-10-24)

Relevé de l'IA. Compteurs en direct par l'API de Xbooru. Un personnage = son tag principal + les publications ajoutées par ses autres noms (calcul par négation, sans double compte).

Exclus car ce ne sont pas des personnages individuels : original_character, humans_of_pokemon, inkling (espèce), character_request, anonymous, pokemon_(creature), fan_character, team_rocket.

| Rang | Personnage | Franchise | Sexe | Publications | dont autres noms |
|---|---|---|---|---|---|
| 1 | Raven | Teen Titans (DC) | F | 11 463 | 9 |
| 2 | Hinata Hyûga | Naruto | F | 7 761 | 29 |
| 3 | Sakura Haruno | Naruto | F | 7 027 |  |
| 4 | Amy Rose | Sonic | F | 6 664 |  |
| 5 | Lois Griffin | Family Guy | F | 6 421 |  |
| 6 | Princesse Peach | Mario | F | 6 152 |  |
| 7 | Starfire | Teen Titans (DC) | F | 6 143 | 13 |
| 8 | Naruto Uzumaki | Naruto | M | 6 050 |  |
| 9 | Velma Dinkley | Scooby-Doo | F | 5 991 |  |
| 10 | Rouge the Bat | Sonic | F | 5 985 |  |
| 11 | Nami | One Piece | F | 5 085 | 2 255 |
| 12 | Marge Simpson | Les Simpson | F | 4 974 |  |
| 13 | Tsunade | Naruto | F | 4 292 | 17 |
| 14 | Sonic | Sonic | M | 4 241 |  |
| 15 | Twilight Sparkle | My Little Pony | F | 4 227 | 1 229 |
| 16 | Flora (May) | Pokémon | F | 4 174 | 1 405 |
| 17 | Gwen Tennyson | Ben 10 | F | 3 796 |  |
| 18 | Kim Possible | Kim Possible | F | 3 763 |  |
| 19 | Marie | Splatoon | F | 3 458 |  |
| 20 | Helen Parr (Elastigirl) | Les Indestructibles | F | 3 303 | 421 |
| 21 | Princesse Zelda | Zelda | F | 3 293 | 211 |
| 22 | Cream the Rabbit | Sonic | F | 3 210 |  |
| 23 | Fluttershy | My Little Pony | F | 3 138 | 641 |
| 24 | Francine Smith | American Dad! | F | 3 136 |  |
| 25 | Sailor Moon (Usagi) | Sailor Moon | F | 3 099 | 448 |
| 26 | Ondine (Misty) | Pokémon | F | 3 099 | 665 |
| 27 | Aurore (Dawn) | Pokémon | F | 3 072 | 1 209 |
| 28 | Jessica Rabbit | Qui veut la peau de Roger Rabbit | F | 3 030 |  |
| 29 | Tifa Lockhart | Final Fantasy | F | 2 960 |  |
| 30 | Rarity | My Little Pony | F | 2 911 | 844 |
| 31 | Meg Griffin | Family Guy | F | 2 892 |  |
| 32 | Samus Aran | Metroid | F | 2 846 | 4 |
| 33 | Leela | Futurama | F | 2 812 |  |
| 34 | Nico Robin | One Piece | F | 2 780 |  |
| 35 | Daphne Blake | Scooby-Doo | F | 2 739 |  |
| 36 | Chun-Li | Street Fighter | F | 2 729 |  |
| 37 | Rainbow Dash | My Little Pony | F | 2 700 | 372 |
| 38 | C-18 | Dragon Ball | F | 2 672 |  |
| 39 | Princesse Daisy | Mario | F | 2 631 |  |
| 40 | Beast Boy | Teen Titans (DC) | M | 2 541 |  |
| 41 | Applejack | My Little Pony | F | 2 525 | 573 |
| 42 | Pinkie Pie | My Little Pony | F | 2 520 | 563 |
| 43 | Wonder Woman | DC | F | 2 505 | 14 |
| 44 | Sacha (Ash) | Pokémon | M | 2 459 | 101 |
| 45 | Jasmine | Aladdin (Disney) | F | 2 347 |  |
| 46 | Bulma | Dragon Ball | F | 2 309 | 388 |
| 47 | Ino Yamanaka | Naruto | F | 2 306 |  |
| 48 | Harley Quinn | DC | F | 2 213 | 3 |
| 49 | Renamon | Digimon | F | 2 195 | 1 |
| 50 | Hatsune Miku | Vocaloid | F | 2 151 |  |

Juste après : Serena 2 143 ; Ariel 2 110 ; Ludvina (Hilda) 2 088 ; Cynthia 2 055 ; Blaze the Cat 2 019 ; Vanilla the Rabbit 2 006 ; Shego 1 997 ; Princesse Celestia 1 942 ; Monkey D. Luffy 1 851 ; Harmonie (Rosalina) 1 835
