# Spider-Gwen sur rule34 — relevé du 24/10/2026
Effectif = pid de la dernière page + 21 (± 21), requêtes `spider-gwen id:<N` (et `id:>A id:<B` pour la fenêtre 2017-2018).
- `spider-gwen id:<2600000` : pid 294 → ≈ 315 ; `id:<3000000` : pid 336 → ≈ 357 ; `id:<3500000` : pid 840 → ≈ 861
- `id:<7000000` : pid 3528 → ≈ 3 549 ; `id:<8000000` : pid 4200 → ≈ 4 221 ; `id:<9000000` : pid 6174 → ≈ 6 195
- `spider-gwen id:>2600000 id:<3000000` : 2 pages (43 à 84 posts)
- Total `spider-gwen` (autocomplétion) : 15 414 ; `gwen_stacy` 19 317 ; `gwen_stacy_(spider-verse)` 7 381 ; `spider-gwen` + `gwen_stacy_(spider-verse)` : pid 6048 → ≈ 6 069 (39 %)
- Tags des films : `spider-man:_into_the_spider-verse` 11 727 ; `spider-man:_across_the_spider-verse` 8 539
Nouvelles ancres ID ↔ date : 2 600 000 = 2017-12-19 (historique des tags) ; 3 000 000 ≤ 2018-12-05 (1er commentaire) ; 3 500 000 = 2019-11-26 (historique des tags, bot).
Sorties : Spider-Man: New Generation (Into the Spider-Verse) 14/12/2018 ; Across the Spider-Verse 02/06/2023.
