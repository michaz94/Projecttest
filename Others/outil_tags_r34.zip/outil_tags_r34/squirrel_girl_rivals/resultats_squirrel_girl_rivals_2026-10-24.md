# Squirrel Girl avant et après Marvel Rivals (relevé du 24/10/2026)

Dates du jeu : annonce le 27/03/2024 ; Squirrel Girl trouvée dans les fichiers de l'alpha (datamine) en mai 2024 ; **révélée officiellement le 30/11–1/12/2024** ; **sortie du jeu le 06/12/2024**, avec elle jouable dès le lancement.

## rule34.xxx (union des 6 tags du personnage = 10 093)
Union : `( squirrel_girl_(marvel) ~ squirrel_girl_(marvel_rivals) ~ squirrel_girl ~ doreen_green ~ squirrel_girl_(sunshine_squirrel) ~ squirrel_girl_(symbiote_squirrel) )`. Compte = dernière page + 21 (± 21).

| Mesure | Publications |
|---|---|
| Total (audit du 24/10) | 10 093 |
| Avant la vague Marvel Rivals (`id:<11884000`) | ≈ 1 491 |
| Depuis (par différence) | ≈ 8 600 |
| Avec le tag `marvel_rivals` | ≈ 7 119 (70 %) |
| Sans le tag `marvel_rivals` | ≈ 2 919 |

- Coupure par numéro de post : en triant `squirrel_girl_(marvel) marvel_rivals` par id croissant, le 1er post est isolé (11 678 769) et la série continue commence à 11 884 592. La date exacte du post 11 884 000 n'est pas lisible sans compte. Elle correspond au début de la vague Marvel Rivals (révélation du 30/11/2024), ce que confirme Danbooru (pic en décembre 2024).
- Tags d'année (date du dessin, mis sur une minorité de posts), pour 10 000 posts portant le même tag d'année : 2023 ≈ 63 posts (3,4) ; 2024 ≈ 273 (14,9) ; 2025 ≈ 399 (14,5) ; 2026 ≈ 105 (5,4). Totaux des tags d'année (autocomplétion) : 2023 = 186 371, 2024 = 183 044, 2025 = 275 002, 2026 = 195 601.

## Danbooru (`squirrel_girl_(marvel)`, 720 images ; date de mise en ligne)
- Avant décembre 2024 : 21 images au total (16 avant 2021, 5 de 2021 à novembre 2024).
- Décembre 2024 → 23/10/2026 : 692 (219 rien qu'en décembre 2024). Avec le tag `marvel_rivals` : 670 sur 720.
- 12 mois avant (déc. 2023–nov. 2024) : 1 image (0,01 pour 10 000 uploads du site).
- 12 mois après (déc. 2024–nov. 2025) : 563 (3,16 pour 10 000).
- 12 derniers mois (oct. 2025–sept. 2026) : 147 (0,68 pour 10 000), soit −78 % par rapport à la 1re année, en part du site.
- Détail mensuel : `danbooru_mensuel_2026-10-24.json`.
