# Magik avant et après Marvel Rivals (relevé du 24/10/2026)

Dates : Magik est dans la bande-annonce d'annonce du jeu (27/03/2024) et jouable dès l'alpha fermée (10–20/05/2024, ~30 000 joueurs) ; **sortie du jeu le 06/12/2024**. Second jeu : **Marvel Tōkon: Fighting Souls** (Arc System Works), Magik confirmée le 12/02/2026, **sorti le 06/08/2026**.

## rule34.xxx (union de 4 tags = ≈ 5 733)
Union : `( magik_(illyana_rasputin) ~ magik_(marvel_rivals) ~ magik_(marvel_tokon) ~ magik_(x-men) )`. Compte = dernière page + 21 (± 21).

| Mesure | Publications |
|---|---|
| Total | ≈ 5 733 |
| Avant la vague Marvel Rivals (`id:<11884000`, ≈ 30/11/2024, même coupure que Squirrel Girl) | ≈ 651 |
| dont tagués `marvel_rivals` (annonce → sortie) | ≤ 42 (une seule page) |
| Depuis (par différence) | ≈ 5 080 |
| Avec le tag `marvel_rivals` | ≈ 4 263 (74 %) |
| Sans le tag `marvel_rivals` | ≈ 1 491 |
| Avec le tag `marvel_tokon:_fighting_souls` | ≈ 315 |

- Tri par id croissant de `magik_(illyana_rasputin) marvel_rivals` : 1 post isolé (10 931 249), puis la série continue commence à 11 926 505, après la sortie.
- L'annonce (mars 2024) et l'alpha (mai 2024) n'ont presque rien produit sur rule34 : ≤ 42 posts Rivals avant la sortie.

## Danbooru (`magik_(x-men)`, 1 112 images ; date de mise en ligne)
- Avant décembre 2024 : 64 (14 avant 2021, 50 de 2021 à novembre 2024).
- Décembre 2024 → 23/10/2026 : ≈ 1 009. Avec le tag `marvel_rivals` : 615 sur 1 112. Environ 39 images ne tombent dans aucune tranche de date.
- 12 mois avant l'annonce (mars 2023–février 2024) : 10 (0,09 pour 10 000 uploads du site).
- De l'annonce à la sortie (mars–novembre 2024, 9 mois) : 32 (0,27 pour 10 000).
- 12 mois avant la sortie : 34 (0,22) ; 12 mois après : 468 (2,62), soit ×12.
- 12 derniers mois (oct. 2025–sept. 2026) : 578 (2,67), pas de baisse. Pic d'août 2026 : 122 images, dont 74 taguées Marvel Tōkon (juillet : 78 dont 33 ; septembre : 55 dont 22).
- Détail mensuel : `danbooru_mensuel_2026-10-24.json`.
