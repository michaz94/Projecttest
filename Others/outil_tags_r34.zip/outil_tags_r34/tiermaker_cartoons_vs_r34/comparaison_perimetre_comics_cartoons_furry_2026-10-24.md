# Votes TierMaker « dessins animés » vs rule34 — périmètre Comics, Cartoons occidentaux et Furry (24 octobre 2026)

Liste rule34 du périmètre : les 111 personnages féminins de la sélection 388 classés Comics (18), Cartoons / films d'animation occidentaux (50) ou Furry (43) dans le classement par médium v12, plus les 5 espèces dessinées surtout en femelle (Gardevoir, Renamon, Lockpin, Aquali, Givrali), rangées en Furry. Tous ont au moins 5 038 publications (liste des tags, pages 1 à 390).

Côté TierMaker : top 100 Average Vote de chaque vote après retrait des personnages hors périmètre (jeux vidéo : Overwatch, Arcane/League of Legends, Castlevania, Peach du film Mario, Pokémon ; animanga : Naruto, One Piece, Pokémon (anime), Yu-Gi-Oh!, Dragon Ball). Les images non identifiées restent à leur place mais sont exclues des calculs.

Votes à paliers supplémentaires (81614596 : Hard Pass ; 20899730 : Ewwwwww et Who?) : Hard Pass et Ewwwwww comptent comme la note la plus basse (échelle 6 → 1) ; les votes « Who? » (je ne connais pas) sont retirés. Choix fait par toi le 24 oct.

## Synthèse

| Vote | Retirés (hors périmètre) | Identifiés | Distincts | Dans la liste r34 du périmètre | Liste r34 présente dans le modèle | Spearman rang TM / publications r34 |
|---|---:|---:|---:|---:|---:|---|
| 5058287 | 0 | 85 | 83 | 38 | 50 / 116 | 0,42 (p < 0,001, n = 83) |
| 8447367 | 0 | 79 | 78 | 30 | 30 / 116 | 0,43 (p < 0,001, n = 78) |
| 88691896 | 4 | 73 | 73 | 35 | 35 / 116 | 0,38 (p < 0,001, n = 73) |
| 91860172 | 9 | 46 | 46 | 23 | 25 / 116 | 0,46 (p = 0,0013, n = 46) |
| 81614596 | 0 | 98 | 98 | 11 | 11 / 116 | 0,47 (p < 0,001, n = 98) |
| 30083716 | 16 | 94 | 74 | 37 | 43 / 116 | 0,29 (p = 0,0107, n = 74) |
| 20899730 | 1 | 99 | 97 | 28 | 32 / 116 | 0,48 (p < 0,001, n = 97) |
| 80408816 | 89 | 98 | 98 | 47 | 64 / 116 | 0,43 (p < 0,001, n = 98) |
| 436045 | 36 | 99 | 99 | 34 | 37 / 116 | 0,42 (p < 0,001, n = 99) |
| 73568440 | 94 | 22 | 22 | 16 | 16 / 116 | 0,31 (p = 0,1556, n = 22) |

## Vote 5058287 — modèle « Definitive Cartoon Waifu Tier List » (601 images, 25/10/2025)

Retirés : aucun. Répartition des identifiés : Cartoons 67, Comics 12, Furry 6. Votants par image : 616 à 4802.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Shego | Cartoons | 2805 | 7 856 | 73 |  |
| 2 | 2 | Gwen Stacy (Spider-Verse) | Comics | 2136 | 19 716 | 21 |  |
| 3 | 3 | Chel | Cartoons | 1257 | 11 392 | 49 |  |
| 4 | 4 | Hélène Parr / Elastigirl | Cartoons | 905 | 15 935 | 31 |  |
| 5 | 5 | Starfire | Cartoons | 1465 | 21 791 | 16 |  |
| 6 | 6 | Raven | Cartoons | 1488 | 39 707 | 5 |  |
| 7 | 7 | GoGo Tomago | Cartoons | 3183 | 2 278 | sous 5 011 | compte autocomplétion |
| 8 | 8 | Mavis | Cartoons | 940 | 8 447 | 69 |  |
| 9 | 9 | Tante Cass | Cartoons | 803 | 4 966 | sous 5 011 | compte autocomplétion |
| 10 | 10 | Jessica Rabbit | Cartoons | 2471 | 12 174 | 46 |  |
| 11 | 11 | Blackfire | Comics | 954 | 4 245 | sous 5 011 | identification incertaine; compte autocomplétion |
| 12 | 12 | Lola Bunny | Furry | 1464 | 8 547 | 68 |  |
| 13 | 13 | Wonder Woman | Comics | 1015 | 22 974 | 14 |  |
| 14 | 14 | Kim Possible | Cartoons | 3074 | 12 439 | 45 |  |
| 15 | 15 | Sergent Calhoun | Cartoons | 1018 | 285 | sous 5 011 | compte autocomplétion |
| 16 | 16 | Raiponce | Cartoons | 1241 | 6 348 | 95 | tag générique |
| 17 | 17 | Korra | Cartoons | 3706 | 13 757 | 41 |  |
| 18 | 18 | non identifiée |  | 698 |  |  |  |
| 19 | 19 | Jane Porter | Cartoons | 917 | 2 289 | sous 5 011 | compte autocomplétion |
| 20 | 20 | Batgirl (Barbara Gordon) | Comics | 764 | 7 875 | 72 |  |
| 21 | 21 | Gwen (Total Drama) | Cartoons | 962 | 4 327 | sous 5 011 | compte autocomplétion |
| 22 | 22 | Elsa | Cartoons | 1240 | 14 890 | 37 |  |
| 23 | 23 | Mégara | Cartoons | 2749 | 1 693 | sous 5 011 | compte autocomplétion |
| 24 | 24 | Harley Quinn | Cartoons | 1025 | 26 362 | 9 |  |
| 25 | 25 | Ty Lee | Cartoons | 1641 | 5 660 | 104 |  |
| 26 | 26 | Black Canary | Comics | 988 | 2 613 | sous 5 011 | compte autocomplétion |
| 27 | 27 | Esmeralda | Cartoons | 2487 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 28 | 28 | Supergirl | Comics | 745 | 16 375 | 30 |  |
| 29 | 29 | Daphné | Cartoons | 710 | 6 963 | 86 |  |
| 30 | 30 | non identifiée |  | 1318 |  |  |  |
| 31 | 31 | Mulan | Cartoons | 2286 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 32 | 32 | Vanessa Doofenshmirtz | Cartoons | 1300 | 765 | sous 5 011 | compte autocomplétion |
| 33 | 33 | La sauveteuse (Lilo & Stitch) | Cartoons | 1094 | 973 | sous 5 011 | compte autocomplétion |
| 34 | 34 | Kida | Cartoons | 767 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 35 | 35 | Raven | Cartoons | 1792 | 39 707 | 5 | identification incertaine; 2e image (meilleure : 6) |
| 36 | 36 | Gwen Tennyson | Cartoons | 979 | 21 472 | 17 |  |
| 37 | 37 | Véra (Velma) | Cartoons | 717 | 14 935 | 35 |  |
| 38 | 38 | Jasmine | Cartoons | 3442 | 7 518 | 77 |  |
| 39 | 39 | Marceline | Cartoons | 1559 | 8 284 | 70 |  |
| 40 | 40 | Sara Bellum | Cartoons | 1207 | 1 624 | sous 5 011 | compte autocomplétion |
| 41 | 41 | Vaiana | Cartoons | 4125 | 1 610 | sous 5 011 | tag générique; compte autocomplétion |
| 42 | 42 | non identifiée |  | 704 |  |  |  |
| 43 | 43 | Aurore | Cartoons | 3230 | 2 261 | sous 5 011 | compte autocomplétion |
| 44 | 44 | June (Avatar) | Cartoons | 826 | 292 | sous 5 011 | compte autocomplétion |
| 45 | 45 | Judy Hopps | Furry | 1245 | 26 160 | 10 |  |
| 46 | 46 | La mère de Dexter | Cartoons | 3941 | 20 | sous 5 011 | compte autocomplétion |
| 47 | 47 | Honey Lemon | Cartoons | 3063 | 1 237 | sous 5 011 | compte autocomplétion |
| 48 | 48 | Princesse des flammes | Cartoons | 645 | 1 784 | sous 5 011 | compte autocomplétion |
| 49 | 49 | Wendy Corduroy | Cartoons | 2515 | 5 038 | 116 |  |
| 50 | 50 | Carmen Sandiego | Cartoons | 918 | 560 | sous 5 011 | compte autocomplétion |
| 51 | 51 | April O'Neil | Comics | 1232 | 5 475 | 107 |  |
| 52 | 52 | Poison Ivy | Comics | 665 | 7 409 | 78 |  |
| 53 | 53 | Pocahontas | Cartoons | 1622 | 2 047 | sous 5 011 | compte autocomplétion |
| 54 | 54 | Belle | Cartoons | 1245 | 3 317 | sous 5 011 | compte autocomplétion |
| 55 | 55 | Asami Sato | Cartoons | 831 | 3 611 | sous 5 011 | compte autocomplétion |
| 56 | 56 | Colette (Ratatouille) | Cartoons | 3289 | 487 | sous 5 011 | compte autocomplétion |
| 57 | 57 | Terra | Comics | 1262 | 1 434 | sous 5 011 | compte autocomplétion |
| 58 | 58 | Katara | Cartoons | 770 | 12 083 | 47 |  |
| 59 | 59 | non identifiée |  | 986 |  |  |  |
| 60 | 60 | non identifiée |  | 1420 |  |  |  |
| 61 | 61 | Anna | Cartoons | 3476 | 6 383 | 93 |  |
| 62 | 62 | Violette Parr | Cartoons | 1675 | 7 665 | 75 |  |
| 63 | 63 | non identifiée |  | 620 |  |  |  |
| 64 | 64 | Susan / Génormica | Cartoons | 1351 | 277 | sous 5 011 | compte autocomplétion |
| 65 | 65 | Nicole Watterson | Furry | 1127 | 9 366 | 63 | identification incertaine |
| 66 | 66 | Clover | Cartoons | 625 | 2 826 | sous 5 011 | compte autocomplétion |
| 67 | 67 | Fionna | Cartoons | 1343 | 5 055 | 115 |  |
| 68 | 68 | Sam (Totally Spies) | Cartoons | 1019 | 3 099 | sous 5 011 | compte autocomplétion |
| 69 | 69 | Helga Sinclair | Cartoons | 750 | 421 | sous 5 011 | compte autocomplétion |
| 70 | 70 | Malicia (Rogue) | Comics | 1416 | 8 641 | 67 |  |
| 71 | 71 | Tiana | Cartoons | 870 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 72 | 72 | non identifiée |  | 3509 |  |  |  |
| 73 | 73 | Ember McLain | Cartoons | 3515 | 758 | sous 5 011 | compte autocomplétion |
| 74 | 74 | non identifiée |  | 620 |  |  |  |
| 75 | 75 | Charlotte La Bouff | Cartoons | 1376 | 224 | sous 5 011 | compte autocomplétion |
| 76 | 76 | Bridgette | Cartoons | 885 | 979 | sous 5 011 | compte autocomplétion |
| 77 | 77 | Mai (Avatar) | Cartoons | 4802 | 2 370 | sous 5 011 | compte autocomplétion |
| 78 | 78 | La Muerte | Cartoons | 928 | 122 | sous 5 011 | compte autocomplétion |
| 79 | 79 | non identifiée |  | 3147 |  |  |  |
| 80 | 80 | non identifiée |  | 757 |  |  |  |
| 81 | 81 | Supergirl | Comics | 639 | 16 375 | 30 | 2e image (meilleure : 28) |
| 82 | 82 | Courtney | Cartoons | 876 | 2 127 | sous 5 011 | compte autocomplétion |
| 83 | 83 | Hawkgirl | Comics | 673 | 917 | sous 5 011 | compte autocomplétion |
| 84 | 84 | Francine Smith | Cartoons | 1878 | 4 122 | sous 5 011 | compte autocomplétion |
| 85 | 85 | non identifiée |  | 1111 |  |  |  |
| 86 | 86 | Loona | Furry | 1013 | 43 049 | 2 |  |
| 87 | 87 | non identifiée |  | 1765 |  |  |  |
| 88 | 88 | Toph | Cartoons | 3507 | 9 643 | 60 |  |
| 89 | 89 | Sam Manson | Cartoons | 2112 | 1 735 | sous 5 011 | compte autocomplétion |
| 90 | 90 | Dani Phantom | Cartoons | 1201 | 264 | sous 5 011 | compte autocomplétion |
| 91 | 91 | Marinette / Ladybug | Cartoons | 847 | 6 437 | 91 |  |
| 92 | 92 | Sally (Cars) | Cartoons | 708 | 41 | sous 5 011 | compte autocomplétion |
| 93 | 93 | Millie | Furry | 1213 | 9 057 | 64 |  |
| 94 | 94 | non identifiée |  | 1016 |  |  |  |
| 95 | 95 | Flo (Cars) | Cartoons | 2301 | 4 | sous 5 011 | compte autocomplétion |
| 96 | 96 | non identifiée |  | 616 |  |  |  |
| 97 | 97 | Audrey Ramirez | Cartoons | 3097 | 397 | sous 5 011 | compte autocomplétion |
| 98 | 98 | Nani | Cartoons | 660 | 2 915 | sous 5 011 | compte autocomplétion |
| 99 | 99 | Tigresse | Furry | 1304 | 5 210 | 112 |  |
| 100 | 100 | non identifiée |  | 1427 |  |  |  |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | 86 | 1013 |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 6 | 1488 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | 146 | 4340 |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | 104 | 1354 |
| 9 | Harley Quinn | Cartoons | 26 362 | 24 | 1025 |
| 10 | Judy Hopps | Furry | 26 160 | 45 | 1245 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | 136 | 1843 |
| 14 | Wonder Woman | Comics | 22 974 | 13 | 1015 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | 117 | 2336 |
| 16 | Starfire | Cartoons | 21 791 | 5 | 1465 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | 36 | 979 |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 2 | 2136 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | 179 | 1453 |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | 128 | 2932 |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | 267 | 1404 |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | 197 | 2304 |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | 28 | 745 |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 4 | 905 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | non trouvé |  |
| 35 | Véra (Velma) | Cartoons | 14 935 | 37 | 717 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 22 | 1240 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 130 | 636 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 17 | 3706 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | non trouvé |  |
| 45 | Kim Possible | Cartoons | 12 439 | 14 | 3074 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 10 | 2471 |
| 47 | Katara | Cartoons | 12 083 | 58 | 770 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 3 | 1257 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | 106 (incertain) | 1342 |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | non trouvé |  |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 101 | 847 |
| 60 | Toph | Cartoons | 9 643 | 88 | 3507 |
| 61 | Sally Acorn | Furry | 9 562 | 370 (incertain) | 1220 |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | 65 (incertain) | 1127 |
| 64 | Millie | Furry | 9 057 | 93 | 1213 |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | 70 | 1416 |
| 68 | Lola Bunny | Furry | 8 547 | 12 | 1464 |
| 69 | Mavis | Cartoons | 8 447 | 8 | 940 |
| 70 | Marceline | Cartoons | 8 284 | 39 | 1559 |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 20 | 764 |
| 73 | Shego | Cartoons | 7 856 | 1 | 2805 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | 62 | 1675 |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 38 | 3442 |
| 78 | Poison Ivy | Comics | 7 409 | 52 | 665 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 29 | 710 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | 91 | 847 |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 61 | 3476 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | 16 | 1241 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 25 | 1641 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 51 | 1232 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | 99 | 1304 |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | 67 | 1343 |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 49 | 2515 |

## Vote 8447367 — modèle « Cartoon Girls » (229 images, 03/10/2025)

Retirés : aucun. Répartition des identifiés : Cartoons 73, Comics 1, Furry 5. Votants par image : 2278 à 8249.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Chel | Cartoons | 3872 | 11 392 | 49 |  |
| 2 | 2 | Hélène Parr / Elastigirl | Cartoons | 8249 | 15 935 | 31 |  |
| 3 | 3 | Lola Bunny | Furry | 3438 | 8 547 | 68 |  |
| 4 | 4 | Jessica Rabbit | Cartoons | 4152 | 12 174 | 46 |  |
| 5 | 5 | Gwen Stacy (Spider-Verse) | Comics | 3783 | 19 716 | 21 |  |
| 6 | 6 | Mavis | Cartoons | 2897 | 8 447 | 69 |  |
| 7 | 7 | Shego | Cartoons | 4652 | 7 856 | 73 |  |
| 8 | 8 | Starfire | Cartoons | 3930 | 21 791 | 16 |  |
| 9 | 9 | Jane Porter | Cartoons | 2867 | 2 289 | sous 5 011 | compte autocomplétion |
| 10 | 10 | Kim Possible | Cartoons | 5123 | 12 439 | 45 |  |
| 11 | 11 | Elsa | Cartoons | 3058 | 14 890 | 37 |  |
| 12 | 12 | Jasmine | Cartoons | 5118 | 7 518 | 77 |  |
| 13 | 13 | GoGo Tomago | Cartoons | 5237 | 2 278 | sous 5 011 | compte autocomplétion |
| 14 | 14 | Daphné | Cartoons | 3240 | 6 963 | 86 |  |
| 15 | 15 | Raven | Cartoons | 3930 | 39 707 | 5 |  |
| 16 | 16 | Sara Bellum | Cartoons | 6171 | 1 624 | sous 5 011 | compte autocomplétion |
| 17 | 17 | Sam Manson | Cartoons | 3000 | 1 735 | sous 5 011 | compte autocomplétion |
| 18 | 18 | Lola Bunny | Furry | 3316 | 8 547 | 68 | 2e image (meilleure : 3) |
| 19 | 19 | Asami Sato | Cartoons | 4093 | 3 611 | sous 5 011 | compte autocomplétion |
| 20 | 20 | Raiponce | Cartoons | 4856 | 6 348 | 95 | tag générique |
| 21 | 21 | Mégara | Cartoons | 4677 | 1 693 | sous 5 011 | compte autocomplétion |
| 22 | 22 | Ariel | Cartoons | 2633 | 4 354 | sous 5 011 | compte autocomplétion |
| 23 | 23 | Korra | Cartoons | 5617 | 13 757 | 41 |  |
| 24 | 24 | Kida | Cartoons | 7286 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 25 | 25 | non identifiée |  | 2833 |  |  |  |
| 26 | 26 | non identifiée |  | 2424 |  |  |  |
| 27 | 27 | Esmeralda | Cartoons | 4072 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 28 | 28 | Mulan | Cartoons | 2817 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 29 | 29 | Vaiana | Cartoons | 6116 | 1 610 | sous 5 011 | tag générique; compte autocomplétion |
| 30 | 30 | Aurore | Cartoons | 5282 | 2 261 | sous 5 011 | compte autocomplétion |
| 31 | 31 | June (Avatar) | Cartoons | 2590 | 292 | sous 5 011 | compte autocomplétion |
| 32 | 32 | Véra (Velma) | Cartoons | 3206 | 14 935 | 35 |  |
| 33 | 33 | Belle | Cartoons | 2950 | 3 317 | sous 5 011 | compte autocomplétion |
| 34 | 34 | Judy Hopps | Furry | 3012 | 26 160 | 10 |  |
| 35 | 35 | Vanessa Doofenshmirtz | Cartoons | 2931 | 765 | sous 5 011 | compte autocomplétion |
| 36 | 36 | Helga Sinclair | Cartoons | 2418 | 421 | sous 5 011 | compte autocomplétion |
| 37 | 37 | Anna | Cartoons | 5623 | 6 383 | 93 |  |
| 38 | 38 | Pocahontas | Cartoons | 2964 | 2 047 | sous 5 011 | compte autocomplétion |
| 39 | 39 | Ty Lee | Cartoons | 4122 | 5 660 | 104 |  |
| 40 | 40 | Trixie Tang | Cartoons | 2931 | 1 354 | sous 5 011 | compte autocomplétion |
| 41 | 41 | Marceline | Cartoons | 2883 | 8 284 | 70 |  |
| 42 | 42 | non identifiée |  | 3150 |  |  |  |
| 43 | 43 | non identifiée |  | 2504 |  |  |  |
| 44 | 44 | Honey Lemon | Cartoons | 5022 | 1 237 | sous 5 011 | compte autocomplétion |
| 45 | 45 | Tiana | Cartoons | 2710 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 46 | 46 | Wendy Corduroy | Cartoons | 4043 | 5 038 | 116 |  |
| 47 | 47 | non identifiée |  | 2542 |  |  |  |
| 48 | 48 | Nani | Cartoons | 2780 | 2 915 | sous 5 011 | compte autocomplétion |
| 49 | 49 | Katara | Cartoons | 7353 | 12 083 | 47 |  |
| 50 | 50 | Marinette / Ladybug | Cartoons | 2664 | 6 437 | 91 |  |
| 51 | 51 | Sam (Totally Spies) | Cartoons | 4324 | 3 099 | sous 5 011 | compte autocomplétion |
| 52 | 52 | Leela | Cartoons | 3059 | 2 896 | sous 5 011 | compte autocomplétion |
| 53 | 53 | Colette (Ratatouille) | Cartoons | 5306 | 487 | sous 5 011 | compte autocomplétion |
| 54 | 54 | Flo (Cars) | Cartoons | 3865 | 4 | sous 5 011 | compte autocomplétion |
| 55 | 55 | Red Hot Riding Hood | Cartoons | 2696 | 229 | sous 5 011 | compte autocomplétion |
| 56 | 56 | Cendrillon | Cartoons | 2542 | 1 570 | sous 5 011 | compte autocomplétion |
| 57 | 57 | Audrey Ramirez | Cartoons | 5109 | 397 | sous 5 011 | compte autocomplétion |
| 58 | 58 | Merida | Cartoons | 4107 | 1 216 | sous 5 011 | compte autocomplétion |
| 59 | 59 | Fée Clochette | Cartoons | 2978 | 3 867 | sous 5 011 | compte autocomplétion |
| 60 | 60 | Mai (Avatar) | Cartoons | 6806 | 2 370 | sous 5 011 | compte autocomplétion |
| 61 | 61 | Ember McLain | Cartoons | 5402 | 758 | sous 5 011 | compte autocomplétion |
| 62 | 62 | Princesse Chewing-gum | Cartoons | 2624 | 9 974 | 59 |  |
| 63 | 63 | non identifiée |  | 3410 |  |  |  |
| 64 | 64 | Dégoût | Cartoons | 7730 | 1 569 | sous 5 011 | compte autocomplétion |
| 65 | 65 | non identifiée |  | 3040 |  |  |  |
| 66 | 66 | Marge Simpson | Cartoons | 3749 | 8 044 | 71 |  |
| 67 | 67 | Clover | Cartoons | 3998 | 2 826 | sous 5 011 | compte autocomplétion |
| 68 | 68 | Rose Quartz | Cartoons | 6349 | 676 | sous 5 011 | compte autocomplétion |
| 69 | 69 | Isabela Madrigal | Cartoons | 3044 | 482 | sous 5 011 | compte autocomplétion |
| 70 | 70 | non identifiée |  | 2865 |  |  |  |
| 71 | 71 | Toph | Cartoons | 5331 | 9 643 | 60 |  |
| 72 | 72 | Roxanne | Furry | 2407 | 1 705 | sous 5 011 | compte autocomplétion |
| 73 | 73 | Blanche-Neige | Cartoons | 2452 | 2 457 | sous 5 011 | compte autocomplétion |
| 74 | 74 | Lois Griffin | Cartoons | 3643 | 6 381 | 94 |  |
| 75 | 75 | non identifiée |  | 2400 |  |  |  |
| 76 | 76 | non identifiée |  | 4862 |  |  |  |
| 77 | 77 | Jazz Fenton | Cartoons | 2716 | 828 | sous 5 011 | compte autocomplétion |
| 78 | 78 | non identifiée |  | 2346 |  |  |  |
| 79 | 79 | non identifiée |  | 2359 |  |  |  |
| 80 | 80 | non identifiée |  | 3123 |  |  |  |
| 81 | 81 | Alex | Cartoons | 3690 | 2 645 | sous 5 011 | compte autocomplétion |
| 82 | 82 | non identifiée |  | 2903 |  |  |  |
| 83 | 83 | Wilma Pierrafeu | Cartoons | 2939 | 716 | sous 5 011 | compte autocomplétion |
| 84 | 84 | Bo la bergère | Cartoons | 8102 | 244 | sous 5 011 | compte autocomplétion |
| 85 | 85 | Kitty Katswell | Furry | 2520 | 2 825 | sous 5 011 | compte autocomplétion |
| 86 | 86 | Lapis Lazuli | Cartoons | 4003 | 5 844 | 101 |  |
| 87 | 87 | Star Butterfly | Cartoons | 4062 | 5 697 | 102 |  |
| 88 | 88 | Mère Gothel | Cartoons | 4145 | 786 | sous 5 011 | compte autocomplétion |
| 89 | 89 | non identifiée |  | 6517 |  |  |  |
| 90 | 90 | non identifiée |  | 2638 |  |  |  |
| 91 | 91 | Jessie (Toy Story) | Cartoons | 4932 | 600 | sous 5 011 | compte autocomplétion |
| 92 | 92 | non identifiée |  | 2970 |  |  |  |
| 93 | 93 | Beth Smith | Cartoons | 3136 | 1 920 | sous 5 011 | compte autocomplétion |
| 94 | 94 | Alice | Cartoons | 2611 | 3 616 | sous 5 011 | compte autocomplétion |
| 95 | 95 | non identifiée |  | 2286 |  |  |  |
| 96 | 96 | non identifiée |  | 2613 |  |  |  |
| 97 | 97 | Linda Flynn-Fletcher | Cartoons | 2278 | 603 | sous 5 011 | compte autocomplétion |
| 98 | 98 | non identifiée |  | 4528 |  |  |  |
| 99 | 99 | Frankie Foster | Cartoons | 2324 | 6 704 | 89 |  |
| 100 | 100 | non identifiée |  | 3182 |  |  |  |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 15 | 3930 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | non trouvé |  |
| 10 | Judy Hopps | Furry | 26 160 | 34 | 3012 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | non trouvé |  |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 8 | 3930 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | non trouvé |  |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 5 | 3783 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | non trouvé |  |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 2 | 8249 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | non trouvé |  |
| 35 | Véra (Velma) | Cartoons | 14 935 | 32 | 3206 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 11 | 3058 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | non trouvé |  |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 23 | 5617 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | non trouvé |  |
| 45 | Kim Possible | Cartoons | 12 439 | 10 | 5123 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 4 | 4152 |
| 47 | Katara | Cartoons | 12 083 | 49 | 7353 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 1 | 3872 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | non trouvé |  |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 62 | 2624 |
| 60 | Toph | Cartoons | 9 643 | 71 | 5331 |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | non trouvé |  |
| 68 | Lola Bunny | Furry | 8 547 | 3 | 3438 |
| 69 | Mavis | Cartoons | 8 447 | 6 | 2897 |
| 70 | Marceline | Cartoons | 8 284 | 41 | 2883 |
| 71 | Marge Simpson | Cartoons | 8 044 | 66 | 3749 |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | non trouvé |  |
| 73 | Shego | Cartoons | 7 856 | 7 | 4652 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 12 | 5118 |
| 78 | Poison Ivy | Comics | 7 409 | non trouvé |  |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 14 | 3240 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | 99 | 2324 |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | 50 | 2664 |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 37 | 5623 |
| 94 | Lois Griffin | Cartoons | 6 381 | 74 | 3643 |
| 95 | Raiponce | Cartoons | 6 348 | 20 | 4856 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | 86 | 4003 |
| 102 | Star Butterfly | Cartoons | 5 697 | 87 | 4062 |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 39 | 4122 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | non trouvé |  |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 46 | 4043 |

## Vote 88691896 — modèle « Hottest Female Cartoon Characters » (200 images, 09/02/2025)

Retirés : Jinx (League of Legends) (45), Carmilla (46), Sypha Belnades (47), Vi (Arcane) (74). Répartition des identifiés : Cartoons 56, Comics 13, Furry 4. Votants par image : 3361 à 9958.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Hélène Parr / Elastigirl | Cartoons | 4101 | 15 935 | 31 |  |
| 2 | 2 | Kim Possible | Cartoons | 4254 | 12 439 | 45 |  |
| 3 | 3 | Jessica Rabbit | Cartoons | 8150 | 12 174 | 46 |  |
| 4 | 4 | Black Canary | Comics | 3632 | 2 613 | sous 5 011 | compte autocomplétion |
| 5 | 5 | Chel | Cartoons | 3667 | 11 392 | 49 |  |
| 6 | 6 | Black Cat | Comics | 8512 | 15 119 | 34 |  |
| 7 | 7 | Shego | Cartoons | 9958 | 7 856 | 73 |  |
| 8 | 8 | Wonder Woman | Comics | 3776 | 22 974 | 14 |  |
| 9 | 9 | Raven | Cartoons | 3834 | 39 707 | 5 |  |
| 10 | 10 | Starfire | Cartoons | 3791 | 21 791 | 16 |  |
| 11 | 11 | Blackfire | Comics | 3694 | 4 245 | sous 5 011 | identification incertaine; compte autocomplétion |
| 12 | 12 | Tante Cass | Cartoons | 3916 | 4 966 | sous 5 011 | compte autocomplétion |
| 13 | 13 | Gwen Stacy (Spider-Verse) | Comics | 4563 | 19 716 | 21 |  |
| 14 | 14 | Harley Quinn | Cartoons | 3807 | 26 362 | 9 |  |
| 15 | 15 | Lola Bunny | Furry | 3688 | 8 547 | 68 |  |
| 16 | 16 | Mavis | Cartoons | 3637 | 8 447 | 69 |  |
| 17 | 17 | Sam Manson | Cartoons | 4312 | 1 735 | sous 5 011 | compte autocomplétion |
| 18 | 18 | Mégara | Cartoons | 4102 | 1 693 | sous 5 011 | compte autocomplétion |
| 19 | 19 | Zatanna | Comics | 3559 | 3 952 | sous 5 011 | compte autocomplétion |
| 20 | 20 | Ty Lee | Cartoons | 3564 | 5 660 | 104 |  |
| 21 | 21 | Catwoman | Comics | 4138 | 10 167 | 56 |  |
| 22 | 22 | Jasmine | Cartoons | 4168 | 7 518 | 77 |  |
| 23 | 23 | Azula | Cartoons | 3535 | 12 587 | 44 |  |
| 24 | 24 | Gwen (Total Drama) | Cartoons | 3775 | 4 327 | sous 5 011 | compte autocomplétion |
| 25 | 25 | Korra | Cartoons | 3559 | 13 757 | 41 |  |
| 26 | 26 | Daphné | Cartoons | 3864 | 6 963 | 86 |  |
| 27 | 27 | Batgirl (Barbara Gordon) | Comics | 3937 | 7 875 | 72 |  |
| 28 | 28 | Sara Bellum | Cartoons | 8940 | 1 624 | sous 5 011 | compte autocomplétion |
| 29 | 29 | Jane Porter | Cartoons | 4059 | 2 289 | sous 5 011 | compte autocomplétion |
| 30 | 30 | Kida | Cartoons | 3903 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 31 | 31 | non identifiée |  | 4647 |  |  |  |
| 32 | 32 | non identifiée |  | 3706 |  |  |  |
| 33 | 33 | non identifiée |  | 4779 |  |  |  |
| 34 | 34 | Atom Eve | Comics | 5518 | 3 662 | sous 5 011 | compte autocomplétion |
| 35 | 35 | Belle | Cartoons | 4076 | 3 317 | sous 5 011 | compte autocomplétion |
| 36 | 36 | non identifiée |  | 5725 |  |  |  |
| 37 | 37 | non identifiée |  | 3553 |  |  |  |
| 38 | 38 | April O'Neil | Comics | 7942 | 5 475 | 107 |  |
| 39 | 39 | Asami Sato | Cartoons | 3435 | 3 611 | sous 5 011 | compte autocomplétion |
| 40 | 40 | Esmeralda | Cartoons | 4003 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 41 | 41 | non identifiée |  | 3471 |  |  |  |
| 42 | 42 | Elsa | Cartoons | 4061 | 14 890 | 37 |  |
| 43 | 43 | Nani | Cartoons | 4036 | 2 915 | sous 5 011 | compte autocomplétion |
| 44 | 44 | non identifiée |  | 3860 |  |  |  |
| 45 | 48 | Anna | Cartoons | 4023 | 6 383 | 93 |  |
| 46 | 49 | Marceline | Cartoons | 3487 | 8 284 | 70 |  |
| 47 | 50 | Ariel | Cartoons | 4260 | 4 354 | sous 5 011 | compte autocomplétion |
| 48 | 51 | Véra (Velma) | Cartoons | 3849 | 14 935 | 35 |  |
| 49 | 52 | Katara | Cartoons | 3497 | 12 083 | 47 |  |
| 50 | 53 | non identifiée |  | 7538 |  |  |  |
| 51 | 54 | non identifiée |  | 3498 |  |  |  |
| 52 | 55 | Alex | Cartoons | 4109 | 2 645 | sous 5 011 | compte autocomplétion |
| 53 | 56 | Sam (Totally Spies) | Cartoons | 4126 | 3 099 | sous 5 011 | compte autocomplétion |
| 54 | 57 | Heather | Cartoons | 3705 | 2 404 | sous 5 011 | compte autocomplétion |
| 55 | 58 | Mulan | Cartoons | 4035 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 56 | 59 | Clover | Cartoons | 4089 | 2 826 | sous 5 011 | compte autocomplétion |
| 57 | 60 | non identifiée |  | 3478 |  |  |  |
| 58 | 61 | Tiana | Cartoons | 3902 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 59 | 62 | non identifiée |  | 3810 |  |  |  |
| 60 | 63 | Suki | Cartoons | 3441 | 1 534 | sous 5 011 | tag générique; compte autocomplétion |
| 61 | 64 | Princesse des flammes | Cartoons | 3478 | 1 784 | sous 5 011 | compte autocomplétion |
| 62 | 65 | Pocahontas | Cartoons | 4013 | 2 047 | sous 5 011 | compte autocomplétion |
| 63 | 66 | non identifiée |  | 5339 |  |  |  |
| 64 | 67 | Raya | Cartoons | 4350 | 214 | sous 5 011 | compte autocomplétion |
| 65 | 68 | non identifiée |  | 4768 |  |  |  |
| 66 | 69 | Fée Clochette | Cartoons | 4354 | 3 867 | sous 5 011 | compte autocomplétion |
| 67 | 70 | Colette (Ratatouille) | Cartoons | 3873 | 487 | sous 5 011 | compte autocomplétion |
| 68 | 71 | non identifiée |  | 3526 |  |  |  |
| 69 | 72 | non identifiée |  | 3419 |  |  |  |
| 70 | 73 | Malicia (Rogue) | Comics | 3451 | 8 641 | 67 |  |
| 71 | 75 | Audrey Ramirez | Cartoons | 3772 | 397 | sous 5 011 | compte autocomplétion |
| 72 | 76 | Mystique | Comics | 3419 | 1 502 | sous 5 011 | compte autocomplétion |
| 73 | 77 | non identifiée |  | 4290 |  |  |  |
| 74 | 78 | non identifiée |  | 5263 |  |  |  |
| 75 | 79 | Judy Hopps | Furry | 4013 | 26 160 | 10 |  |
| 76 | 80 | Anastasia | Cartoons | 4781 | 188 | sous 5 011 | compte autocomplétion |
| 77 | 81 | non identifiée |  | 4657 |  |  |  |
| 78 | 82 | non identifiée |  | 4463 |  |  |  |
| 79 | 83 | Mai (Avatar) | Cartoons | 3452 | 2 370 | sous 5 011 | identification incertaine; compte autocomplétion |
| 80 | 84 | non identifiée |  | 6462 |  |  |  |
| 81 | 85 | La mère de Dexter | Cartoons | 4533 | 20 | sous 5 011 | compte autocomplétion |
| 82 | 86 | Fionna | Cartoons | 3443 | 5 055 | 115 |  |
| 83 | 87 | Tornade (Storm) | Comics | 3422 | 4 390 | sous 5 011 | compte autocomplétion |
| 84 | 88 | Loona | Furry | 4115 | 43 049 | 2 |  |
| 85 | 89 | Princesse Chewing-gum | Cartoons | 3495 | 9 974 | 59 |  |
| 86 | 90 | Lady Amalthea | Cartoons | 4085 | 82 | sous 5 011 | compte autocomplétion |
| 87 | 91 | non identifiée |  | 5331 |  |  |  |
| 88 | 92 | Ember McLain | Cartoons | 3361 | 758 | sous 5 011 | compte autocomplétion |
| 89 | 93 | Cendrillon | Cartoons | 5502 | 1 570 | sous 5 011 | compte autocomplétion |
| 90 | 94 | non identifiée |  | 6354 |  |  |  |
| 91 | 95 | Millie | Furry | 4050 | 9 057 | 64 |  |
| 92 | 96 | Leela | Cartoons | 6335 | 2 896 | sous 5 011 | compte autocomplétion |
| 93 | 97 | non identifiée |  | 4438 |  |  |  |
| 94 | 98 | Frankie Foster | Cartoons | 3368 | 6 704 | 89 |  |
| 95 | 99 | non identifiée |  | 8035 |  |  |  |
| 96 | 100 | non identifiée |  | 4177 |  |  |  |
| 97 | 101 | Ahsoka Tano | Cartoons | 3442 | 14 807 | 38 |  |
| 98 | 102 | non identifiée |  | 5305 |  |  |  |
| 99 | 103 | Charlie Morningstar | Cartoons | 8506 | 10 604 | 53 |  |
| 100 | 104 | non identifiée |  | 3497 |  |  |  |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | 88 | 4115 |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 9 | 3834 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | 14 | 3807 |
| 10 | Judy Hopps | Furry | 26 160 | 79 | 4013 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | 8 | 3776 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 10 | 3791 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | non trouvé |  |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 13 | 4563 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | non trouvé |  |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 1 | 4101 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | 6 | 8512 |
| 35 | Véra (Velma) | Cartoons | 14 935 | 51 | 3849 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 42 | 4061 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 101 | 3442 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 25 | 3559 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | 23 | 3535 |
| 45 | Kim Possible | Cartoons | 12 439 | 2 | 4254 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 3 | 8150 |
| 47 | Katara | Cartoons | 12 083 | 52 | 3497 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 5 | 3667 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | 103 | 8506 |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | 21 | 4138 |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 89 | 3495 |
| 60 | Toph | Cartoons | 9 643 | non trouvé |  |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | 95 | 4050 |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | 73 | 3451 |
| 68 | Lola Bunny | Furry | 8 547 | 15 | 3688 |
| 69 | Mavis | Cartoons | 8 447 | 16 | 3637 |
| 70 | Marceline | Cartoons | 8 284 | 49 | 3487 |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 27 | 3937 |
| 73 | Shego | Cartoons | 7 856 | 7 | 9958 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 22 | 4168 |
| 78 | Poison Ivy | Comics | 7 409 | non trouvé |  |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 26 | 3864 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | 98 | 3368 |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 48 | 4023 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | non trouvé |  |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 20 | 3564 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 38 | 7942 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | 86 | 3443 |
| 116 | Wendy Corduroy | Cartoons | 5 038 | non trouvé |  |

## Vote 91860172 — modèle « Hottest Animated Women Crushes Ranked » (214 images, 21/09/2025)

Retirés : Widowmaker (4), D.Va (5), Mercy (7), Peach (film Super Mario Bros.) (34), Tracer (38), Mei (Overwatch) (48), Symmetra (58), Pharah (72), Brigitte (79). Répartition des identifiés : Cartoons 28, Comics 18, Furry 0. Votants par image : 2149 à 9270.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Chel | Cartoons | 6980 | 11 392 | 49 |  |
| 2 | 2 | Hélène Parr / Elastigirl | Cartoons | 6845 | 15 935 | 31 |  |
| 3 | 3 | Tante Cass | Cartoons | 2861 | 4 966 | sous 5 011 | compte autocomplétion |
| 4 | 6 | Raven | Cartoons | 4194 | 39 707 | 5 |  |
| 5 | 8 | non identifiée |  | 4658 |  |  |  |
| 6 | 9 | Kim Possible | Cartoons | 5035 | 12 439 | 45 |  |
| 7 | 10 | Starfire | Cartoons | 6067 | 21 791 | 16 |  |
| 8 | 11 | Black Canary | Comics | 3915 | 2 613 | sous 5 011 | identification incertaine; compte autocomplétion |
| 9 | 12 | Daphné | Cartoons | 3125 | 6 963 | 86 | identification incertaine |
| 10 | 13 | Jessica Rabbit | Cartoons | 9270 | 12 174 | 46 |  |
| 11 | 14 | Shego | Cartoons | 8348 | 7 856 | 73 |  |
| 12 | 15 | Jasmine | Cartoons | 7625 | 7 518 | 77 |  |
| 13 | 16 | non identifiée |  | 4927 |  |  |  |
| 14 | 17 | Black Widow | Comics | 7068 | 10 379 | 55 | identification incertaine |
| 15 | 18 | GoGo Tomago | Cartoons | 2801 | 2 278 | sous 5 011 | compte autocomplétion |
| 16 | 19 | Sergent Calhoun | Cartoons | 2803 | 285 | sous 5 011 | compte autocomplétion |
| 17 | 20 | Wonder Woman | Comics | 3867 | 22 974 | 14 |  |
| 18 | 21 | Kida | Cartoons | 6811 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 19 | 22 | Mégara | Cartoons | 2629 | 1 693 | sous 5 011 | compte autocomplétion |
| 20 | 23 | non identifiée |  | 4565 |  |  |  |
| 21 | 24 | Harley Quinn | Cartoons | 3382 | 26 362 | 9 |  |
| 22 | 25 | Poison Ivy | Comics | 6345 | 7 409 | 78 |  |
| 23 | 26 | Catwoman | Comics | 3137 | 10 167 | 56 |  |
| 24 | 27 | Supergirl | Comics | 3845 | 16 375 | 30 |  |
| 25 | 28 | Elsa | Cartoons | 2698 | 14 890 | 37 |  |
| 26 | 29 | non identifiée |  | 5751 |  |  |  |
| 27 | 30 | Zatanna | Comics | 7654 | 3 952 | sous 5 011 | compte autocomplétion |
| 28 | 31 | Black Cat | Comics | 6276 | 15 119 | 34 |  |
| 29 | 32 | non identifiée |  | 5175 |  |  |  |
| 30 | 33 | non identifiée |  | 2767 |  |  |  |
| 31 | 35 | non identifiée |  | 2468 |  |  |  |
| 32 | 36 | non identifiée |  | 3236 |  |  |  |
| 33 | 37 | non identifiée |  | 2348 |  |  |  |
| 34 | 39 | non identifiée |  | 5373 |  |  |  |
| 35 | 40 | Véra (Velma) | Cartoons | 3244 | 14 935 | 35 |  |
| 36 | 41 | Belle | Cartoons | 3377 | 3 317 | sous 5 011 | compte autocomplétion |
| 37 | 42 | non identifiée |  | 2667 |  |  |  |
| 38 | 43 | La sauveteuse (Lilo & Stitch) | Cartoons | 2938 | 973 | sous 5 011 | compte autocomplétion |
| 39 | 44 | non identifiée |  | 4506 |  |  |  |
| 40 | 45 | non identifiée |  | 3964 |  |  |  |
| 41 | 46 | Power Girl | Comics | 8421 | 13 942 | 40 |  |
| 42 | 47 | Huntress | Comics | 2882 | 902 | sous 5 011 | compte autocomplétion |
| 43 | 49 | non identifiée |  | 2395 |  |  |  |
| 44 | 50 | non identifiée |  | 3836 |  |  |  |
| 45 | 51 | Femme invisible | Comics | 2394 | 10 816 | 52 |  |
| 46 | 52 | Helga Sinclair | Cartoons | 2750 | 421 | sous 5 011 | compte autocomplétion |
| 47 | 53 | non identifiée |  | 5073 |  |  |  |
| 48 | 54 | non identifiée |  | 7339 |  |  |  |
| 49 | 55 | Sara Bellum | Cartoons | 4023 | 1 624 | sous 5 011 | compte autocomplétion |
| 50 | 56 | non identifiée |  | 7113 |  |  |  |
| 51 | 57 | non identifiée |  | 2164 |  |  |  |
| 52 | 59 | Fée Clochette | Cartoons | 4189 | 3 867 | sous 5 011 | compte autocomplétion |
| 53 | 60 | Ariel | Cartoons | 8068 | 4 354 | sous 5 011 | compte autocomplétion |
| 54 | 61 | non identifiée |  | 3581 |  |  |  |
| 55 | 62 | non identifiée |  | 3424 |  |  |  |
| 56 | 63 | non identifiée |  | 5117 |  |  |  |
| 57 | 64 | non identifiée |  | 2298 |  |  |  |
| 58 | 65 | April O'Neil | Comics | 2809 | 5 475 | 107 |  |
| 59 | 66 | non identifiée |  | 3207 |  |  |  |
| 60 | 67 | Malicia (Rogue) | Comics | 5671 | 8 641 | 67 |  |
| 61 | 68 | Emma Frost | Comics | 3290 | 20 269 | 19 |  |
| 62 | 69 | non identifiée |  | 3516 |  |  |  |
| 63 | 70 | non identifiée |  | 4177 |  |  |  |
| 64 | 71 | Lindsay | Cartoons | 5624 | 2 535 | sous 5 011 | compte autocomplétion |
| 65 | 73 | non identifiée |  | 3672 |  |  |  |
| 66 | 74 | non identifiée |  | 2524 |  |  |  |
| 67 | 75 | non identifiée |  | 6589 |  |  |  |
| 68 | 76 | non identifiée |  | 2560 |  |  |  |
| 69 | 77 | non identifiée |  | 4341 |  |  |  |
| 70 | 78 | non identifiée |  | 4201 |  |  |  |
| 71 | 80 | Pocahontas | Cartoons | 3425 | 2 047 | sous 5 011 | compte autocomplétion |
| 72 | 81 | Tiana | Cartoons | 2769 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 73 | 82 | non identifiée |  | 2452 |  |  |  |
| 74 | 83 | Sorcière rouge | Comics | 2973 | 4 969 | sous 5 011 | compte autocomplétion |
| 75 | 84 | non identifiée |  | 3544 |  |  |  |
| 76 | 85 | La Guêpe | Comics | 5411 | 1 236 | sous 5 011 | compte autocomplétion |
| 77 | 86 | non identifiée |  | 2619 |  |  |  |
| 78 | 87 | Nani | Cartoons | 2629 | 2 915 | sous 5 011 | compte autocomplétion |
| 79 | 88 | non identifiée |  | 4601 |  |  |  |
| 80 | 89 | non identifiée |  | 3803 |  |  |  |
| 81 | 90 | non identifiée |  | 2452 |  |  |  |
| 82 | 91 | non identifiée |  | 3730 |  |  |  |
| 83 | 92 | Courtney | Cartoons | 4396 | 2 127 | sous 5 011 | compte autocomplétion |
| 84 | 93 | non identifiée |  | 3371 |  |  |  |
| 85 | 94 | non identifiée |  | 6013 |  |  |  |
| 86 | 95 | non identifiée |  | 2456 |  |  |  |
| 87 | 96 | Hawkgirl | Comics | 2502 | 917 | sous 5 011 | compte autocomplétion |
| 88 | 97 | non identifiée |  | 2261 |  |  |  |
| 89 | 98 | non identifiée |  | 2563 |  |  |  |
| 90 | 99 | non identifiée |  | 2291 |  |  |  |
| 91 | 100 | non identifiée |  | 3620 |  |  |  |
| 92 | 101 | non identifiée |  | 2617 |  |  |  |
| 93 | 102 | non identifiée |  | 4232 |  |  |  |
| 94 | 103 | Mystique | Comics | 2507 | 1 502 | sous 5 011 | compte autocomplétion |
| 95 | 104 | non identifiée |  | 2214 |  |  |  |
| 96 | 105 | non identifiée |  | 3989 |  |  |  |
| 97 | 106 | non identifiée |  | 3132 |  |  |  |
| 98 | 107 | non identifiée |  | 2149 |  |  |  |
| 99 | 108 | non identifiée |  | 2264 |  |  |  |
| 100 | 109 | non identifiée |  | 5467 |  |  |  |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 6 | 4194 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | 24 | 3382 |
| 10 | Judy Hopps | Furry | 26 160 | non trouvé |  |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | 20 | 3867 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 10 | 6067 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | non trouvé |  |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | 68 | 3290 |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | non trouvé |  |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | 27 | 3845 |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 2 | 6845 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | 31 | 6276 |
| 35 | Véra (Velma) | Cartoons | 14 935 | 40 | 3244 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 28 | 2698 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 119 | 3643 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | 46 | 8421 |
| 41 | Korra | Cartoons | 13 757 | non trouvé |  |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | non trouvé |  |
| 45 | Kim Possible | Cartoons | 12 439 | 9 | 5035 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 13 | 9270 |
| 47 | Katara | Cartoons | 12 083 | non trouvé |  |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 1 | 6980 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | 51 | 2394 |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | 17 (incertain) | 7068 |
| 56 | Catwoman | Comics | 10 167 | 26 | 3137 |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | 128 | 3273 |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | non trouvé |  |
| 60 | Toph | Cartoons | 9 643 | non trouvé |  |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | 67 | 5671 |
| 68 | Lola Bunny | Furry | 8 547 | non trouvé |  |
| 69 | Mavis | Cartoons | 8 447 | non trouvé |  |
| 70 | Marceline | Cartoons | 8 284 | non trouvé |  |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | non trouvé |  |
| 73 | Shego | Cartoons | 7 856 | 14 | 8348 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 15 | 7625 |
| 78 | Poison Ivy | Comics | 7 409 | 25 | 6345 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 12 (incertain) | 3125 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | non trouvé |  |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | non trouvé |  |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | non trouvé |  |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 65 | 2809 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | non trouvé |  |

## Vote 81614596 — modèle « Some of Disney/Pixar's hottest women » (150 images, 13/06/2025 ; paliers S à D + Hard Pass)

Retirés : aucun. Répartition des identifiés : Cartoons 89, Comics 0, Furry 9. Votants par image : 2385 à 5737.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Hélène Parr / Elastigirl | Cartoons | 3663 | 15 935 | 31 |  |
| 2 | 2 | Mégara | Cartoons | 3130 | 1 693 | sous 5 011 | compte autocomplétion |
| 3 | 3 | Tante Cass | Cartoons | 5095 | 4 966 | sous 5 011 | compte autocomplétion |
| 4 | 4 | Shego | Cartoons | 2727 | 7 856 | 73 |  |
| 5 | 5 | Raiponce | Cartoons | 2816 | 6 348 | 95 | tag générique |
| 6 | 6 | Kim Possible | Cartoons | 3220 | 12 439 | 45 |  |
| 7 | 7 | Elsa | Cartoons | 3928 | 14 890 | 37 |  |
| 8 | 8 | Jessica Rabbit | Cartoons | 3338 | 12 174 | 46 |  |
| 9 | 9 | Jasmine | Cartoons | 3391 | 7 518 | 77 |  |
| 10 | 10 | GoGo Tomago | Cartoons | 3570 | 2 278 | sous 5 011 | compte autocomplétion |
| 11 | 11 | Jane Porter | Cartoons | 3414 | 2 289 | sous 5 011 | compte autocomplétion |
| 12 | 12 | Wendy Corduroy | Cartoons | 2584 | 5 038 | 116 |  |
| 13 | 13 | Sergent Calhoun | Cartoons | 2691 | 285 | sous 5 011 | compte autocomplétion |
| 14 | 14 | Kida | Cartoons | 3169 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 15 | 15 | Honey Lemon | Cartoons | 3413 | 1 237 | sous 5 011 | compte autocomplétion |
| 16 | 16 | Belle | Cartoons | 4916 | 3 317 | sous 5 011 | compte autocomplétion |
| 17 | 17 | Vanessa Doofenshmirtz | Cartoons | 2585 | 765 | sous 5 011 | compte autocomplétion |
| 18 | 18 | Esmeralda | Cartoons | 3760 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 19 | 19 | Tiana | Cartoons | 2598 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 20 | 20 | Mirage (Les Indestructibles) | Cartoons | 2951 | 898 | sous 5 011 | compte autocomplétion |
| 21 | 21 | Ann Possible | Cartoons | 5326 | 2 843 | sous 5 011 | compte autocomplétion |
| 22 | 22 | Anna | Cartoons | 5444 | 6 383 | 93 |  |
| 23 | 23 | Aphrodite (Hercule) | Cartoons | 5109 | 120 | sous 5 011 | tag générique; compte autocomplétion |
| 24 | 24 | Les Bimbettes (La Belle et la Bête) | Cartoons | 4007 | 3 | sous 5 011 | tag générique; compte autocomplétion |
| 25 | 25 | Mulan | Cartoons | 3771 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 26 | 26 | Vaiana | Cartoons | 2942 | 1 610 | sous 5 011 | tag générique; compte autocomplétion |
| 27 | 27 | Aurore | Cartoons | 4924 | 2 261 | sous 5 011 | compte autocomplétion |
| 28 | 28 | Colette (Ratatouille) | Cartoons | 4144 | 487 | sous 5 011 | compte autocomplétion |
| 29 | 29 | Ariel | Cartoons | 5276 | 4 354 | sous 5 011 | compte autocomplétion |
| 30 | 30 | Audrey Ramirez | Cartoons | 4925 | 397 | sous 5 011 | compte autocomplétion |
| 31 | 31 | Fifi / Babette, le plumeau (La Belle et la Bête) | Cartoons | 3509 | 136 | sous 5 011 | tag générique; compte autocomplétion |
| 32 | 32 | Candace Flynn | Cartoons | 4386 | 1 233 | sous 5 011 | compte autocomplétion |
| 33 | 33 | Nani | Cartoons | 2841 | 2 915 | sous 5 011 | compte autocomplétion |
| 34 | 34 | Shank (Ralph 2.0) | Cartoons | 2553 | 45 | sous 5 011 | compte autocomplétion |
| 35 | 35 | Charlotte La Bouff | Cartoons | 4244 | 224 | sous 5 011 | compte autocomplétion |
| 36 | 36 | Les Muses (Hercule) | Cartoons | 2771 | 86 | sous 5 011 | tag générique; compte autocomplétion |
| 37 | 37 | Judy Hopps | Furry | 3308 | 26 160 | 10 |  |
| 38 | 38 | Raya | Cartoons | 2612 | 214 | sous 5 011 | compte autocomplétion |
| 39 | 39 | Reine Iduna | Cartoons | 2671 | 85 | sous 5 011 | compte autocomplétion |
| 40 | 40 | Merida | Cartoons | 3020 | 1 216 | sous 5 011 | compte autocomplétion |
| 41 | 41 | Pocahontas | Cartoons | 2742 | 2 047 | sous 5 011 | compte autocomplétion |
| 42 | 42 | Helga Sinclair | Cartoons | 3312 | 421 | sous 5 011 | compte autocomplétion |
| 43 | 43 | Bonnie Rockwaller | Cartoons | 4342 | 2 126 | sous 5 011 | compte autocomplétion |
| 44 | 44 | Chicha | Cartoons | 4067 | 236 | sous 5 011 | compte autocomplétion |
| 45 | 45 | Vidia | Cartoons | 2488 | 52 | sous 5 011 | compte autocomplétion |
| 46 | 46 | Anita Radcliffe | Cartoons | 5330 | 224 | sous 5 011 | compte autocomplétion |
| 47 | 47 | Elisa Maza | Cartoons | 3591 | 645 | sous 5 011 | compte autocomplétion |
| 48 | 48 | Ondine (Silvermist) | Cartoons | 2569 | 84 | sous 5 011 | compte autocomplétion |
| 49 | 49 | Reine Arianna | Cartoons | 2647 | 94 | sous 5 011 | compte autocomplétion |
| 50 | 50 | Cendrillon | Cartoons | 4160 | 1 570 | sous 5 011 | compte autocomplétion |
| 51 | 51 | Te Fiti | Cartoons | 2535 | 5 | sous 5 011 | compte autocomplétion |
| 52 | 52 | Dégoût | Cartoons | 3937 | 1 569 | sous 5 011 | compte autocomplétion |
| 53 | 53 | Linda Flynn-Fletcher | Cartoons | 3071 | 603 | sous 5 011 | compte autocomplétion |
| 54 | 54 | La fille au béret (Dingo et Max 2) | Furry | 2740 | 154 | sous 5 011 | identification incertaine; compte autocomplétion |
| 55 | 55 | Reine Elinor | Cartoons | 2671 | 146 | sous 5 011 | compte autocomplétion |
| 56 | 56 | Bo la bergère | Cartoons | 4540 | 244 | sous 5 011 | compte autocomplétion |
| 57 | 57 | Kate (Inner Workings) | Cartoons | 3066 | 555 | sous 5 011 | compte autocomplétion |
| 58 | 58 | Roxanne | Furry | 2601 | 1 705 | sous 5 011 | compte autocomplétion |
| 59 | 59 | Jessie (Toy Story) | Cartoons | 3262 | 600 | sous 5 011 | compte autocomplétion |
| 60 | 60 | Giffany | Cartoons | 3379 | 202 | sous 5 011 | compte autocomplétion |
| 61 | 61 | Jackie Lynn Thomas | Cartoons | 3236 | 2 987 | sous 5 011 | compte autocomplétion |
| 62 | 62 | Fée Clochette | Cartoons | 2548 | 3 867 | sous 5 011 | compte autocomplétion |
| 63 | 63 | Evelyn Deavor | Cartoons | 3638 | 60 | sous 5 011 | compte autocomplétion |
| 64 | 64 | Hekapoo | Cartoons | 3304 | 3 067 | sous 5 011 | compte autocomplétion |
| 65 | 65 | Mère Gothel | Cartoons | 2867 | 786 | sous 5 011 | compte autocomplétion |
| 66 | 66 | Mme Andersen (Vice-Versa) | Cartoons | 2822 | 281 | sous 5 011 | compte autocomplétion |
| 67 | 67 | Sarah Hawkins | Cartoons | 2517 | 130 | sous 5 011 | compte autocomplétion |
| 68 | 68 | Clochette Periwinkle | Cartoons | 2650 | 23 | sous 5 011 | compte autocomplétion |
| 69 | 69 | Ellie Fredricksen | Cartoons | 3680 | 6 | sous 5 011 | compte autocomplétion |
| 70 | 70 | Star Butterfly | Cartoons | 2554 | 5 697 | 102 |  |
| 71 | 71 | Princesse Eilonwy | Cartoons | 2561 | 224 | sous 5 011 | compte autocomplétion |
| 72 | 72 | Honeymaren | Cartoons | 3186 | 23 | sous 5 011 | compte autocomplétion |
| 73 | 73 | Imelda (Coco) | Cartoons | 3216 | 7 | sous 5 011 | compte autocomplétion |
| 74 | 74 | Maléfique | Cartoons | 3005 | 1 598 | sous 5 011 | compte autocomplétion |
| 75 | 75 | Noa (Fawn) | Cartoons | 3552 | 55 | sous 5 011 | compte autocomplétion |
| 76 | 76 | Alice | Cartoons | 5737 | 3 616 | sous 5 011 | compte autocomplétion |
| 77 | 77 | Capitaine Amelia | Furry | 4178 | 1 418 | sous 5 011 | compte autocomplétion |
| 78 | 78 | Mary Darling | Cartoons | 2824 | 84 | sous 5 011 | compte autocomplétion |
| 79 | 79 | Luisa Madrigal | Cartoons | 2899 | 192 | sous 5 011 | compte autocomplétion |
| 80 | 80 | Katrina Van Tassel | Cartoons | 2964 | 54 | sous 5 011 | compte autocomplétion |
| 81 | 81 | Blanche-Neige | Cartoons | 2596 | 2 457 | sous 5 011 | compte autocomplétion |
| 82 | 82 | Slue Foot Sue | Cartoons | 2421 | 110 | sous 5 011 | compte autocomplétion |
| 83 | 83 | Reine Leah | Cartoons | 2549 | 22 | sous 5 011 | compte autocomplétion |
| 84 | 84 | Franny Robinson | Cartoons | 3449 | 50 | sous 5 011 | compte autocomplétion |
| 85 | 85 | Angel (Lilo & Stitch) | Furry | 5523 | 668 | sous 5 011 | compte autocomplétion |
| 86 | 86 | Abigail Callaghan (Les Nouveaux Héros) | Cartoons | 5561 |  |  | pas de tag rule34 dédié (exclue des calculs) |
| 87 | 87 | Monique | Cartoons | 2692 | 495 | sous 5 011 | compte autocomplétion |
| 88 | 88 | Della Duck | Furry | 3755 | 138 | sous 5 011 | compte autocomplétion |
| 89 | 89 | La Reine (Blanche-Neige) | Cartoons | 3697 | 63 | sous 5 011 | compte autocomplétion |
| 90 | 90 | Demona | Cartoons | 3658 | 974 | sous 5 011 | compte autocomplétion |
| 91 | 91 | Celia Mae | Cartoons | 4264 | 33 | sous 5 011 | compte autocomplétion |
| 92 | 92 | Daisy Duck | Furry | 3876 | 545 | sous 5 011 | compte autocomplétion |
| 93 | 93 | Mira Nova | Cartoons | 2726 | 300 | sous 5 011 | compte autocomplétion |
| 94 | 94 | Gazelle (Zootopie) | Furry | 3459 | 1 075 | sous 5 011 | compte autocomplétion |
| 95 | 95 | Vivian Porter | Cartoons | 2385 | 122 | sous 5 011 | compte autocomplétion |
| 96 | 96 | Sina (Vaiana) | Cartoons | 2535 |  |  | pas de tag rule34 dédié (exclue des calculs) |
| 97 | 97 | Sylvia | Furry | 2446 | 347 | sous 5 011 | compte autocomplétion |
| 98 | 98 | Lord Dominator | Cartoons | 2896 | 2 256 | sous 5 011 | compte autocomplétion |
| 99 | 99 | La Fée bleue | Cartoons | 4471 | 77 | sous 5 011 | compte autocomplétion |
| 100 | 100 | Joie (Vice-Versa) | Cartoons | 3230 | 832 | sous 5 011 | compte autocomplétion |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | non trouvé |  |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | non trouvé |  |
| 10 | Judy Hopps | Furry | 26 160 | 37 | 3308 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | non trouvé |  |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | non trouvé |  |
| 17 | Gwen Tennyson | Cartoons | 21 472 | non trouvé |  |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | non trouvé |  |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | non trouvé |  |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 1 | 3663 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | non trouvé |  |
| 35 | Véra (Velma) | Cartoons | 14 935 | non trouvé |  |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 7 | 3928 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | non trouvé |  |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | non trouvé |  |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | non trouvé |  |
| 45 | Kim Possible | Cartoons | 12 439 | 6 | 3220 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 8 | 3338 |
| 47 | Katara | Cartoons | 12 083 | non trouvé |  |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | non trouvé |  |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | non trouvé |  |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | non trouvé |  |
| 60 | Toph | Cartoons | 9 643 | non trouvé |  |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | non trouvé |  |
| 68 | Lola Bunny | Furry | 8 547 | non trouvé |  |
| 69 | Mavis | Cartoons | 8 447 | non trouvé |  |
| 70 | Marceline | Cartoons | 8 284 | non trouvé |  |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | non trouvé |  |
| 73 | Shego | Cartoons | 7 856 | 4 | 2727 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 9 | 3391 |
| 78 | Poison Ivy | Comics | 7 409 | non trouvé |  |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | non trouvé |  |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 22 | 5444 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | 5 | 2816 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | 70 | 2554 |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | non trouvé |  |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | non trouvé |  |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 12 | 2584 |

## Vote 30083716 — modèle « Female Cartoon Characters » (1 087 images, 09/05/2026)

Retirés : Tsunade (14), Nami (28), Hinata Hyûga (34), Tsunade (45), Jessie (Team Rocket) (51), Nico Robin (55), Nami (65), Tsunade (69), Jessie (Team Rocket) (85), Temari (87), Jinx (League of Legends) (92), Ino Yamanaka (98), Tsunade (101), Infirmière Joëlle (103), Magicienne des ténèbres (109), Serena (Pokémon) (111). Répartition des identifiés : Cartoons 59, Comics 30, Furry 5. Votants par image : 30 à 2611.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Chel | Cartoons | 584 | 11 392 | 49 |  |
| 2 | 2 | Hélène Parr / Elastigirl | Cartoons | 594 | 15 935 | 31 |  |
| 3 | 3 | Tante Cass | Cartoons | 292 | 4 966 | sous 5 011 | compte autocomplétion |
| 4 | 4 | Wonder Woman | Comics | 325 | 22 974 | 14 |  |
| 5 | 5 | Shego | Cartoons | 625 | 7 856 | 73 |  |
| 6 | 6 | Lola Bunny | Furry | 318 | 8 547 | 68 |  |
| 7 | 7 | Jane Porter | Cartoons | 532 | 2 289 | sous 5 011 | compte autocomplétion |
| 8 | 8 | Kim Possible | Cartoons | 980 | 12 439 | 45 |  |
| 9 | 9 | Tante Cass | Cartoons | 1688 | 4 966 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 3) |
| 10 | 10 | Raven | Cartoons | 364 | 39 707 | 5 |  |
| 11 | 11 | Blackfire | Comics | 285 | 4 245 | sous 5 011 | compte autocomplétion |
| 12 | 12 | Starfire | Cartoons | 352 | 21 791 | 16 |  |
| 13 | 13 | Gwen Stacy (Spider-Verse) | Comics | 329 | 19 716 | 21 |  |
| 14 | 15 | Jessica Rabbit | Cartoons | 556 | 12 174 | 46 |  |
| 15 | 16 | Mégara | Cartoons | 926 | 1 693 | sous 5 011 | compte autocomplétion |
| 16 | 17 | Black Widow | Comics | 244 | 10 379 | 55 |  |
| 17 | 18 | Mavis | Cartoons | 510 | 8 447 | 69 |  |
| 18 | 19 | Zatanna | Comics | 289 | 3 952 | sous 5 011 | compte autocomplétion |
| 19 | 20 | Jasmine | Cartoons | 1043 | 7 518 | 77 |  |
| 20 | 21 | Kida | Cartoons | 964 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 21 | 22 | GoGo Tomago | Cartoons | 388 | 2 278 | sous 5 011 | compte autocomplétion |
| 22 | 23 | Asami Sato | Cartoons | 340 | 3 611 | sous 5 011 | identification incertaine; compte autocomplétion |
| 23 | 24 | Batgirl (Barbara Gordon) | Comics | 277 | 7 875 | 72 |  |
| 24 | 25 | Daphné | Cartoons | 336 | 6 963 | 86 |  |
| 25 | 26 | Harley Quinn | Cartoons | 291 | 26 362 | 9 |  |
| 26 | 27 | Gwen (Total Drama) | Cartoons | 230 | 4 327 | sous 5 011 | compte autocomplétion |
| 27 | 29 | Poison Ivy | Comics | 212 | 7 409 | 78 |  |
| 28 | 30 | Black Cat | Comics | 602 | 15 119 | 34 |  |
| 29 | 31 | Batgirl (Barbara Gordon) | Comics | 216 | 7 875 | 72 | 2e image (meilleure : 24) |
| 30 | 32 | Korra | Cartoons | 399 | 13 757 | 41 |  |
| 31 | 33 | Mégara | Cartoons | 296 | 1 693 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 16) |
| 32 | 35 | Elsa | Cartoons | 2155 | 14 890 | 37 |  |
| 33 | 36 | Mulan | Cartoons | 500 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 34 | 37 | Asami Sato | Cartoons | 239 | 3 611 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 23) |
| 35 | 38 | Black Canary | Comics | 233 | 2 613 | sous 5 011 | compte autocomplétion |
| 36 | 39 | Esmeralda | Cartoons | 292 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 37 | 40 | Azula | Cartoons | 438 | 12 587 | 44 |  |
| 38 | 41 | Raiponce | Cartoons | 364 | 6 348 | 95 | tag générique |
| 39 | 42 | Black Widow | Comics | 48 | 10 379 | 55 | 2e image (meilleure : 17) |
| 40 | 43 | Ty Lee | Cartoons | 341 | 5 660 | 104 |  |
| 41 | 44 | Les Hex Girls (Scooby-Doo) | Cartoons | 1218 | 317 | sous 5 011 | tag générique; compte autocomplétion |
| 42 | 46 | Fifi / Babette, le plumeau (La Belle et la Bête) | Cartoons | 2265 | 136 | sous 5 011 | tag générique; compte autocomplétion |
| 43 | 47 | Sara Bellum | Cartoons | 388 | 1 624 | sous 5 011 | compte autocomplétion |
| 44 | 48 | non identifiée |  | 624 |  |  |  |
| 45 | 49 | Lola Bunny | Furry | 296 | 8 547 | 68 | 2e image (meilleure : 6) |
| 46 | 50 | Malicia (Rogue) | Comics | 317 | 8 641 | 67 |  |
| 47 | 52 | Fire (Justice League) | Comics | 219 | 249 | sous 5 011 | compte autocomplétion |
| 48 | 53 | Sergent Calhoun | Cartoons | 589 | 285 | sous 5 011 | compte autocomplétion |
| 49 | 54 | Atom Eve | Comics | 191 | 3 662 | sous 5 011 | compte autocomplétion |
| 50 | 56 | Katara | Cartoons | 530 | 12 083 | 47 |  |
| 51 | 57 | Bonnie Rockwaller | Cartoons | 361 | 2 126 | sous 5 011 | identification incertaine; compte autocomplétion |
| 52 | 58 | Asami Sato | Cartoons | 80 | 3 611 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 23) |
| 53 | 59 | Zatanna | Comics | 231 | 3 952 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 19) |
| 54 | 60 | Power Girl | Comics | 210 | 13 942 | 40 |  |
| 55 | 61 | June (Avatar) | Cartoons | 39 | 292 | sous 5 011 | compte autocomplétion |
| 56 | 62 | Batgirl (Barbara Gordon) | Comics | 76 | 7 875 | 72 | 2e image (meilleure : 24) |
| 57 | 63 | non identifiée |  | 519 |  |  |  |
| 58 | 64 | Black Canary | Comics | 44 | 2 613 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 38) |
| 59 | 66 | Esmeralda | Cartoons | 1188 | 893 | sous 5 011 | tag générique; compte autocomplétion; 2e image (meilleure : 39) |
| 60 | 67 | Blackfire | Comics | 103 | 4 245 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 11) |
| 61 | 68 | Batgirl (Barbara Gordon) | Comics | 41 | 7 875 | 72 | 2e image (meilleure : 24) |
| 62 | 70 | Supergirl | Comics | 151 | 16 375 | 30 |  |
| 63 | 71 | non identifiée |  | 172 |  |  |  |
| 64 | 72 | Les Bimbettes (La Belle et la Bête) | Cartoons | 1292 | 3 | sous 5 011 | tag générique; compte autocomplétion |
| 65 | 73 | Harley Quinn | Cartoons | 74 | 26 362 | 9 | 2e image (meilleure : 26) |
| 66 | 74 | Véra (Velma) | Cartoons | 324 | 14 935 | 35 |  |
| 67 | 75 | Tornade (Storm) | Comics | 276 | 4 390 | sous 5 011 | compte autocomplétion |
| 68 | 76 | Suki | Cartoons | 46 | 1 534 | sous 5 011 | tag générique; compte autocomplétion |
| 69 | 77 | Catwoman | Comics | 224 | 10 167 | 56 |  |
| 70 | 78 | non identifiée |  | 212 |  |  |  |
| 71 | 79 | Astrid | Cartoons | 250 | 5 127 | 114 |  |
| 72 | 80 | Jinx (Teen Titans) | Comics | 262 | 3 260 | sous 5 011 | compte autocomplétion |
| 73 | 81 | Helga Sinclair | Cartoons | 1020 | 421 | sous 5 011 | compte autocomplétion |
| 74 | 82 | Pocahontas | Cartoons | 2611 | 2 047 | sous 5 011 | compte autocomplétion |
| 75 | 83 | Mirage (Les Indestructibles) | Cartoons | 879 | 898 | sous 5 011 | compte autocomplétion |
| 76 | 84 | Belle | Cartoons | 1553 | 3 317 | sous 5 011 | compte autocomplétion |
| 77 | 86 | Asami Sato | Cartoons | 36 | 3 611 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 23) |
| 78 | 88 | Gardevoir | Furry | 47 | 41 237 | 4 |  |
| 79 | 89 | Barbie | Cartoons | 40 | 822 | sous 5 011 | tag générique; compte autocomplétion |
| 80 | 90 | Femme invisible | Comics | 36 | 10 816 | 52 |  |
| 81 | 91 | Tiana | Cartoons | 1931 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 82 | 93 | Catwoman | Comics | 181 | 10 167 | 56 | 2e image (meilleure : 77) |
| 83 | 94 | Anna | Cartoons | 1772 | 6 383 | 93 |  |
| 84 | 95 | Supergirl | Comics | 30 | 16 375 | 30 | 2e image (meilleure : 70) |
| 85 | 96 | Wendy Corduroy | Cartoons | 335 | 5 038 | 116 |  |
| 86 | 97 | Trixie Tang | Cartoons | 469 | 1 354 | sous 5 011 | compte autocomplétion |
| 87 | 99 | Sam (Totally Spies) | Cartoons | 775 | 3 099 | sous 5 011 | compte autocomplétion |
| 88 | 100 | Vanessa Doofenshmirtz | Cartoons | 2146 | 765 | sous 5 011 | compte autocomplétion |
| 89 | 102 | Fire (Justice League) | Comics | 35 | 249 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 52) |
| 90 | 104 | Zatanna | Comics | 74 | 3 952 | sous 5 011 | compte autocomplétion; 2e image (meilleure : 19) |
| 91 | 105 | Ann Possible | Cartoons | 1733 | 2 843 | sous 5 011 | compte autocomplétion |
| 92 | 106 | Ten / Melanie Walker | Cartoons | 199 | 84 | sous 5 011 | compte autocomplétion |
| 93 | 107 | Judy Hopps | Furry | 2115 | 26 160 | 10 |  |
| 94 | 108 | Honey Lemon | Cartoons | 354 | 1 237 | sous 5 011 | compte autocomplétion |
| 95 | 110 | Rouge the Bat | Furry | 602 | 45 414 | 1 |  |
| 96 | 112 | non identifiée |  | 166 |  |  |  |
| 97 | 113 | Ariel | Cartoons | 1703 | 4 354 | sous 5 011 | compte autocomplétion |
| 98 | 114 | non identifiée |  | 1330 |  |  |  |
| 99 | 115 | Toph | Cartoons | 368 | 9 643 | 60 |  |
| 100 | 116 | Malicia (Rogue) | Comics | 207 | 8 641 | 67 | 2e image (meilleure : 50) |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | 110 | 602 |
| 2 | Loona | Furry | 43 049 | 236 | 210 |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | 88 | 47 |
| 5 | Raven | Cartoons | 39 707 | 10 | 364 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | 26 | 291 |
| 10 | Judy Hopps | Furry | 26 160 | 107 | 2115 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | 4 | 325 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 12 | 352 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | 131 | 212 |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 13 | 329 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | 70 | 151 |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 2 | 594 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | 30 | 602 |
| 35 | Véra (Velma) | Cartoons | 14 935 | 74 | 324 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 35 | 2155 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 168 | 210 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | 60 | 210 |
| 41 | Korra | Cartoons | 13 757 | 32 | 399 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | 40 | 438 |
| 45 | Kim Possible | Cartoons | 12 439 | 8 | 980 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 15 | 556 |
| 47 | Katara | Cartoons | 12 083 | 56 | 530 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 1 | 584 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | 90 | 36 |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | 17 | 244 |
| 56 | Catwoman | Comics | 10 167 | 77 | 224 |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 253 | 451 |
| 60 | Toph | Cartoons | 9 643 | 115 | 368 |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | 50 | 317 |
| 68 | Lola Bunny | Furry | 8 547 | 6 | 318 |
| 69 | Mavis | Cartoons | 8 447 | 18 | 510 |
| 70 | Marceline | Cartoons | 8 284 | 155 | 2027 |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 24 | 277 |
| 73 | Shego | Cartoons | 7 856 | 5 | 625 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 20 | 1043 |
| 78 | Poison Ivy | Comics | 7 409 | 29 | 212 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 25 | 336 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 94 | 1772 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | 41 | 364 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 43 | 341 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 140 | 243 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | 79 | 250 |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 96 | 335 |

## Vote 20899730 — modèle « Penultimate Female Cartoon Character Tierlist » (324 images, 24/02/2026 ; paliers S à D + Ewwwwww + Who?)

Retirés : Peach (film Super Mario Bros.) (25). Répartition des identifiés : Cartoons 91, Comics 5, Furry 3. Votants par image : 709 à 3206.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Hélène Parr / Elastigirl | Cartoons | 1887 | 15 935 | 31 |  |
| 2 | 2 | Chel | Cartoons | 2119 | 11 392 | 49 |  |
| 3 | 3 | Tante Cass | Cartoons | 2181 | 4 966 | sous 5 011 | compte autocomplétion |
| 4 | 4 | Blackfire | Comics | 2293 | 4 245 | sous 5 011 | compte autocomplétion |
| 5 | 5 | Shego | Cartoons | 1044 | 7 856 | 73 |  |
| 6 | 6 | Mavis | Cartoons | 1258 | 8 447 | 69 |  |
| 7 | 7 | Mégara | Cartoons | 1225 | 1 693 | sous 5 011 | compte autocomplétion |
| 8 | 8 | Starfire | Cartoons | 1022 | 21 791 | 16 |  |
| 9 | 9 | Jessica Rabbit | Cartoons | 1446 | 12 174 | 46 |  |
| 10 | 10 | Jasmine | Cartoons | 1516 | 7 518 | 77 |  |
| 11 | 11 | Gwen Stacy (Spider-Verse) | Comics | 1602 | 19 716 | 21 |  |
| 12 | 12 | Raven | Cartoons | 1090 | 39 707 | 5 |  |
| 13 | 13 | GoGo Tomago | Cartoons | 1599 | 2 278 | sous 5 011 | compte autocomplétion |
| 14 | 14 | Daphné | Cartoons | 2003 | 6 963 | 86 |  |
| 15 | 15 | Jane Porter | Cartoons | 1456 | 2 289 | sous 5 011 | compte autocomplétion |
| 16 | 16 | Asami Sato | Cartoons | 2401 | 3 611 | sous 5 011 | compte autocomplétion |
| 17 | 17 | Belle | Cartoons | 2411 | 3 317 | sous 5 011 | compte autocomplétion |
| 18 | 18 | Sam (Totally Spies) | Cartoons | 944 | 3 099 | sous 5 011 | compte autocomplétion |
| 19 | 19 | Kim Possible | Cartoons | 1353 | 12 439 | 45 |  |
| 20 | 20 | Lola Bunny | Furry | 1306 | 8 547 | 68 |  |
| 21 | 21 | Gwen (Total Drama) | Cartoons | 1458 | 4 327 | sous 5 011 | compte autocomplétion |
| 22 | 22 | Kida | Cartoons | 1228 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 23 | 23 | Esmeralda | Cartoons | 1539 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 24 | 24 | La sauveteuse (Lilo & Stitch) | Cartoons | 897 | 973 | sous 5 011 | compte autocomplétion |
| 25 | 26 | Les Bimbettes (La Belle et la Bête) | Cartoons | 2062 | 3 | sous 5 011 | tag générique; compte autocomplétion |
| 26 | 27 | Fifi / Babette, le plumeau (La Belle et la Bête) | Cartoons | 1506 | 136 | sous 5 011 | tag générique; compte autocomplétion |
| 27 | 28 | Aurore | Cartoons | 2388 | 2 261 | sous 5 011 | compte autocomplétion |
| 28 | 29 | Ariel | Cartoons | 2854 | 4 354 | sous 5 011 | compte autocomplétion |
| 29 | 30 | Raiponce | Cartoons | 1064 | 6 348 | 95 | tag générique |
| 30 | 31 | Atom Eve | Comics | 2354 | 3 662 | sous 5 011 | compte autocomplétion |
| 31 | 32 | Elsa | Cartoons | 1792 | 14 890 | 37 |  |
| 32 | 33 | Mulan | Cartoons | 1105 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 33 | 34 | Tiana | Cartoons | 972 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 34 | 35 | Sergent Calhoun | Cartoons | 973 | 285 | sous 5 011 | compte autocomplétion |
| 35 | 36 | April O'Neil | Comics | 2508 | 5 475 | 107 |  |
| 36 | 37 | Mirage (Les Indestructibles) | Cartoons | 1151 | 898 | sous 5 011 | compte autocomplétion |
| 37 | 38 | Éris (Sinbad) | Cartoons | 1403 | 113 | sous 5 011 | compte autocomplétion |
| 38 | 39 | Azula | Cartoons | 2154 | 12 587 | 44 |  |
| 39 | 40 | Anastasia | Cartoons | 2757 | 188 | sous 5 011 | compte autocomplétion |
| 40 | 41 | Vanessa Doofenshmirtz | Cartoons | 921 | 765 | sous 5 011 | compte autocomplétion |
| 41 | 42 | Ann Possible | Cartoons | 2792 | 2 843 | sous 5 011 | compte autocomplétion |
| 42 | 43 | Ty Lee | Cartoons | 866 | 5 660 | 104 |  |
| 43 | 44 | Les Hex Girls (Scooby-Doo) | Cartoons | 1261 | 317 | sous 5 011 | tag générique; compte autocomplétion |
| 44 | 45 | Mary Jane Watson | Comics | 1025 | 7 592 | 76 |  |
| 45 | 46 | Susan / Génormica | Cartoons | 943 | 277 | sous 5 011 | compte autocomplétion |
| 46 | 47 | Gwen Tennyson | Cartoons | 1388 | 21 472 | 17 |  |
| 47 | 48 | Korra | Cartoons | 1226 | 13 757 | 41 |  |
| 48 | 49 | Nani | Cartoons | 1119 | 2 915 | sous 5 011 | compte autocomplétion |
| 49 | 50 | Raven | Cartoons | 1013 | 39 707 | 5 | 2e image (meilleure : 12) |
| 50 | 51 | Véra (Velma) | Cartoons | 955 | 14 935 | 35 |  |
| 51 | 52 | Anna | Cartoons | 2942 | 6 383 | 93 |  |
| 52 | 53 | Wendy Corduroy | Cartoons | 911 | 5 038 | 116 |  |
| 53 | 54 | Lucy Mann | Cartoons | 1017 | 215 | sous 5 011 | compte autocomplétion |
| 54 | 55 | Clover | Cartoons | 819 | 2 826 | sous 5 011 | compte autocomplétion |
| 55 | 56 | Lindsay | Cartoons | 1141 | 2 535 | sous 5 011 | compte autocomplétion |
| 56 | 57 | Honey Lemon | Cartoons | 1434 | 1 237 | sous 5 011 | compte autocomplétion |
| 57 | 58 | Suki | Cartoons | 844 | 1 534 | sous 5 011 | tag générique; compte autocomplétion |
| 58 | 59 | Charlotte La Bouff | Cartoons | 1894 | 224 | sous 5 011 | compte autocomplétion |
| 59 | 60 | Alex | Cartoons | 3206 | 2 645 | sous 5 011 | compte autocomplétion |
| 60 | 61 | Patty Peterson | Cartoons | 911 | 13 | sous 5 011 | compte autocomplétion |
| 61 | 62 | María Posada | Cartoons | 1027 | 38 | sous 5 011 | compte autocomplétion |
| 62 | 63 | Sara Bellum | Cartoons | 893 | 1 624 | sous 5 011 | compte autocomplétion |
| 63 | 64 | Les Muses (Hercule) | Cartoons | 962 | 86 | sous 5 011 | tag générique; compte autocomplétion |
| 64 | 65 | Keyleth | Cartoons | 979 | 853 | sous 5 011 | compte autocomplétion |
| 65 | 66 | Pocahontas | Cartoons | 1000 | 2 047 | sous 5 011 | compte autocomplétion |
| 66 | 67 | Vaiana | Cartoons | 1120 | 1 610 | sous 5 011 | tag générique; compte autocomplétion |
| 67 | 68 | La fille au béret (Dingo et Max 2) | Furry | 846 | 154 | sous 5 011 | compte autocomplétion |
| 68 | 69 | Bridgette | Cartoons | 1868 | 979 | sous 5 011 | compte autocomplétion |
| 69 | 70 | Mai (Avatar) | Cartoons | 1055 | 2 370 | sous 5 011 | compte autocomplétion |
| 70 | 71 | Astrid | Cartoons | 2510 | 5 127 | 114 |  |
| 71 | 72 | Sam Sparks | Cartoons | 967 | 14 | sous 5 011 | compte autocomplétion |
| 72 | 73 | Kai Green | Cartoons | 1051 | 117 | sous 5 011 | compte autocomplétion |
| 73 | 74 | Merida | Cartoons | 1169 | 1 216 | sous 5 011 | compte autocomplétion |
| 74 | 75 | Myriam (Le Prince d'Égypte) | Cartoons | 900 | 14 | sous 5 011 | compte autocomplétion |
| 75 | 76 | Marceline | Cartoons | 1128 | 8 284 | 70 |  |
| 76 | 77 | Courtney | Cartoons | 1729 | 2 127 | sous 5 011 | compte autocomplétion |
| 77 | 78 | Audrey Ramirez | Cartoons | 2138 | 397 | sous 5 011 | compte autocomplétion |
| 78 | 79 | Marinette / Ladybug | Cartoons | 1917 | 6 437 | 91 |  |
| 79 | 80 | Sarah Hawkins | Cartoons | 786 | 130 | sous 5 011 | compte autocomplétion |
| 80 | 81 | Colette (Ratatouille) | Cartoons | 1972 | 487 | sous 5 011 | compte autocomplétion |
| 81 | 82 | Starfire | Cartoons | 946 | 21 791 | 16 | 2e image (meilleure : 8) |
| 82 | 83 | Fée Clochette | Cartoons | 933 | 3 867 | sous 5 011 | compte autocomplétion |
| 83 | 84 | Les sirènes (Peter Pan) | Cartoons | 899 |  |  | pas de tag rule34 dédié (exclue des calculs) |
| 84 | 85 | Cendrillon | Cartoons | 1981 | 1 570 | sous 5 011 | compte autocomplétion |
| 85 | 86 | Judy Hopps | Furry | 1391 | 26 160 | 10 |  |
| 86 | 87 | Julie Yamamoto | Cartoons | 1091 | 1 003 | sous 5 011 | compte autocomplétion |
| 87 | 88 | La Muerte | Cartoons | 1081 | 122 | sous 5 011 | compte autocomplétion |
| 88 | 89 | Rebecca Holiday | Cartoons | 728 | 72 | sous 5 011 | compte autocomplétion |
| 89 | 90 | Helga Sinclair | Cartoons | 1199 | 421 | sous 5 011 | compte autocomplétion |
| 90 | 91 | Elisa Maza | Cartoons | 1249 | 645 | sous 5 011 | compte autocomplétion |
| 91 | 92 | Sirena Ong | Cartoons | 709 | 3 | sous 5 011 | compte autocomplétion |
| 92 | 93 | Katara | Cartoons | 1235 | 12 083 | 47 |  |
| 93 | 94 | Heather | Cartoons | 1354 | 2 404 | sous 5 011 | compte autocomplétion |
| 94 | 95 | Princesse des flammes | Cartoons | 1441 | 1 784 | sous 5 011 | compte autocomplétion |
| 95 | 96 | La mère de Dexter | Cartoons | 1598 | 20 | sous 5 011 | compte autocomplétion |
| 96 | 97 | Izzy | Cartoons | 1247 | 687 | sous 5 011 | compte autocomplétion |
| 97 | 98 | Ember McLain | Cartoons | 1383 | 758 | sous 5 011 | compte autocomplétion |
| 98 | 99 | Emily (Les Noces funèbres) | Cartoons | 1554 | 172 | sous 5 011 | compte autocomplétion |
| 99 | 100 | Chicha | Cartoons | 1657 | 236 | sous 5 011 | compte autocomplétion |
| 100 | 101 | Anita Radcliffe | Cartoons | 2585 | 224 | sous 5 011 | compte autocomplétion |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 12 | 1090 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | non trouvé |  |
| 10 | Judy Hopps | Furry | 26 160 | 86 | 1391 |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | non trouvé |  |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 8 | 1022 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | 47 | 1388 |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 11 | 1602 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | non trouvé |  |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 1 | 1887 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | non trouvé |  |
| 35 | Véra (Velma) | Cartoons | 14 935 | 51 | 955 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 32 | 1792 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 102 | 2277 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 48 | 1226 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | 39 | 2154 |
| 45 | Kim Possible | Cartoons | 12 439 | 19 | 1353 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 9 | 1446 |
| 47 | Katara | Cartoons | 12 083 | 93 | 1235 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 2 | 2119 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | non trouvé |  |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 158 | 968 |
| 60 | Toph | Cartoons | 9 643 | 201 | 800 |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | 132 | 1037 |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | non trouvé |  |
| 68 | Lola Bunny | Furry | 8 547 | 20 | 1306 |
| 69 | Mavis | Cartoons | 8 447 | 6 | 1258 |
| 70 | Marceline | Cartoons | 8 284 | 76 | 1128 |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | non trouvé |  |
| 73 | Shego | Cartoons | 7 856 | 5 | 1044 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | 45 | 1025 |
| 77 | Jasmine | Cartoons | 7 518 | 10 | 1516 |
| 78 | Poison Ivy | Comics | 7 409 | non trouvé |  |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 14 | 2003 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | 79 | 1917 |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | 52 | 2942 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | 30 | 1064 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 43 | 866 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 36 | 2508 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | 71 | 2510 |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 53 | 911 |

## Vote 80408816 — modèle « Waifus Anime, Cartoon and Videogames » (381 images, 17/08/2025 ; modèle tous médiums : animanga et jeux vidéo retirés, images du périmètre identifiées jusqu'au rang 274)

Retirés : Hinata Hyûga (2), Chun-Li (4), Marin Kitagawa (5), 2B (6), D.Va (7), Mirko (Rumi Usagiyama) (8), Cynthia (Pokémon) (9), Tsunade (10), Samus Aran (11), Yor Forger (12), Nami (14), Yoruichi (15), Fubuki (16), Tatsumaki (17), Princesse Zelda (18), Makima (19), Mitsuri Kanroji (20), Harmonie (Rosalina) (21), Jinx (League of Legends) (23), Cammy White (24), Momo Yaoyorozu (26), Mercy (27), Power (29), C-18 (30), Shinobu Kochô (31), Princesse Peach (32), Himiko Toga (33), Lara Croft (34), Nico Robin (36), Ino Yamanaka (38), Zero Two (40), Sonia (Pokémon) (42), Tifa Lockhart (43), Hilda (Pokémon) (44), Kobeni (46), Mikasa Ackerman (48), Widowmaker (50), Ochako Uraraka (52), Ada Wong (54), Ryûko Matoi (56), Bayonetta (57), Hayase Nagatoro (58), Darkness (59), Bulma (60), Tracer (61), Shôko Komi (63), Misato Katsuragi (64), Rosa (Pokémon) (65), Nessa (Pokémon) (66), Aqua (67), Rebecca (Edgerunners) (68), Ondine (Misty) (69), Jessie (Team Rocket) (72), Princesse Daisy (75), Orihime Inoue (76), Alcina Dimitrescu (77), Mai Shiranui (78), Monika (DDLC) (79), Nemona (Pokémon) (80), Shûko Komi (mère de Komi) (83), Kyôka Jirô (84), Nezuko (87), Lucy Heartfilia (88), Jill Valentine (90), Palutena (91), Yuri (DDLC) (94), Tsuyu Asui (95), Erza Scarlet (96), Mina Ashido (97), Aurore (Dawn) (98), Flora (Pokémon) (99), Ahri (100), Rin Tôsaka (102), Sakura Haruno (103), Pauline (Mario) (104), Megumin (105), Ashley Graham (107), Yoko Littner (108), Purah (109), Mei (Overwatch) (110), Asuka Langley (112), Chika Fujiwara (113), Natsuki (DDLC) (115), Misa Amane (116), Rosemary (Marnie) (117), Sayori (DDLC) (118), Stocking Anarchy (122), Rei Ayanami (124), Jolyne Kujo (130). Répartition des identifiés : Cartoons 77, Comics 10, Furry 11. Votants par image : 764 à 4473.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Raven | Cartoons | 4473 | 39 707 | 5 |  |
| 2 | 3 | Starfire | Cartoons | 2935 | 21 791 | 16 |  |
| 3 | 13 | Gwen Stacy (Spider-Verse) | Comics | 2279 | 19 716 | 21 |  |
| 4 | 22 | Mavis | Cartoons | 2608 | 8 447 | 69 |  |
| 5 | 25 | Hélène Parr / Elastigirl | Cartoons | 1133 | 15 935 | 31 |  |
| 6 | 28 | Harley Quinn | Cartoons | 1547 | 26 362 | 9 |  |
| 7 | 35 | Shego | Cartoons | 2322 | 7 856 | 73 |  |
| 8 | 37 | Wonder Woman | Comics | 1212 | 22 974 | 14 |  |
| 9 | 39 | Ty Lee | Cartoons | 3122 | 5 660 | 104 |  |
| 10 | 41 | Chel | Cartoons | 878 | 11 392 | 49 |  |
| 11 | 45 | Azula | Cartoons | 2183 | 12 587 | 44 |  |
| 12 | 47 | Jessica Rabbit | Cartoons | 1179 | 12 174 | 46 |  |
| 13 | 49 | Wendy Corduroy | Cartoons | 2329 | 5 038 | 116 |  |
| 14 | 51 | Daphné | Cartoons | 1164 | 6 963 | 86 |  |
| 15 | 53 | Kim Possible | Cartoons | 2340 | 12 439 | 45 |  |
| 16 | 55 | Gwen (Total Drama) | Cartoons | 3349 | 4 327 | sous 5 011 | compte autocomplétion |
| 17 | 62 | Tante Cass | Cartoons | 1071 | 4 966 | sous 5 011 | compte autocomplétion |
| 18 | 70 | Toph | Cartoons | 3100 | 9 643 | 60 |  |
| 19 | 71 | Lola Bunny | Furry | 1033 | 8 547 | 68 |  |
| 20 | 73 | Korra | Cartoons | 981 | 13 757 | 41 |  |
| 21 | 74 | Vanessa Doofenshmirtz | Cartoons | 1349 | 765 | sous 5 011 | compte autocomplétion |
| 22 | 81 | Belle | Cartoons | 1070 | 3 317 | sous 5 011 | compte autocomplétion |
| 23 | 82 | Poison Ivy | Comics | 844 | 7 409 | 78 |  |
| 24 | 85 | Raiponce | Cartoons | 1445 | 6 348 | 95 | tag générique |
| 25 | 86 | Véra (Velma) | Cartoons | 1153 | 14 935 | 35 |  |
| 26 | 89 | Katara | Cartoons | 1756 | 12 083 | 47 |  |
| 27 | 92 | GoGo Tomago | Cartoons | 1031 | 2 278 | sous 5 011 | compte autocomplétion |
| 28 | 93 | Jane Porter | Cartoons | 941 | 2 289 | sous 5 011 | compte autocomplétion |
| 29 | 101 | Mulan | Cartoons | 944 | 1 888 | sous 5 011 | tag générique; compte autocomplétion |
| 30 | 106 | Jinx (Teen Titans) | Comics | 1189 | 3 260 | sous 5 011 | compte autocomplétion |
| 31 | 111 | Elsa | Cartoons | 1524 | 14 890 | 37 |  |
| 32 | 114 | Violette Parr | Cartoons | 1053 | 7 665 | 75 |  |
| 33 | 119 | Marceline | Cartoons | 935 | 8 284 | 70 |  |
| 34 | 120 | Marinette / Ladybug | Cartoons | 2630 | 6 437 | 91 |  |
| 35 | 121 | Supergirl | Comics | 1123 | 16 375 | 30 |  |
| 36 | 123 | Ann Possible | Cartoons | 2223 | 2 843 | sous 5 011 | compte autocomplétion |
| 37 | 125 | Suki | Cartoons | 1287 | 1 534 | sous 5 011 | tag générique; compte autocomplétion |
| 38 | 126 | April O'Neil | Comics | 897 | 5 475 | 107 |  |
| 39 | 127 | Gwen Tennyson | Cartoons | 1811 | 21 472 | 17 |  |
| 40 | 128 | Mirage (Aladdin) | Cartoons | 932 | 503 | sous 5 011 | compte autocomplétion |
| 41 | 129 | Kida | Cartoons | 1004 | 1 406 | sous 5 011 | tag générique; compte autocomplétion |
| 42 | 135 | Gardevoir | Furry | 1441 | 41 237 | 4 |  |
| 43 | 136 | La sauveteuse (Lilo & Stitch) | Cartoons | 925 | 973 | sous 5 011 | compte autocomplétion |
| 44 | 138 | Princesse Chewing-gum | Cartoons | 931 | 9 974 | 59 |  |
| 45 | 139 | Jasmine | Cartoons | 1288 | 7 518 | 77 |  |
| 46 | 140 | Mégara | Cartoons | 1529 | 1 693 | sous 5 011 | compte autocomplétion |
| 47 | 143 | Lockpin (Lopunny) | Furry | 924 | 23 999 | 12 |  |
| 48 | 144 | Ariel | Cartoons | 1540 | 4 354 | sous 5 011 | compte autocomplétion |
| 49 | 145 | Sam (Totally Spies) | Cartoons | 876 | 3 099 | sous 5 011 | compte autocomplétion |
| 50 | 146 | Ankha | Furry | 932 | 17 729 | 26 |  |
| 51 | 149 | Ahsoka Tano | Cartoons | 882 | 14 807 | 38 |  |
| 52 | 150 | Asami Sato | Cartoons | 776 | 3 611 | sous 5 011 | compte autocomplétion |
| 53 | 152 | Courtney | Cartoons | 3156 | 2 127 | sous 5 011 | compte autocomplétion |
| 54 | 154 | Honey Lemon | Cartoons | 1027 | 1 237 | sous 5 011 | compte autocomplétion |
| 55 | 157 | Anna | Cartoons | 1493 | 6 383 | 93 |  |
| 56 | 158 | Astrid | Cartoons | 798 | 5 127 | 114 |  |
| 57 | 159 | Leni Loud | Cartoons | 2627 | 2 514 | sous 5 011 | compte autocomplétion |
| 58 | 161 | Clover | Cartoons | 863 | 2 826 | sous 5 011 | compte autocomplétion |
| 59 | 163 | Aurore | Cartoons | 921 | 2 261 | sous 5 011 | compte autocomplétion |
| 60 | 166 | Lindsay | Cartoons | 3191 | 2 535 | sous 5 011 | compte autocomplétion |
| 61 | 167 | Sam Manson | Cartoons | 962 | 1 735 | sous 5 011 | compte autocomplétion |
| 62 | 168 | Nani | Cartoons | 928 | 2 915 | sous 5 011 | compte autocomplétion |
| 63 | 171 | Jackie Lynn Thomas | Cartoons | 1256 | 2 987 | sous 5 011 | compte autocomplétion |
| 64 | 172 | Rouge the Bat | Furry | 1439 | 45 414 | 1 |  |
| 65 | 173 | Batgirl (Barbara Gordon) | Comics | 1096 | 7 875 | 72 |  |
| 66 | 174 | La mère de Dexter | Cartoons | 910 | 20 | sous 5 011 | compte autocomplétion |
| 67 | 176 | Vaiana | Cartoons | 846 | 1 610 | sous 5 011 | tag générique; compte autocomplétion |
| 68 | 177 | Esmeralda | Cartoons | 992 | 893 | sous 5 011 | tag générique; compte autocomplétion |
| 69 | 178 | Bloom (Winx Club) | Cartoons | 1018 | 1 340 | sous 5 011 | compte autocomplétion |
| 70 | 180 | Fionna | Cartoons | 900 | 5 055 | 115 |  |
| 71 | 184 | Nicole Watterson | Furry | 1553 | 9 366 | 63 |  |
| 72 | 187 | Vicky (Mes parrains sont magiques) | Cartoons | 1447 | 2 114 | sous 5 011 | compte autocomplétion |
| 73 | 189 | Miss Heed (Villainous) | Cartoons | 2171 | 1 172 | sous 5 011 | compte autocomplétion |
| 74 | 191 | Alex | Cartoons | 866 | 2 645 | sous 5 011 | compte autocomplétion |
| 75 | 192 | Ember McLain | Cartoons | 928 | 758 | sous 5 011 | compte autocomplétion |
| 76 | 193 | non identifiée |  | 764 |  |  |  |
| 77 | 194 | Fluttershy (Equestria Girls) | Furry | 2359 | 26 448 | 8 |  |
| 78 | 195 | Maddie Fenton | Cartoons | 943 | 3 690 | sous 5 011 | compte autocomplétion |
| 79 | 196 | Zatanna | Comics | 1065 | 3 952 | sous 5 011 | compte autocomplétion |
| 80 | 198 | Heather | Cartoons | 1071 | 2 404 | sous 5 011 | compte autocomplétion |
| 81 | 199 | Peni Parker | Comics | 2423 | 3 306 | sous 5 011 | compte autocomplétion |
| 82 | 200 | Jessica Cruz (Green Lantern) | Comics | 1065 | 858 | sous 5 011 | compte autocomplétion |
| 83 | 201 | Trixie Tang | Cartoons | 1405 | 1 354 | sous 5 011 | compte autocomplétion |
| 84 | 204 | Judy Hopps | Furry | 1006 | 26 160 | 10 |  |
| 85 | 207 | Isabela Madrigal | Cartoons | 796 | 482 | sous 5 011 | compte autocomplétion |
| 86 | 208 | Pinkie Pie (Equestria Girls) | Furry | 2314 | 19 483 | 22 |  |
| 87 | 209 | Millie | Furry | 779 | 9 057 | 64 |  |
| 88 | 210 | Mai (Avatar) | Cartoons | 824 | 2 370 | sous 5 011 | compte autocomplétion |
| 89 | 211 | Amy Rose | Furry | 1425 | 41 846 | 3 |  |
| 90 | 212 | Lori Loud | Cartoons | 1930 | 2 685 | sous 5 011 | compte autocomplétion |
| 91 | 213 | Tiana | Cartoons | 1014 | 922 | sous 5 011 | tag générique; compte autocomplétion |
| 92 | 214 | L'Autre Mère (Coraline) | Cartoons | 909 | 717 | sous 5 011 | compte autocomplétion |
| 93 | 215 | Sergent Calhoun | Cartoons | 1011 | 285 | sous 5 011 | compte autocomplétion |
| 94 | 216 | Mabel Pines | Cartoons | 2900 | 3 956 | sous 5 011 | compte autocomplétion |
| 95 | 219 | Charlie Morningstar | Cartoons | 801 | 10 604 | 53 |  |
| 96 | 220 | Audrey Ramirez | Cartoons | 959 | 397 | sous 5 011 | compte autocomplétion |
| 97 | 221 | Hekapoo | Cartoons | 1255 | 3 067 | sous 5 011 | compte autocomplétion |
| 98 | 222 | Princesse Fiona | Cartoons | 792 | 1 081 | sous 5 011 | tag générique; compte autocomplétion |
| 99 | 223 | Fée Clochette | Cartoons | 967 | 3 867 | sous 5 011 | compte autocomplétion |
| 100 | 225 | non identifiée |  | 2320 |  |  |  |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | 172 | 1439 |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | 211 | 1425 |
| 4 | Gardevoir | Furry | 41 237 | 135 | 1441 |
| 5 | Raven | Cartoons | 39 707 | 1 | 4473 |
| 6 | Renamon | Furry | 33 274 | 298 | 795 |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | 242 | 1422 |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | 194 | 2359 |
| 9 | Harley Quinn | Cartoons | 26 362 | 28 | 1547 |
| 10 | Judy Hopps | Furry | 26 160 | 204 | 1006 |
| 11 | Toriel | Furry | 24 145 | 260 | 869 |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | 143 | 924 |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | 258 | 1282 |
| 14 | Wonder Woman | Comics | 22 974 | 37 | 1212 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | 227 | 1591 |
| 16 | Starfire | Cartoons | 21 791 | 3 | 2935 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | 127 | 1811 |
| 18 | Marie (Isabelle) | Furry | 20 826 | 273 | 1679 |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 13 | 2279 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | 208 | 2314 |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | 240 | 1273 |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | 146 | 932 |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | 325 | 929 |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | 310 | 746 |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | 121 | 1123 |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 25 | 1133 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | 238 | 1388 |
| 34 | Black Cat | Comics | 15 119 | non trouvé |  |
| 35 | Véra (Velma) | Cartoons | 14 935 | 86 | 1153 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | 111 | 1524 |
| 38 | Ahsoka Tano | Cartoons | 14 807 | 149 | 882 |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 73 | 981 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | 45 | 2183 |
| 45 | Kim Possible | Cartoons | 12 439 | 53 | 2340 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 47 | 1179 |
| 47 | Katara | Cartoons | 12 083 | 89 | 1756 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 41 | 878 |
| 50 | Vanilla | Furry | 11 235 | 281 | 1366 |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | 219 | 801 |
| 54 | Cream the Rabbit | Furry | 10 519 | 295 | 1372 |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | non trouvé |  |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 138 | 931 |
| 60 | Toph | Cartoons | 9 643 | 70 | 3100 |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | 184 | 1553 |
| 64 | Millie | Furry | 9 057 | 209 | 779 |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | non trouvé |  |
| 68 | Lola Bunny | Furry | 8 547 | 71 | 1033 |
| 69 | Mavis | Cartoons | 8 447 | 22 | 2608 |
| 70 | Marceline | Cartoons | 8 284 | 119 | 935 |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 173 | 1096 |
| 73 | Shego | Cartoons | 7 856 | 35 | 2322 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | 114 | 1053 |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | 139 | 1288 |
| 78 | Poison Ivy | Comics | 7 409 | 82 | 844 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 51 | 1164 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | 265 | 1104 |
| 89 | Frankie Foster | Cartoons | 6 704 | 237 | 2186 |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | 120 | 2630 |
| 92 | Amity Blight | Cartoons | 6 411 | 271 | 2600 |
| 93 | Anna | Cartoons | 6 383 | 157 | 1493 |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | 85 | 1445 |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | 268 | 1272 |
| 102 | Star Butterfly | Cartoons | 5 697 | 241 | 1647 |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 39 | 3122 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 126 | 897 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | 158 | 798 |
| 115 | Fionna | Cartoons | 5 055 | 180 | 900 |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 49 | 2329 |

## Vote 436045 — modèle « Cartoon Hotties » (295 images, vote encore ouvert, relevé du 24/10/2026 ; malgré le titre, environ un tiers d'anime, retirés)

Retirés : Nami (10), Tsunade (11), Mt. Lady (16), Fubuki (17), Makio, Suma et Hinatsuru (Demon Slayer, image de groupe) (18), Nico Robin (20), Boa Hancock (28), Midnight (29), Mirko (Rumi Usagiyama) (30), C-18 (36), Hinata Hyûga (41), Momo Yaoyorozu (44), Mitsuri Kanroji (46), Ochako Uraraka (48), Mikasa Ackerman (49), Ino Yamanaka (51), Daki (53), Tatsumaki (54), Misato Katsuragi (55), Lady Nagant (56), Asuka Langley (58), Bulma (59), Rei Ayanami (61), Mei Hatsume (64), Mari Makinami (65), Vivi (66), Nejire Hadô (67), Mei Terumî (71), Shinobu Kochô (73), Temari (78), Himiko Toga (79), Kanae Kochô (81), Nana Shimura (88), Tsuyu Asui (90), Mina Ashido (91), Chichi (97). Répartition des identifiés : Cartoons 56, Comics 40, Furry 3. Votants par image : 1054 à 3303.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 1 | Chel | Cartoons | 1206 | 11 392 | 49 |  |
| 2 | 2 | Hélène Parr / Elastigirl | Cartoons | 1193 | 15 935 | 31 |  |
| 3 | 3 | Jessica Rabbit | Cartoons | 1811 | 12 174 | 46 |  |
| 4 | 4 | Raven | Cartoons | 1499 | 39 707 | 5 |  |
| 5 | 5 | Black Canary | Comics | 2923 | 2 613 | sous 5 011 | compte autocomplétion |
| 6 | 6 | Shego | Cartoons | 1416 | 7 856 | 73 |  |
| 7 | 7 | Starfire | Cartoons | 1428 | 21 791 | 16 |  |
| 8 | 8 | Tante Cass | Cartoons | 1147 | 4 966 | sous 5 011 | compte autocomplétion |
| 9 | 9 | Wonder Woman | Comics | 1326 | 22 974 | 14 |  |
| 10 | 12 | Lola Bunny | Furry | 1651 | 8 547 | 68 |  |
| 11 | 13 | Korra | Cartoons | 1684 | 13 757 | 41 |  |
| 12 | 14 | Goblin Queen (Madelyne Pryor) | Comics | 1912 | 477 | sous 5 011 | compte autocomplétion |
| 13 | 15 | Daphné | Cartoons | 2391 | 6 963 | 86 |  |
| 14 | 19 | Black Widow | Comics | 2759 | 10 379 | 55 |  |
| 15 | 21 | GoGo Tomago | Cartoons | 1104 | 2 278 | sous 5 011 | compte autocomplétion |
| 16 | 22 | La sauveteuse (Lilo & Stitch) | Cartoons | 1098 | 973 | sous 5 011 | compte autocomplétion |
| 17 | 23 | Atom Eve | Comics | 3179 | 3 662 | sous 5 011 | compte autocomplétion |
| 18 | 24 | Harley Quinn | Cartoons | 1977 | 26 362 | 9 |  |
| 19 | 25 | Black Cat | Comics | 2827 | 15 119 | 34 |  |
| 20 | 26 | Kim Possible | Cartoons | 1677 | 12 439 | 45 |  |
| 21 | 27 | Blackfire | Comics | 2814 | 4 245 | sous 5 011 | compte autocomplétion |
| 22 | 31 | Malicia (Rogue) | Comics | 1409 | 8 641 | 67 |  |
| 23 | 32 | Captain Marvel (Carol Danvers) | Comics | 2521 | 2 767 | sous 5 011 | compte autocomplétion |
| 24 | 33 | Batgirl (Barbara Gordon) | Comics | 3016 | 7 875 | 72 |  |
| 25 | 34 | Talia al Ghul | Comics | 1271 | 460 | sous 5 011 | compte autocomplétion |
| 26 | 35 | Zatanna | Comics | 1230 | 3 952 | sous 5 011 | compte autocomplétion |
| 27 | 37 | Supergirl | Comics | 1311 | 16 375 | 30 |  |
| 28 | 38 | Gwen (Total Drama) | Cartoons | 1938 | 4 327 | sous 5 011 | compte autocomplétion |
| 29 | 39 | Asami Sato | Cartoons | 3083 | 3 611 | sous 5 011 | compte autocomplétion |
| 30 | 40 | Sara Bellum | Cartoons | 1226 | 1 624 | sous 5 011 | compte autocomplétion |
| 31 | 42 | Viper (Marvel) | Comics | 1221 | 42 | sous 5 011 | compte autocomplétion |
| 32 | 43 | Catwoman | Comics | 2500 | 10 167 | 56 |  |
| 33 | 45 | April O'Neil | Comics | 3175 | 5 475 | 107 |  |
| 34 | 47 | Huntress | Comics | 1770 | 902 | sous 5 011 | compte autocomplétion |
| 35 | 50 | Véra (Velma) | Cartoons | 1322 | 14 935 | 35 |  |
| 36 | 52 | Azula | Cartoons | 3007 | 12 587 | 44 |  |
| 37 | 57 | Poison Ivy | Comics | 1387 | 7 409 | 78 |  |
| 38 | 60 | Mockingbird | Comics | 1412 | 93 | sous 5 011 | compte autocomplétion |
| 39 | 62 | Star Sapphire | Comics | 1304 | 312 | sous 5 011 | compte autocomplétion |
| 40 | 63 | Astrid | Cartoons | 1113 | 5 127 | 114 |  |
| 41 | 68 | Wendy Corduroy | Cartoons | 1267 | 5 038 | 116 |  |
| 42 | 69 | Anissa (Invincible) | Comics | 3272 | 349 | sous 5 011 | compte autocomplétion |
| 43 | 70 | Vanessa Doofenshmirtz | Cartoons | 1291 | 765 | sous 5 011 | compte autocomplétion |
| 44 | 72 | L'Enchanteresse (Amora) | Comics | 1960 | 242 | sous 5 011 | compte autocomplétion |
| 45 | 74 | Ellen Yin | Cartoons | 1998 | 56 | sous 5 011 | identification incertaine; compte autocomplétion |
| 46 | 75 | Nani | Cartoons | 1070 | 2 915 | sous 5 011 | compte autocomplétion |
| 47 | 76 | Lindsay | Cartoons | 1578 | 2 535 | sous 5 011 | compte autocomplétion |
| 48 | 77 | Terra | Comics | 1286 | 1 434 | sous 5 011 | compte autocomplétion |
| 49 | 80 | Gwen Tennyson | Cartoons | 1894 | 21 472 | 17 |  |
| 50 | 82 | Hawkgirl | Comics | 1817 | 917 | sous 5 011 | compte autocomplétion |
| 51 | 83 | Mirage (Les Indestructibles) | Cartoons | 1074 | 898 | sous 5 011 | compte autocomplétion |
| 52 | 84 | Bridgette | Cartoons | 2609 | 979 | sous 5 011 | compte autocomplétion |
| 53 | 85 | Ty Lee | Cartoons | 1264 | 5 660 | 104 |  |
| 54 | 86 | Giganta | Comics | 1845 | 595 | sous 5 011 | compte autocomplétion |
| 55 | 87 | Jean Grey | Comics | 1701 | 4 029 | sous 5 011 | compte autocomplétion |
| 56 | 89 | Gwen Stacy (Spider-Verse) | Comics | 1833 | 19 716 | 21 |  |
| 57 | 92 | Marceline | Cartoons | 1538 | 8 284 | 70 |  |
| 58 | 93 | La Guêpe | Comics | 1230 | 1 236 | sous 5 011 | compte autocomplétion |
| 59 | 94 | Tornade (Storm) | Comics | 1312 | 4 390 | sous 5 011 | compte autocomplétion |
| 60 | 95 | Nicole Watterson | Furry | 1488 | 9 366 | 63 |  |
| 61 | 96 | Les Hex Girls (Scooby-Doo) | Cartoons | 1763 | 317 | sous 5 011 | tag générique; compte autocomplétion |
| 62 | 98 | Fire (Justice League) | Comics | 1898 | 249 | sous 5 011 | compte autocomplétion |
| 63 | 99 | Fée Clochette | Cartoons | 1059 | 3 867 | sous 5 011 | compte autocomplétion |
| 64 | 100 | Charmcaster | Cartoons | 2279 | 928 | sous 5 011 | compte autocomplétion |
| 65 | 101 | Courtney | Cartoons | 2285 | 2 127 | sous 5 011 | compte autocomplétion |
| 66 | 102 | Izzy | Cartoons | 1720 | 687 | sous 5 011 | compte autocomplétion |
| 67 | 104 | Heather | Cartoons | 1805 | 2 404 | sous 5 011 | compte autocomplétion |
| 68 | 105 | Maria Hill | Comics | 1146 | 286 | sous 5 011 | compte autocomplétion |
| 69 | 106 | Lois Lane | Comics | 1107 | 2 939 | sous 5 011 | compte autocomplétion |
| 70 | 107 | Wilhamena | Cartoons | 1180 | 1 379 | sous 5 011 | identification incertaine; compte autocomplétion |
| 71 | 109 | Jinx (Teen Titans) | Comics | 1666 | 3 260 | sous 5 011 | compte autocomplétion |
| 72 | 110 | Honey Lemon | Cartoons | 1054 | 1 237 | sous 5 011 | compte autocomplétion |
| 73 | 111 | Karen Plankton | Cartoons | 1670 | 462 | sous 5 011 | compte autocomplétion |
| 74 | 112 | Miss Heed (Villainous) | Cartoons | 1394 | 1 172 | sous 5 011 | compte autocomplétion |
| 75 | 114 | Superwoman | Comics | 1260 | 732 | sous 5 011 | tag générique; compte autocomplétion |
| 76 | 115 | Shrinking Rae | Comics | 1335 | 322 | sous 5 011 | compte autocomplétion |
| 77 | 116 | Cleopatra (Clone High) | Cartoons | 1155 |  |  | pas de tag rule34 dédié (exclue des calculs) |
| 78 | 117 | Desiree (Danny Phantom) | Cartoons | 2128 | 1 061 | sous 5 011 | tag générique; compte autocomplétion |
| 79 | 118 | Vixen | Comics | 1197 | 717 | sous 5 011 | compte autocomplétion |
| 80 | 120 | Mai (Avatar) | Cartoons | 1456 | 2 370 | sous 5 011 | compte autocomplétion |
| 81 | 121 | Debbie Grayson | Comics | 2262 | 1 537 | sous 5 011 | compte autocomplétion |
| 82 | 122 | Leela | Cartoons | 1281 | 2 896 | sous 5 011 | compte autocomplétion |
| 83 | 123 | Princesse des flammes | Cartoons | 1965 | 1 784 | sous 5 011 | compte autocomplétion |
| 84 | 125 | Paulina (Danny Phantom) | Cartoons | 1366 | 999 | sous 5 011 | compte autocomplétion |
| 85 | 126 | Katara | Cartoons | 1604 | 12 083 | 47 |  |
| 86 | 127 | Fionna | Cartoons | 1996 | 5 055 | 115 |  |
| 87 | 128 | Duplikate | Comics | 2160 | 3 | sous 5 011 | compte autocomplétion |
| 88 | 129 | Mary Jane Watson | Comics | 1423 | 7 592 | 76 |  |
| 89 | 130 | EVE (WALL-E) | Cartoons | 1075 | 343 | sous 5 011 | compte autocomplétion |
| 90 | 132 | Vicki Vale | Comics | 1167 | 70 | sous 5 011 | compte autocomplétion |
| 91 | 133 | Adora (She-Ra) | Cartoons | 1138 | 2 605 | sous 5 011 | tag générique; compte autocomplétion |
| 92 | 135 | Sam Manson | Cartoons | 1304 | 1 735 | sous 5 011 | compte autocomplétion |
| 93 | 136 | Loona | Furry | 1500 | 43 049 | 2 |  |
| 94 | 138 | Jazz Fenton | Cartoons | 1637 | 828 | sous 5 011 | compte autocomplétion |
| 95 | 140 | Jessica (Rick et Morty) | Cartoons | 1661 | 818 | sous 5 011 | compte autocomplétion |
| 96 | 141 | Sally (Cars) | Cartoons | 1066 | 41 | sous 5 011 | compte autocomplétion |
| 97 | 142 | Susan et Mary Test | Cartoons | 1250 | 519 | sous 5 011 | compte autocomplétion |
| 98 | 143 | Amy Wong | Cartoons | 3303 | 1 537 | sous 5 011 | compte autocomplétion |
| 99 | 144 | Princesse Chewing-gum | Cartoons | 1393 | 9 974 | 59 |  |
| 100 | 145 | Maddie Fenton | Cartoons | 1454 | 3 690 | sous 5 011 | compte autocomplétion |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | 136 | 1500 |
| 3 | Amy Rose | Furry | 41 846 | non trouvé |  |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | 4 | 1499 |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | 24 | 1977 |
| 10 | Judy Hopps | Furry | 26 160 | non trouvé |  |
| 11 | Toriel | Furry | 24 145 | non trouvé |  |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | 9 | 1326 |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | 7 | 1428 |
| 17 | Gwen Tennyson | Cartoons | 21 472 | 80 | 1894 |
| 18 | Marie (Isabelle) | Furry | 20 826 | non trouvé |  |
| 19 | Emma Frost | Comics | 20 269 | non trouvé |  |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | 89 | 1833 |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | non trouvé |  |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | 37 | 1311 |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | 2 | 1193 |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | non trouvé |  |
| 34 | Black Cat | Comics | 15 119 | 25 | 2827 |
| 35 | Véra (Velma) | Cartoons | 14 935 | 50 | 1322 |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | non trouvé |  |
| 38 | Ahsoka Tano | Cartoons | 14 807 | non trouvé |  |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | 13 | 1684 |
| 42 | Hornet | Furry | 12 634 | non trouvé |  |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | 52 | 3007 |
| 45 | Kim Possible | Cartoons | 12 439 | 26 | 1677 |
| 46 | Jessica Rabbit | Cartoons | 12 174 | 3 | 1811 |
| 47 | Katara | Cartoons | 12 083 | 126 | 1604 |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | 1 | 1206 |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | non trouvé |  |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | 19 | 2759 |
| 56 | Catwoman | Comics | 10 167 | 43 | 2500 |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | non trouvé |  |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | 144 | 1393 |
| 60 | Toph | Cartoons | 9 643 | non trouvé |  |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | 95 | 1488 |
| 64 | Millie | Furry | 9 057 | 161 | 1410 |
| 65 | Kindred (Agneau) | Furry | 8 777 | non trouvé |  |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | 31 | 1409 |
| 68 | Lola Bunny | Furry | 8 547 | 12 | 1651 |
| 69 | Mavis | Cartoons | 8 447 | non trouvé |  |
| 70 | Marceline | Cartoons | 8 284 | 92 | 1538 |
| 71 | Marge Simpson | Cartoons | 8 044 | 147 | 1526 |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 33 | 3016 |
| 73 | Shego | Cartoons | 7 856 | 6 | 1416 |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | 129 | 1423 |
| 77 | Jasmine | Cartoons | 7 518 | non trouvé |  |
| 78 | Poison Ivy | Comics | 7 409 | 57 | 1387 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | 15 | 2391 |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | non trouvé |  |
| 94 | Lois Griffin | Cartoons | 6 381 | 166 | 1552 |
| 95 | Raiponce | Cartoons | 6 348 | non trouvé |  |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | 85 | 1264 |
| 105 | Magik | Comics | 5 651 | non trouvé |  |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | 45 | 3175 |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | 63 | 1113 |
| 115 | Fionna | Cartoons | 5 055 | 127 | 1996 |
| 116 | Wendy Corduroy | Cartoons | 5 038 | 68 | 1267 |

## Vote 73568440 — modèle « Ranking Female Video Game Charecters » (617 images, 11-18/09/2025 ; modèle jeux vidéo : seules ses 24 images du périmètre — personnages de comics et Furry — sont comparées)

Retirés : 2B (1), Tifa Lockhart (2), Samus Aran (3), Chun-Li (4), Princesse Zelda (5), Cynthia (Pokémon) (6), Lara Croft (7), Ada Wong (8), Harmonie (Rosalina) (9), Bayonetta (11), D.Va (13), Mercy (14), Ciri (15), Jill Valentine (16), Cammy White (17), Aerith (18), Juri Han (19), EVE (Stellar Blade) (20), A2 (21), Purah (22), Palutena (23), Ranni (25), Princesse Daisy (26), Princesse Peach (28), Luna Snow (29), Mai Shiranui (30), Sonia (Pokémon) (31), Gardienne du feu (Dark Souls) (32), Raiden Shogun (33), Widowmaker (34), Yelan (35), Melina (Elden Ring) (37), Elsa-Mina (Lusamine) (38), Saber (Artoria) (40), Ashe (Overwatch) (41), Panam Palmer (42), Urbosa (43), Nessa (Pokémon) (44), Makoto Niijima (45), Lady (Devil May Cry) (46), Yennefer (47), Rin Tôsaka (48), Yae Miko (49), Ashley Graham (50), Futaba Sakura (51), Morrigan (52), Jinx (League of Legends) (53), Ahri (54), Ann Takamaki (55), Marika (Elden Ring) (56), Lady Maria (Bloodborne) (57), Jade (Mortal Kombat) (58), Baiken (59), Miss Fortune (Sarah Fortune) (60), Tae Takemi (61), Kiriko (62), Pyra (63), Kafka (Star Rail) (64), Malenia (65), Pauline (Mario) (66), Claire Redfield (67), Ägir (Azur Lane) (68), Jane Doe (ZZZ) (69), Caitlyn (70), Mitsuru Kirijo (71), Burnice (72), Jessie (FF VII) (73), Lisa (Genshin) (75), Kainé (76), Camilla (77), Shenhe (78), Hilda (Pokémon) (79), Juliet Starling (80), Nicole Demara (81), Arlecchino (82), Nina Williams (83), Flora (Pokémon) (84), Lucifer (Helltaker) (85), Lucina (86), Faïza (Bea) (87), Marie Rose (88), Judy Alvarez (89), Acheron (90), Mavuika (91), Beidou (92), Lulu (FF X) (93), Modeus (94), Sae Niijima (95), Aphrodite (Hades) (96), Mona (97), Jessie (Team Rocket) (98), Quiet (99), Tracer (100), Felicia (Darkstalkers) (274). Répartition des identifiés : Cartoons 1, Comics 11, Furry 10. Votants par image : 154 à 919.

### Top 100 TierMaker (périmètre) → rule34

| # | Rang TM | Personnage | Médium | Votants | Publications r34 | Rang r34 (périmètre) | Remarque |
|---:|---:|---|---|---:|---:|---|---|
| 1 | 10 | Black Cat | Comics | 629 | 15 119 | 34 |  |
| 2 | 12 | Femme invisible | Comics | 202 | 10 816 | 52 |  |
| 3 | 24 | Psylocke | Comics | 177 | 7 511 | sous 5 011 | compte autocomplétion |
| 4 | 27 | Catwoman | Comics | 542 | 10 167 | 56 |  |
| 5 | 36 | Emma Frost | Comics | 187 | 20 269 | 19 |  |
| 6 | 39 | Harley Quinn | Cartoons | 424 | 26 362 | 9 |  |
| 7 | 74 | Magik | Comics | 169 | 5 651 | 105 |  |
| 8 | 147 | Poison Ivy | Comics | 261 | 7 409 | 78 |  |
| 9 | 193 | Batgirl (Barbara Gordon) | Comics | 517 | 7 875 | 72 |  |
| 10 | 201 | Ankha | Furry | 812 | 17 729 | 26 |  |
| 11 | 249 | Hornet | Furry | 376 | 12 634 | 42 |  |
| 12 | 291 | Amy Rose | Furry | 919 | 41 846 | 3 |  |
| 13 | 319 | Gamora | Comics | 353 | 820 | sous 5 011 | compte autocomplétion |
| 14 | 345 | Squirrel Girl (Doreen Green) | Comics | 163 | 10 093 | 57 |  |
| 15 | 374 | Blaze the Cat | Furry | 166 | 15 169 | 33 |  |
| 16 | 396 | Toriel | Furry | 181 | 24 145 | 11 |  |
| 17 | 409 | Marie (Isabelle) | Furry | 397 | 20 826 | 18 |  |
| 18 | 443 | Blanche-Neige (Fables / The Wolf Among Us) | Comics | 174 |  |  | pas de tag rule34 dédié (exclue des calculs) |
| 19 | 561 | Lapin Peach (Rabbid Peach) | Furry | 233 | 295 | sous 5 011 | compte autocomplétion |
| 20 | 568 | Amaterasu (Okami) | Furry | 753 | 1 810 | sous 5 011 | tag générique; compte autocomplétion |
| 21 | 573 | Rivet | Furry | 200 | 3 745 | sous 5 011 | compte autocomplétion |
| 22 | 576 | Kindred (Agneau) | Furry | 154 | 8 777 | 65 |  |
| 23 | 591 | Kamala Khan (Ms. Marvel) | Comics | 280 | 1 876 | sous 5 011 | compte autocomplétion |

### Liste rule34 du périmètre (116) → rang dans ce modèle

| Rang r34 | Personnage | Médium | Publications | Rang TM | Votants |
|---:|---|---|---:|---|---:|
| 1 | Rouge the Bat | Furry | 45 414 | non trouvé |  |
| 2 | Loona | Furry | 43 049 | non trouvé |  |
| 3 | Amy Rose | Furry | 41 846 | 291 | 919 |
| 4 | Gardevoir | Furry | 41 237 | non trouvé |  |
| 5 | Raven | Cartoons | 39 707 | non trouvé |  |
| 6 | Renamon | Furry | 33 274 | non trouvé |  |
| 7 | Twilight Sparkle (Equestria Girls) | Furry | 30 892 | non trouvé |  |
| 8 | Fluttershy (Equestria Girls) | Furry | 26 448 | non trouvé |  |
| 9 | Harley Quinn | Cartoons | 26 362 | 39 | 424 |
| 10 | Judy Hopps | Furry | 26 160 | non trouvé |  |
| 11 | Toriel | Furry | 24 145 | 396 | 181 |
| 12 | Lockpin (Lopunny) | Furry | 23 999 | non trouvé |  |
| 13 | Rainbow Dash (Equestria Girls) | Furry | 23 923 | non trouvé |  |
| 14 | Wonder Woman | Comics | 22 974 | non trouvé |  |
| 15 | Rarity (Equestria Girls) | Furry | 22 555 | non trouvé |  |
| 16 | Starfire | Cartoons | 21 791 | non trouvé |  |
| 17 | Gwen Tennyson | Cartoons | 21 472 | non trouvé |  |
| 18 | Marie (Isabelle) | Furry | 20 826 | 409 | 397 |
| 19 | Emma Frost | Comics | 20 269 | 36 | 187 |
| 20 | Krystal | Furry | 19 783 | non trouvé |  |
| 21 | Gwen Stacy (Spider-Verse) | Comics | 19 716 | non trouvé |  |
| 22 | Pinkie Pie (Equestria Girls) | Furry | 19 483 | non trouvé |  |
| 23 | Applejack (Equestria Girls) | Furry | 18 411 | non trouvé |  |
| 24 | Aquali (Vaporeon) | Furry | 18 056 | non trouvé |  |
| 25 | Yang Xiao Long | Cartoons | 17 965 | non trouvé |  |
| 26 | Ankha | Furry | 17 729 | 201 | 812 |
| 27 | Celestia (Equestria Girls) | Furry | 17 047 | non trouvé |  |
| 28 | Luna (Equestria Girls) | Furry | 16 864 | non trouvé |  |
| 29 | Givrali (Glaceon) | Furry | 16 462 | non trouvé |  |
| 30 | Supergirl | Comics | 16 375 | non trouvé |  |
| 31 | Hélène Parr / Elastigirl | Cartoons | 15 935 | non trouvé |  |
| 32 | Ruby Rose | Cartoons | 15 701 | non trouvé |  |
| 33 | Blaze the Cat | Furry | 15 169 | 374 | 166 |
| 34 | Black Cat | Comics | 15 119 | 10 | 629 |
| 35 | Véra (Velma) | Cartoons | 14 935 | non trouvé |  |
| 36 | Toy Chica | Furry | 14 905 | non trouvé |  |
| 37 | Elsa | Cartoons | 14 890 | non trouvé |  |
| 38 | Ahsoka Tano | Cartoons | 14 807 | non trouvé |  |
| 39 | Weiss Schnee | Cartoons | 14 113 | non trouvé |  |
| 40 | Power Girl | Comics | 13 942 | non trouvé |  |
| 41 | Korra | Cartoons | 13 757 | non trouvé |  |
| 42 | Hornet | Furry | 12 634 | 249 | 376 |
| 43 | Pomni | Cartoons | 12 589 | non trouvé |  |
| 44 | Azula | Cartoons | 12 587 | non trouvé |  |
| 45 | Kim Possible | Cartoons | 12 439 | non trouvé |  |
| 46 | Jessica Rabbit | Cartoons | 12 174 | non trouvé |  |
| 47 | Katara | Cartoons | 12 083 | non trouvé |  |
| 48 | Roxanne Wolf | Furry | 11 401 | non trouvé |  |
| 49 | Chel | Cartoons | 11 392 | non trouvé |  |
| 50 | Vanilla | Furry | 11 235 | non trouvé |  |
| 51 | Blake Belladonna | Cartoons | 10 881 | non trouvé |  |
| 52 | Femme invisible | Comics | 10 816 | 12 | 202 |
| 53 | Charlie Morningstar | Cartoons | 10 604 | non trouvé |  |
| 54 | Cream the Rabbit | Furry | 10 519 | non trouvé |  |
| 55 | Black Widow | Comics | 10 379 | non trouvé |  |
| 56 | Catwoman | Comics | 10 167 | 27 | 542 |
| 57 | Squirrel Girl (Doreen Green) | Comics | 10 093 | 345 | 163 |
| 58 | Psylocke | Comics | 10 006 | non trouvé |  |
| 59 | Princesse Chewing-gum | Cartoons | 9 974 | non trouvé |  |
| 60 | Toph | Cartoons | 9 643 | non trouvé |  |
| 61 | Sally Acorn | Furry | 9 562 | non trouvé |  |
| 62 | Susie | Furry | 9 501 | non trouvé |  |
| 63 | Nicole Watterson | Furry | 9 366 | non trouvé |  |
| 64 | Millie | Furry | 9 057 | non trouvé |  |
| 65 | Kindred (Agneau) | Furry | 8 777 | 576 | 154 |
| 66 | Coco Bandicoot | Furry | 8 730 | non trouvé |  |
| 67 | Malicia (Rogue) | Comics | 8 641 | non trouvé |  |
| 68 | Lola Bunny | Furry | 8 547 | non trouvé |  |
| 69 | Mavis | Cartoons | 8 447 | non trouvé |  |
| 70 | Marceline | Cartoons | 8 284 | non trouvé |  |
| 71 | Marge Simpson | Cartoons | 8 044 | non trouvé |  |
| 72 | Batgirl (Barbara Gordon) | Comics | 7 875 | 193 | 517 |
| 73 | Shego | Cartoons | 7 856 | non trouvé |  |
| 74 | She-Hulk | Comics | 7 675 | non trouvé |  |
| 75 | Violette Parr | Cartoons | 7 665 | non trouvé |  |
| 76 | Mary Jane Watson | Comics | 7 592 | non trouvé |  |
| 77 | Jasmine | Cartoons | 7 518 | non trouvé |  |
| 78 | Poison Ivy | Comics | 7 409 | 147 | 261 |
| 79 | Reine Chrysalis | Furry | 7 334 | non trouvé |  |
| 80 | Noelle Holiday | Furry | 7 286 | non trouvé |  |
| 81 | Luz Noceda | Cartoons | 7 228 | non trouvé |  |
| 82 | Meow Skulls | Furry | 7 049 | non trouvé |  |
| 83 | Diane Foxington | Furry | 7 036 | non trouvé |  |
| 84 | Péridot | Cartoons | 7 018 | non trouvé |  |
| 85 | Chica | Furry | 6 995 | non trouvé |  |
| 86 | Daphné | Cartoons | 6 963 | non trouvé |  |
| 87 | Princesse Cadance | Furry | 6 936 | non trouvé |  |
| 88 | Jenny Wakeman (XJ-9) | Cartoons | 6 893 | non trouvé |  |
| 89 | Frankie Foster | Cartoons | 6 704 | non trouvé |  |
| 90 | Ariel | Cartoons | 6 586 | non trouvé |  |
| 91 | Marinette / Ladybug | Cartoons | 6 437 | non trouvé |  |
| 92 | Amity Blight | Cartoons | 6 411 | non trouvé |  |
| 93 | Anna | Cartoons | 6 383 | non trouvé |  |
| 94 | Lois Griffin | Cartoons | 6 381 | non trouvé |  |
| 95 | Raiponce | Cartoons | 6 348 | non trouvé |  |
| 96 | Ragatha | Cartoons | 6 289 | non trouvé |  |
| 97 | Trixie Lulamoon | Furry | 6 137 | non trouvé |  |
| 98 | Kit (Kit Bodega) | Furry | 6 069 | non trouvé |  |
| 99 | Vaggie | Cartoons | 5 958 | non trouvé |  |
| 100 | Raven Team Leader | Furry | 5 862 | non trouvé |  |
| 101 | Lapis Lazuli | Cartoons | 5 844 | non trouvé |  |
| 102 | Star Butterfly | Cartoons | 5 697 | non trouvé |  |
| 103 | Muffet | Furry | 5 667 | non trouvé |  |
| 104 | Ty Lee | Cartoons | 5 660 | non trouvé |  |
| 105 | Magik | Comics | 5 651 | 74 | 169 |
| 106 | Surge the Tenrec | Furry | 5 619 | non trouvé |  |
| 107 | April O'Neil | Comics | 5 475 | non trouvé |  |
| 108 | La mère de Dexter | Cartoons | 5 439 | non trouvé |  |
| 109 | Perle (Pearl) | Cartoons | 5 347 | non trouvé |  |
| 110 | Tawna Bandicoot | Furry | 5 343 | non trouvé |  |
| 111 | Undyne | Furry | 5 244 | non trouvé |  |
| 112 | Tigresse | Furry | 5 210 | non trouvé |  |
| 113 | Pyrrha Nikos | Cartoons | 5 207 | non trouvé |  |
| 114 | Astrid | Cartoons | 5 127 | non trouvé |  |
| 115 | Fionna | Cartoons | 5 055 | non trouvé |  |
| 116 | Wendy Corduroy | Cartoons | 5 038 | non trouvé |  |

## Méthode et limites

- Médium : classement v5 pour les personnages de la sélection ; sinon médium de création (DC/Marvel/Invincible = Comics, Raven et Starfire en Cartoons à ta demande, Harley Quinn en Cartoons comme dans la v5). Les versions Equestria Girls (humaines) sont rattachées aux poneys MLP, donc en Furry.
- Identification visuelle sur planches contact (pas d'étiquettes sur ces images) ; cas douteux signalés. Recherche de la liste rule34 dans tout le modèle en miniatures : un personnage peu lisible a pu être manqué.
- Publications : sélection 388 dédupliquée (pages 1 à 390) ; sinon autocomplétion rule34 du 24 oct. 2026 (compteurs pouvant être en retard, variantes non fusionnées ; tags génériques signalés).
- Spearman sur les personnages distincts identifiés du top 100 du périmètre (meilleure image).
- Fichiers : `identifications.py`, `comparer_perimetre.py`, CSV `top100_perimetre_<id>_vs_r34_2026-10-24.csv` (UTF-8 avec BOM).
