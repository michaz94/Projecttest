# Identifications visuelles (planches contact, 24 oct. 2026) des top 100 « Average Vote » de 4 votes TierMaker « dessins animés ».
# Tag rule34 et compte hors sélection = autocomplétion rule34 du 24 oct. 2026 (compteurs pouvant être en retard ; variantes non fusionnées).
# None = image non identifiée avec assez de certitude.
HORS={  # tag : publications (autocomplétion)
"shego":7855,"cass_hamada":4966,"gogo_tomago":2278,"blackfire":4245,"sergeant_calhoun":285,"rapunzel":5448,"jane_porter":2289,
"barbara_gordon":7095,"gwen_(tdi)":4327,"megara":1693,"black_canary":2613,"esmeralda":893,"daphne_blake":6960,"mulan":1888,
"vanessa_doofenshmirtz":765,"lifeguard_(lilo_and_stitch)":973,"kida":1406,"princess_jasmine":7287,"sara_bellum":1624,"moana":1610,
"aurora_(sleeping_beauty)":2261,"june_(avatar)":292,"dexters_mom":20,"honey_lemon":1237,"flame_princess":1784,"wendy_corduroy":5037,
"carmen_sandiego_(2019)":560,"april_o'neil":5474,"poison_ivy":7409,"pocahontas":2047,"belle_(beauty_and_the_beast)":3317,"asami_sato":3611,
"colette_tatou":487,"terra_(dc)":1434,"anna_(frozen)":6380,"violet_parr":7665,"susan_murphy":277,"clover_(totally_spies)":2826,
"fionna_the_human_girl":5054,"sam_(totally_spies)":3099,"helga_sinclair":421,"tiana":922,"ember_mclain":758,"charlotte_la_bouff":224,
"bridgette_(tdi)":979,"mai_(avatar)":2370,"la_muerte":122,"courtney_(tdi)":2127,"hawkgirl":917,"francine_smith":4122,"sam_manson":1735,
"dani_phantom":264,"marinette_dupain-cheng":6437,"sally_carrera":41,"flo_(cars)":4,"audrey_ramirez":397,"nani_pelekai":2915,
"master_tigress":5207,"ariel_(the_little_mermaid)":4354,"trixie_tang":1354,"turanga_leela":2896,"red_hot_riding_hood":229,
"cinderella_(1950_film)":1570,"merida":1216,"tinker_bell":3867,"disgust_(inside_out)":1569,"marge_simpson":8042,
"rose_quartz_(steven_universe)":676,"isabela_madrigal":482,"roxanne_(goof_troop)":1705,"snow_white_(disney)":2457,"lois_griffin":6380,
"jazz_fenton":828,"alex_(totally_spies)":2645,"wilma_flintstone":716,"bo_peep":244,"kitty_katswell":2825,"lapis_lazuli_(steven_universe)":5842,
"star_butterfly":5696,"mother_gothel":786,"jessie_(toy_story)":600,"beth_smith":1920,"alice_liddell":3616,"linda_flynn-fletcher":603,
"frankie_foster":6704,"zatanna":3952,"atom_eve":3662,"carmilla_(castlevania)":328,"sypha_belnades":782,"heather_(tdi)":2404,"suki":1534,
"raya_(ratld)":214,"vi_(league_of_legends)":767,"mystique":1502,"storm_(x-men)":4390,"lady_amalthea":82,"symmetra":3080,
"lindsay_(tdi)":2535,"brigitte_(overwatch_2_suit)":36,"scarlet_witch":4969,"wasp_(marvel)":1236,"huntress_(dc)":902,"anastasia_(film)":188,
"princess_peach_(movie)":322}
AMBIGU={"esmeralda","kida","suki","mulan","tiana","moana","rapunzel"}  # tag générique pouvant mêler plusieurs personnages
NOMS={"shego":"Shego","gwen_stacy":"Gwen Stacy (Spider-Verse)","chel":"Chel","helen_parr":"Hélène Parr / Elastigirl","starfire":"Starfire","raven_(dc)":"Raven",
"gogo_tomago":"GoGo Tomago","mavis_dracula":"Mavis","cass_hamada":"Tante Cass","jessica_rabbit":"Jessica Rabbit","blackfire":"Blackfire","lola_bunny":"Lola Bunny",
"wonder_woman":"Wonder Woman","kimberly_ann_possible":"Kim Possible","sergeant_calhoun":"Sergent Calhoun","rapunzel":"Raiponce","korra":"Korra",
"jane_porter":"Jane Porter","barbara_gordon":"Batgirl (Barbara Gordon)","gwen_(tdi)":"Gwen (Total Drama)","elsa_(frozen)":"Elsa","megara":"Mégara",
"harley_quinn":"Harley Quinn","black_canary":"Black Canary","esmeralda":"Esmeralda","supergirl":"Supergirl","daphne_blake":"Daphné","mulan":"Mulan",
"vanessa_doofenshmirtz":"Vanessa Doofenshmirtz","lifeguard_(lilo_and_stitch)":"La sauveteuse (Lilo & Stitch)","kida":"Kida","gwen_tennyson":"Gwen Tennyson",
"velma_dinkley":"Véra (Velma)","princess_jasmine":"Jasmine","marceline":"Marceline","sara_bellum":"Sara Bellum","moana":"Vaiana","aurora_(sleeping_beauty)":"Aurore",
"june_(avatar)":"June (Avatar)","judy_hopps":"Judy Hopps","dexters_mom":"La mère de Dexter","honey_lemon":"Honey Lemon","flame_princess":"Princesse des flammes",
"wendy_corduroy":"Wendy Corduroy","carmen_sandiego_(2019)":"Carmen Sandiego","april_o'neil":"April O'Neil","poison_ivy":"Poison Ivy","pocahontas":"Pocahontas",
"belle_(beauty_and_the_beast)":"Belle","asami_sato":"Asami Sato","colette_tatou":"Colette (Ratatouille)","terra_(dc)":"Terra","katara":"Katara","anna_(frozen)":"Anna",
"violet_parr":"Violette Parr","susan_murphy":"Susan / Génormica","nicole_watterson":"Nicole Watterson","clover_(totally_spies)":"Clover","fionna_the_human_girl":"Fionna",
"sam_(totally_spies)":"Sam (Totally Spies)","helga_sinclair":"Helga Sinclair","rogue_(x-men)":"Malicia (Rogue)","tiana":"Tiana","ember_mclain":"Ember McLain",
"charlotte_la_bouff":"Charlotte La Bouff","bridgette_(tdi)":"Bridgette","mai_(avatar)":"Mai (Avatar)","la_muerte":"La Muerte","courtney_(tdi)":"Courtney","hawkgirl":"Hawkgirl",
"francine_smith":"Francine Smith","loona_(helluva_boss)":"Loona","toph_bei_fong":"Toph","sam_manson":"Sam Manson","dani_phantom":"Dani Phantom",
"marinette_dupain-cheng":"Marinette / Ladybug","sally_carrera":"Sally (Cars)","millie_(helluva_boss)":"Millie","flo_(cars)":"Flo (Cars)","audrey_ramirez":"Audrey Ramirez",
"nani_pelekai":"Nani","master_tigress":"Tigresse","ariel_(the_little_mermaid)":"Ariel","trixie_tang":"Trixie Tang","turanga_leela":"Leela","red_hot_riding_hood":"Red Hot Riding Hood",
"cinderella_(1950_film)":"Cendrillon","merida":"Merida","tinker_bell":"Fée Clochette","princess_bubblegum":"Princesse Chewing-gum","disgust_(inside_out)":"Dégoût",
"marge_simpson":"Marge Simpson","rose_quartz_(steven_universe)":"Rose Quartz","isabela_madrigal":"Isabela Madrigal","roxanne_(goof_troop)":"Roxanne",
"snow_white_(disney)":"Blanche-Neige","lois_griffin":"Lois Griffin","jazz_fenton":"Jazz Fenton","alex_(totally_spies)":"Alex","wilma_flintstone":"Wilma Pierrafeu",
"bo_peep":"Bo la bergère","kitty_katswell":"Kitty Katswell","lapis_lazuli_(steven_universe)":"Lapis Lazuli","star_butterfly":"Star Butterfly","mother_gothel":"Mère Gothel",
"jessie_(toy_story)":"Jessie (Toy Story)","beth_smith":"Beth Smith","alice_liddell":"Alice","linda_flynn-fletcher":"Linda Flynn-Fletcher","frankie_foster":"Frankie Foster",
"black_cat_(marvel)":"Black Cat","zatanna":"Zatanna","catwoman":"Catwoman","atom_eve":"Atom Eve","jinx_(league_of_legends)":"Jinx (Arcane)","carmilla_(castlevania)":"Carmilla",
"sypha_belnades":"Sypha Belnades","heather_(tdi)":"Heather","suki":"Suki","raya_(ratld)":"Raya","vi_(league_of_legends)":"Vi (Arcane)","mystique":"Mystique",
"anastasia_(film)":"Anastasia","storm_(x-men)":"Tornade (Storm)","lady_amalthea":"Lady Amalthea","widowmaker":"Widowmaker","d.va":"D.Va","mercy":"Mercy",
"princess_peach_(movie)":"Peach (film Super Mario Bros.)","power_girl":"Power Girl","huntress_(dc)":"Huntress","mei_(overwatch)":"Mei","tracer":"Tracer",
"invisible_woman":"Femme invisible","emma_frost":"Emma Frost","symmetra":"Symmetra","lindsay_(tdi)":"Lindsay","pharah":"Pharah","brigitte_(overwatch_2_suit)":"Brigitte",
"scarlet_witch":"Sorcière rouge","wasp_(marvel)":"La Guêpe","black_widow_(marvel)":"Black Widow",
"fluttershy_(mlp)":"Fluttershy (Equestria Girls)","rarity_(mlp)":"Rarity (Equestria Girls)","applejack_(mlp)":"Applejack (Equestria Girls)",
"rainbow_dash_(mlp)":"Rainbow Dash (Equestria Girls)","twilight_sparkle_(mlp)":"Twilight Sparkle (Equestria Girls)","pinkie_pie_(mlp)":"Pinkie Pie (Equestria Girls)",
"princess_luna_(mlp)":"Luna (Equestria Girls)","princess_celestia_(mlp)":"Celestia (Equestria Girls)"}
INCERTAIN={("5058287",11),("5058287",35),("5058287",44),("5058287",65),("8447367",31),("88691896",11),("88691896",23),("91860172",11),("91860172",12),("91860172",17)}
EV={
"5058287":{1:"shego",2:"gwen_stacy",3:"chel",4:"helen_parr",5:"starfire",6:"raven_(dc)",7:"gogo_tomago",8:"mavis_dracula",9:"cass_hamada",10:"jessica_rabbit",
 11:"blackfire",12:"lola_bunny",13:"wonder_woman",14:"kimberly_ann_possible",15:"sergeant_calhoun",16:"rapunzel",17:"korra",18:None,19:"jane_porter",20:"barbara_gordon",
 21:"gwen_(tdi)",22:"elsa_(frozen)",23:"megara",24:"harley_quinn",25:None,26:"black_canary",27:"esmeralda",28:"supergirl",29:"daphne_blake",30:None,
 31:"mulan",32:"vanessa_doofenshmirtz",33:"lifeguard_(lilo_and_stitch)",34:"kida",35:"raven_(dc)",36:"gwen_tennyson",37:"velma_dinkley",38:"princess_jasmine",39:"marceline",40:"sara_bellum",
 41:"moana",42:None,43:"aurora_(sleeping_beauty)",44:"june_(avatar)",45:"judy_hopps",46:"dexters_mom",47:"honey_lemon",48:"flame_princess",49:"wendy_corduroy",50:"carmen_sandiego_(2019)",
 51:"april_o'neil",52:"poison_ivy",53:"pocahontas",54:"belle_(beauty_and_the_beast)",55:"asami_sato",56:"colette_tatou",57:"terra_(dc)",58:"katara",59:None,60:None,
 61:"anna_(frozen)",62:"violet_parr",63:None,64:"susan_murphy",65:"nicole_watterson",66:"clover_(totally_spies)",67:"fionna_the_human_girl",68:"sam_(totally_spies)",69:"helga_sinclair",70:"rogue_(x-men)",
 71:"tiana",72:None,73:"ember_mclain",74:None,75:"charlotte_la_bouff",76:"bridgette_(tdi)",77:"mai_(avatar)",78:"la_muerte",79:None,80:None,
 81:"supergirl",82:"courtney_(tdi)",83:"hawkgirl",84:"francine_smith",85:None,86:"loona_(helluva_boss)",87:None,88:"toph_bei_fong",89:"sam_manson",90:"dani_phantom",
 91:"marinette_dupain-cheng",92:"sally_carrera",93:"millie_(helluva_boss)",94:None,95:"flo_(cars)",96:None,97:"audrey_ramirez",98:"nani_pelekai",99:"master_tigress",100:None},
"8447367":{1:"chel",2:"helen_parr",3:"lola_bunny",4:"jessica_rabbit",5:"gwen_stacy",6:"mavis_dracula",7:"shego",8:"starfire",9:"jane_porter",10:"kimberly_ann_possible",
 11:"elsa_(frozen)",12:"princess_jasmine",13:"gogo_tomago",14:"daphne_blake",15:"raven_(dc)",16:"sara_bellum",17:"sam_manson",18:"lola_bunny",19:"asami_sato",20:"rapunzel",
 21:"megara",22:"ariel_(the_little_mermaid)",23:"korra",24:"kida",25:None,26:None,27:"esmeralda",28:"mulan",29:"moana",30:"aurora_(sleeping_beauty)",
 31:"june_(avatar)",32:"velma_dinkley",33:"belle_(beauty_and_the_beast)",34:"judy_hopps",35:"vanessa_doofenshmirtz",36:"helga_sinclair",37:"anna_(frozen)",38:"pocahontas",39:None,40:"trixie_tang",
 41:"marceline",42:None,43:None,44:"honey_lemon",45:"tiana",46:"wendy_corduroy",47:None,48:"nani_pelekai",49:"katara",50:"marinette_dupain-cheng",
 51:"sam_(totally_spies)",52:"turanga_leela",53:"colette_tatou",54:"flo_(cars)",55:"red_hot_riding_hood",56:"cinderella_(1950_film)",57:"audrey_ramirez",58:"merida",59:"tinker_bell",60:"mai_(avatar)",
 61:"ember_mclain",62:"princess_bubblegum",63:None,64:"disgust_(inside_out)",65:None,66:"marge_simpson",67:"clover_(totally_spies)",68:"rose_quartz_(steven_universe)",69:"isabela_madrigal",70:None,
 71:"toph_bei_fong",72:"roxanne_(goof_troop)",73:"snow_white_(disney)",74:"lois_griffin",75:None,76:None,77:"jazz_fenton",78:None,79:None,80:None,
 81:"alex_(totally_spies)",82:None,83:"wilma_flintstone",84:"bo_peep",85:"kitty_katswell",86:"lapis_lazuli_(steven_universe)",87:"star_butterfly",88:"mother_gothel",89:None,90:None,
 91:"jessie_(toy_story)",92:None,93:"beth_smith",94:"alice_liddell",95:None,96:None,97:"linda_flynn-fletcher",98:None,99:"frankie_foster",100:None},
"88691896":{1:"helen_parr",2:"kimberly_ann_possible",3:"jessica_rabbit",4:"black_canary",5:"chel",6:"black_cat_(marvel)",7:"shego",8:"wonder_woman",9:"raven_(dc)",10:"starfire",
 11:"blackfire",12:"cass_hamada",13:"gwen_stacy",14:"harley_quinn",15:"lola_bunny",16:"mavis_dracula",17:"sam_manson",18:"megara",19:"zatanna",20:None,
 21:"catwoman",22:"princess_jasmine",23:"june_(avatar)",24:"gwen_(tdi)",25:"korra",26:"daphne_blake",27:"barbara_gordon",28:"sara_bellum",29:"jane_porter",30:"kida",
 31:None,32:None,33:None,34:"atom_eve",35:"belle_(beauty_and_the_beast)",36:None,37:None,38:"april_o'neil",39:"asami_sato",40:"esmeralda",
 41:None,42:"elsa_(frozen)",43:"nani_pelekai",44:None,45:"jinx_(league_of_legends)",46:"carmilla_(castlevania)",47:"sypha_belnades",48:"anna_(frozen)",49:"marceline",50:"ariel_(the_little_mermaid)",
 51:"velma_dinkley",52:"katara",53:None,54:None,55:"alex_(totally_spies)",56:"sam_(totally_spies)",57:"heather_(tdi)",58:"mulan",59:"clover_(totally_spies)",60:None,
 61:"tiana",62:None,63:"suki",64:"flame_princess",65:"pocahontas",66:None,67:"raya_(ratld)",68:None,69:"tinker_bell",70:"colette_tatou",
 71:None,72:None,73:"rogue_(x-men)",74:"vi_(league_of_legends)",75:"audrey_ramirez",76:"mystique",77:None,78:None,79:"judy_hopps",80:"anastasia_(film)",
 81:None,82:None,83:None,84:None,85:"dexters_mom",86:"fionna_the_human_girl",87:"storm_(x-men)",88:"loona_(helluva_boss)",89:"princess_bubblegum",90:"lady_amalthea",
 91:None,92:"ember_mclain",93:"cinderella_(1950_film)",94:None,95:"millie_(helluva_boss)",96:"turanga_leela",97:None,98:"frankie_foster",99:None,100:None},
"91860172":{1:"chel",2:"helen_parr",3:"cass_hamada",4:"widowmaker",5:"d.va",6:"raven_(dc)",7:"mercy",8:None,9:"kimberly_ann_possible",10:"starfire",
 11:"black_canary",12:"daphne_blake",13:"jessica_rabbit",14:"shego",15:"princess_jasmine",16:None,17:"black_widow_(marvel)",18:"gogo_tomago",19:"sergeant_calhoun",20:"wonder_woman",
 21:"kida",22:"megara",23:None,24:"harley_quinn",25:"poison_ivy",26:"catwoman",27:"supergirl",28:"elsa_(frozen)",29:None,30:"zatanna",
 31:"black_cat_(marvel)",32:None,33:None,34:"princess_peach_(movie)",35:None,36:None,37:None,38:"tracer",39:None,40:"velma_dinkley",
 41:"belle_(beauty_and_the_beast)",42:None,43:"lifeguard_(lilo_and_stitch)",44:None,45:None,46:"power_girl",47:"huntress_(dc)",48:"mei_(overwatch)",49:None,50:None,
 51:"invisible_woman",52:"helga_sinclair",53:None,54:None,55:"sara_bellum",56:None,57:None,58:"symmetra",59:"tinker_bell",60:"ariel_(the_little_mermaid)",
 61:None,62:None,63:None,64:None,65:"april_o'neil",66:None,67:"rogue_(x-men)",68:"emma_frost",69:None,70:None,
 71:"lindsay_(tdi)",72:"pharah",73:None,74:None,75:None,76:None,77:None,78:None,79:"brigitte_(overwatch_2_suit)",80:"pocahontas",
 81:"tiana",82:None,83:"scarlet_witch",84:None,85:"wasp_(marvel)",86:None,87:"nani_pelekai",88:None,89:None,90:None,
 91:None,92:"courtney_(tdi)",93:None,94:None,95:None,96:"hawkgirl",97:None,98:None,99:None,100:None}}
# Personnages du top 100 rule34 cherchés dans TOUT le modèle (planches des images 1 à fin) : rang de la meilleure image
R34_DANS_MODELE={
"5058287":{"starfire":5,"raven_(dc)":6,"helen_parr":4,"gwen_stacy":2,"wonder_woman":13,"harley_quinn":24,"supergirl":28,"gwen_tennyson":36,"judy_hopps":45,"loona_(helluva_boss)":86,
 "fluttershy_(mlp)":104,"rarity_(mlp)":117,"applejack_(mlp)":128,"rainbow_dash_(mlp)":136,"twilight_sparkle_(mlp)":146,"pinkie_pie_(mlp)":179,"princess_luna_(mlp)":197,"princess_celestia_(mlp)":267},
"8447367":{"helen_parr":2,"gwen_stacy":5,"starfire":8,"raven_(dc)":15,"judy_hopps":34},
"88691896":{"helen_parr":1,"wonder_woman":8,"raven_(dc)":9,"starfire":10,"gwen_stacy":13,"harley_quinn":14,"judy_hopps":79,"loona_(helluva_boss)":88},
"91860172":{"helen_parr":2,"widowmaker":4,"d.va":5,"raven_(dc)":6,"mercy":7,"starfire":10,"wonder_woman":20,"harley_quinn":24,"supergirl":27,"tracer":38,"emma_frost":68,"pharah":72}}

# --- Ajout 24 oct. : périmètre Comics + Cartoons / films d'animation occidentaux + Furry ---
HORS.update({"mystique":1502,"rayla_(the_dragon_prince)":707})
NOMS.update({"ahsoka_tano":"Ahsoka Tano","charlie_morningstar_(hazbin_hotel)":"Charlie Morningstar","rayla_(the_dragon_prince)":"Rayla",
 "psylocke ∪ psylocke_(kwannon)":"Psylocke","sally_acorn":"Sally Acorn"})
# images 101+ identifiées pour compléter les top 100 du périmètre (hors périmètre retirés)
EV["88691896"].update({101:"ahsoka_tano",102:None,103:"charlie_morningstar_(hazbin_hotel)",104:None,105:"rayla_(the_dragon_prince)"})
EV["91860172"].update({101:None,102:None,103:"mystique",104:None,105:None,106:None,107:None,108:None,109:None,110:None})
# personnages de la liste rule34 du périmètre repérés au-delà des images déjà identifiées (parcours en miniatures)
EXTRA={"5058287":{"princess_bubblegum":101,"ahsoka_tano":130,"charlie_morningstar_(hazbin_hotel)":106,"sally_acorn":370},
       "8447367":{},"88691896":{},"91860172":{"ahsoka_tano":119,"psylocke ∪ psylocke_(kwannon)":128}}
# médium des personnages hors sélection 217 (règle : médium de création ; Raven et Starfire en cartoons à ta demande)
COMICS={"blackfire","barbara_gordon","black_canary","poison_ivy","terra_(dc)","hawkgirl","zatanna","atom_eve","mystique","storm_(x-men)",
        "scarlet_witch","wasp_(marvel)","huntress_(dc)"}
FURRY={"master_tigress","kitty_katswell","roxanne_(goof_troop)"}
JEUX={"widowmaker","d.va","mercy","tracer","mei_(overwatch)","symmetra","pharah","brigitte_(overwatch_2_suit)","princess_peach_(movie)",
      "jinx_(league_of_legends)","vi_(league_of_legends)","carmilla_(castlevania)","sypha_belnades"}

# --- Corrections du 24 oct. (remarque de l'utilisateur : June / Azula, Ty Lee) ---
# Vérifiées sur grandes vignettes : 88691896 #23 = Azula (teint pâle, yeux dorés), pas June ; June (teint mat, yeux bruns) = 5058287 #44 et 8447367 #31.
# Ty Lee (tenue de plage, chignon à ruban rouge, ras-du-cou rouge) = 5058287 #25, 8447367 #39, 88691896 #20 (non identifiée jusque-là).
HORS.update({"ty_lee":5659})
NOMS.update({"ty_lee":"Ty Lee","azula":"Azula"})
EV["88691896"].update({20:"ty_lee",23:"azula",83:"mai_(avatar)"})
EV["5058287"].update({25:"ty_lee"})
EV["8447367"].update({39:"ty_lee"})
INCERTAIN-={("88691896",23),("5058287",44),("8447367",31)}
INCERTAIN|={("88691896",83)}

# --- Ajout 24 oct. (suite) : 3 nouveaux votes envoyés par l'utilisateur ---
# 81614596 « Disney/PIXAR Waifus » (paliers S, A, B, C, D, Hard Pass), 30083716 « Hottest Cartoon Characters » (1 087 images, S-D),
# 20899730 « Hottest animated girls » (S, A, B, C, D, Ewwwwww, Who?). Classements : notebooks/analyse_live_tiermaker_v2.py
# (Hard Pass / Ewwwwww = note la plus basse ; « Who? » retiré, choix de l'utilisateur).
# Identification : noms de fichiers (81614596, 20899730, en partie 30083716) vérifiés sur planches ; 30083716 surtout visuel.
HORS.update({"mirage_(the_incredibles)":898,"ann_possible":2843,"aphrodite_(hercules)":120,"bimbettes":3,"babette":136,"candace_flynn":1233,
"shank_(wreck-it_ralph)":45,"the_muses":86,"iduna_(frozen)":85,"bonnie_rockwaller":2126,"chicha_(disney)":236,"vidia":52,"anita_radcliffe":224,
"elisa_maza":645,"silvermist":84,"queen_arianna":94,"te_fiti":5,"queen_elinor":146,"beret_girl":154,"kate_(inner_workings)":555,"giffany":202,
"jackie_lynn_thomas":2987,"evelyn_deavor":60,"hekapoo":3067,"jill_andersen":281,"sarah_hawkins":130,"periwinkle_(disney_fairies)":23,
"ellie_fredricksen":6,"princess_eilonwy":224,"honeymaren":23,"imelda_rivera":7,"maleficent":1598,"fawn_(disney_fairies)":55,"captain_amelia":1418,
"mary_darling":84,"luisa_madrigal":192,"katrina_van_tassel":54,"slue-foot_sue":110,"queen_leah":22,"franny_robinson":50,"angel_(lilo_and_stitch)":668,
"monique_(kim_possible)":495,"della_duck":138,"evil_queen_(disney)":63,"demona":974,"celia_mae":33,"daisy_duck":545,"mira_nova":300,
"gazelle_(zootopia)":1075,"vivian_porter":122,"sylvia_(wander_over_yonder)":347,"lord_dominator":2256,"blue_fairy":77,"joy_(inside_out)":832,
"eris_(sinbad)":113,"hex_girls":317,"mary_jane_watson":7587,"lucy_mann":215,"patty_peterson":13,"maria_posada":38,"keyleth":853,
"astrid_hofferson":5127,"sam_sparks":14,"kai_green":117,"miriam_(the_prince_of_egypt)":14,"julie_yamamoto":1003,"rebecca_holiday":72,
"sirena_ong":3,"izzy_(tdi)":687,"emily_(corpse_bride)":172,"holli_would":790,"musa_(winx_club)":559,"princess_yue":10,"barbie_(franchise)":822,
"jinx_(dc)":3260,"fire_(dc)":249,"melanie_walker":84,"temari":7018,"dark_magician_girl":7994,"nurse_joy":2095,"officer_jenny_(pokemon)":1493,
"cheelai":3436})
AMBIGU|={"babette","aphrodite_(hercules)","barbie_(franchise)","the_muses","bimbettes","hex_girls"}
NOMS.update({"mirage_(the_incredibles)":"Mirage (Les Indestructibles)","ann_possible":"Ann Possible","aphrodite_(hercules)":"Aphrodite (Hercule)",
"bimbettes":"Les Bimbettes (La Belle et la Bête)","babette":"Fifi / Babette, le plumeau (La Belle et la Bête)","candace_flynn":"Candace Flynn",
"shank_(wreck-it_ralph)":"Shank (Ralph 2.0)","the_muses":"Les Muses (Hercule)","iduna_(frozen)":"Reine Iduna","bonnie_rockwaller":"Bonnie Rockwaller",
"chicha_(disney)":"Chicha","vidia":"Vidia","anita_radcliffe":"Anita Radcliffe","elisa_maza":"Elisa Maza","silvermist":"Ondine (Silvermist)",
"queen_arianna":"Reine Arianna","te_fiti":"Te Fiti","queen_elinor":"Reine Elinor","beret_girl":"La fille au béret (Dingo et Max 2)",
"kate_(inner_workings)":"Kate (Inner Workings)","giffany":"Giffany","jackie_lynn_thomas":"Jackie Lynn Thomas","evelyn_deavor":"Evelyn Deavor",
"hekapoo":"Hekapoo","jill_andersen":"Mme Andersen (Vice-Versa)","sarah_hawkins":"Sarah Hawkins","periwinkle_(disney_fairies)":"Clochette Periwinkle",
"ellie_fredricksen":"Ellie Fredricksen","princess_eilonwy":"Princesse Eilonwy","honeymaren":"Honeymaren","imelda_rivera":"Imelda (Coco)",
"maleficent":"Maléfique","fawn_(disney_fairies)":"Noa (Fawn)","captain_amelia":"Capitaine Amelia","mary_darling":"Mary Darling",
"luisa_madrigal":"Luisa Madrigal","katrina_van_tassel":"Katrina Van Tassel","slue-foot_sue":"Slue Foot Sue","queen_leah":"Reine Leah",
"franny_robinson":"Franny Robinson","angel_(lilo_and_stitch)":"Angel (Lilo & Stitch)","monique_(kim_possible)":"Monique","della_duck":"Della Duck",
"evil_queen_(disney)":"La Reine (Blanche-Neige)","demona":"Demona","celia_mae":"Celia Mae","daisy_duck":"Daisy Duck","mira_nova":"Mira Nova",
"gazelle_(zootopia)":"Gazelle (Zootopie)","vivian_porter":"Vivian Porter","sylvia_(wander_over_yonder)":"Sylvia","lord_dominator":"Lord Dominator",
"blue_fairy":"La Fée bleue","joy_(inside_out)":"Joie (Vice-Versa)","eris_(sinbad)":"Éris (Sinbad)","hex_girls":"Les Hex Girls (Scooby-Doo)",
"mary_jane_watson":"Mary Jane Watson","lucy_mann":"Lucy Mann","patty_peterson":"Patty Peterson","maria_posada":"María Posada","keyleth":"Keyleth",
"astrid_hofferson":"Astrid","sam_sparks":"Sam Sparks","kai_green":"Kai Green","miriam_(the_prince_of_egypt)":"Myriam (Le Prince d'Égypte)",
"julie_yamamoto":"Julie Yamamoto","rebecca_holiday":"Rebecca Holiday","sirena_ong":"Sirena Ong","izzy_(tdi)":"Izzy","emily_(corpse_bride)":"Emily (Les Noces funèbres)",
"holli_would":"Holli Would","musa_(winx_club)":"Musa (Winx Club)","princess_yue":"Princesse Yue","barbie_(franchise)":"Barbie","jinx_(dc)":"Jinx (Teen Titans)",
"fire_(dc)":"Fire (Justice League)","melanie_walker":"Ten / Melanie Walker","temari":"Temari","dark_magician_girl":"Magicienne des ténèbres",
"nurse_joy":"Infirmière Joëlle","officer_jenny_(pokemon)":"Agent Jenny","cheelai":"Cheelai","tsunade":"Tsunade","nami_(one_piece)":"Nami",
"nico_robin":"Nico Robin","hyuuga_hinata":"Hinata Hyûga","jessie_(pokemon)":"Jessie (Team Rocket)","ino_yamanaka":"Ino Yamanaka",
"serena_(pokemon)":"Serena (Pokémon)","may_(pokemon)":"Flora (Pokémon)","rouge_the_bat":"Rouge the Bat","gardevoir":"Gardevoir"})
COMICS|={"mary_jane_watson","fire_(dc)","jinx_(dc)"}
FURRY|={"captain_amelia","angel_(lilo_and_stitch)","della_duck","daisy_duck","gazelle_(zootopia)","sylvia_(wander_over_yonder)","beret_girl"}
ANIME={"temari","dark_magician_girl","nurse_joy","officer_jenny_(pokemon)","cheelai"}  # hors périmètre (Animanga), hors sélection 217
# image identifiée mais sans tag rule34 dédié : nom affiché, exclue des calculs
SANS_TAG={("81614596",86):"Abigail Callaghan (Les Nouveaux Héros)",("81614596",96):"Sina (Vaiana)",("20899730",84):"Les sirènes (Peter Pan)"}
EV["81614596"]={1:"helen_parr",2:"megara",3:"cass_hamada",4:"shego",5:"rapunzel",6:"kimberly_ann_possible",7:"elsa_(frozen)",8:"jessica_rabbit",9:"princess_jasmine",10:"gogo_tomago",
 11:"jane_porter",12:"wendy_corduroy",13:"sergeant_calhoun",14:"kida",15:"honey_lemon",16:"belle_(beauty_and_the_beast)",17:"vanessa_doofenshmirtz",18:"esmeralda",19:"tiana",20:"mirage_(the_incredibles)",
 21:"ann_possible",22:"anna_(frozen)",23:"aphrodite_(hercules)",24:"bimbettes",25:"mulan",26:"moana",27:"aurora_(sleeping_beauty)",28:"colette_tatou",29:"ariel_(the_little_mermaid)",30:"audrey_ramirez",
 31:"babette",32:"candace_flynn",33:"nani_pelekai",34:"shank_(wreck-it_ralph)",35:"charlotte_la_bouff",36:"the_muses",37:"judy_hopps",38:"raya_(ratld)",39:"iduna_(frozen)",40:"merida",
 41:"pocahontas",42:"helga_sinclair",43:"bonnie_rockwaller",44:"chicha_(disney)",45:"vidia",46:"anita_radcliffe",47:"elisa_maza",48:"silvermist",49:"queen_arianna",50:"cinderella_(1950_film)",
 51:"te_fiti",52:"disgust_(inside_out)",53:"linda_flynn-fletcher",54:"beret_girl",55:"queen_elinor",56:"bo_peep",57:"kate_(inner_workings)",58:"roxanne_(goof_troop)",59:"jessie_(toy_story)",60:"giffany",
 61:"jackie_lynn_thomas",62:"tinker_bell",63:"evelyn_deavor",64:"hekapoo",65:"mother_gothel",66:"jill_andersen",67:"sarah_hawkins",68:"periwinkle_(disney_fairies)",69:"ellie_fredricksen",70:"star_butterfly",
 71:"princess_eilonwy",72:"honeymaren",73:"imelda_rivera",74:"maleficent",75:"fawn_(disney_fairies)",76:"alice_liddell",77:"captain_amelia",78:"mary_darling",79:"luisa_madrigal",80:"katrina_van_tassel",
 81:"snow_white_(disney)",82:"slue-foot_sue",83:"queen_leah",84:"franny_robinson",85:"angel_(lilo_and_stitch)",86:None,87:"monique_(kim_possible)",88:"della_duck",89:"evil_queen_(disney)",90:"demona",
 91:"celia_mae",92:"daisy_duck",93:"mira_nova",94:"gazelle_(zootopia)",95:"vivian_porter",96:None,97:"sylvia_(wander_over_yonder)",98:"lord_dominator",99:"blue_fairy",100:"joy_(inside_out)"}
EV["30083716"]={1:"chel",2:"helen_parr",3:"cass_hamada",4:"wonder_woman",5:"shego",6:"lola_bunny",7:"jane_porter",8:"kimberly_ann_possible",9:"cass_hamada",10:"raven_(dc)",
 11:"blackfire",12:"starfire",13:"gwen_stacy",14:"tsunade",15:"jessica_rabbit",16:"megara",17:"black_widow_(marvel)",18:"mavis_dracula",19:"zatanna",20:"princess_jasmine",
 21:"kida",22:"gogo_tomago",23:"asami_sato",24:"barbara_gordon",25:"daphne_blake",26:"harley_quinn",27:"gwen_(tdi)",28:"nami_(one_piece)",29:"poison_ivy",30:"black_cat_(marvel)",
 31:"barbara_gordon",32:"korra",33:"megara",34:"hyuuga_hinata",35:"elsa_(frozen)",36:"mulan",37:"asami_sato",38:"black_canary",39:"esmeralda",40:"azula",
 41:"rapunzel",42:"black_widow_(marvel)",43:"ty_lee",44:"hex_girls",45:"tsunade",46:"babette",47:"sara_bellum",48:None,49:"lola_bunny",50:"rogue_(x-men)",
 51:"jessie_(pokemon)",52:"fire_(dc)",53:"sergeant_calhoun",54:"atom_eve",55:"nico_robin",56:"katara",57:"bonnie_rockwaller",58:"asami_sato",59:"zatanna",60:"power_girl",
 61:"june_(avatar)",62:"barbara_gordon",63:None,64:"black_canary",65:"nami_(one_piece)",66:"esmeralda",67:"blackfire",68:"barbara_gordon",69:"tsunade",70:"supergirl",
 71:None,72:"bimbettes",73:"harley_quinn",74:"velma_dinkley",75:"storm_(x-men)",76:"suki",77:"catwoman",78:None,79:"astrid_hofferson",80:"jinx_(dc)",
 81:"helga_sinclair",82:"pocahontas",83:"mirage_(the_incredibles)",84:"belle_(beauty_and_the_beast)",85:"jessie_(pokemon)",86:"asami_sato",87:"temari",88:"gardevoir",89:"barbie_(franchise)",90:"invisible_woman",
 91:"tiana",92:"jinx_(league_of_legends)",93:"catwoman",94:"anna_(frozen)",95:"supergirl",96:"wendy_corduroy",97:"trixie_tang",98:"ino_yamanaka",99:"sam_(totally_spies)",100:"vanessa_doofenshmirtz",
 101:"tsunade",102:"fire_(dc)",103:"nurse_joy",104:"zatanna",105:"ann_possible",106:"melanie_walker",107:"judy_hopps",108:"honey_lemon",109:"dark_magician_girl",110:"rouge_the_bat",
 111:"serena_(pokemon)",112:None,113:"ariel_(the_little_mermaid)",114:None,115:"toph_bei_fong",116:"rogue_(x-men)",117:"cheelai",118:"helga_sinclair",119:None,120:"astrid_hofferson",
 121:"atom_eve",122:"moana",123:"officer_jenny_(pokemon)",124:"susan_murphy",125:"musa_(winx_club)",126:"mai_(avatar)",127:"candace_flynn",128:"aphrodite_(hercules)",129:"princess_yue",130:"anna_(frozen)",
 131:"gwen_tennyson",132:"aurora_(sleeping_beauty)",133:"turanga_leela",134:"tiana",135:"may_(pokemon)",136:"holli_would",137:"hyuuga_hinata",138:"judy_hopps",139:"courtney_(tdi)",140:"april_o'neil"}
EV["20899730"]={1:"helen_parr",2:"chel",3:"cass_hamada",4:"blackfire",5:"shego",6:"mavis_dracula",7:"megara",8:"starfire",9:"jessica_rabbit",10:"princess_jasmine",
 11:"gwen_stacy",12:"raven_(dc)",13:"gogo_tomago",14:"daphne_blake",15:"jane_porter",16:"asami_sato",17:"belle_(beauty_and_the_beast)",18:"sam_(totally_spies)",19:"kimberly_ann_possible",20:"lola_bunny",
 21:"gwen_(tdi)",22:"kida",23:"esmeralda",24:"lifeguard_(lilo_and_stitch)",25:"princess_peach_(movie)",26:"bimbettes",27:"babette",28:"aurora_(sleeping_beauty)",29:"ariel_(the_little_mermaid)",30:"rapunzel",
 31:"atom_eve",32:"elsa_(frozen)",33:"mulan",34:"tiana",35:"sergeant_calhoun",36:"april_o'neil",37:"mirage_(the_incredibles)",38:"eris_(sinbad)",39:"azula",40:"anastasia_(film)",
 41:"vanessa_doofenshmirtz",42:"ann_possible",43:"ty_lee",44:"hex_girls",45:"mary_jane_watson",46:"susan_murphy",47:"gwen_tennyson",48:"korra",49:"nani_pelekai",50:"raven_(dc)",
 51:"velma_dinkley",52:"anna_(frozen)",53:"wendy_corduroy",54:"lucy_mann",55:"clover_(totally_spies)",56:"lindsay_(tdi)",57:"honey_lemon",58:"suki",59:"charlotte_la_bouff",60:"alex_(totally_spies)",
 61:"patty_peterson",62:"maria_posada",63:"sara_bellum",64:"the_muses",65:"keyleth",66:"pocahontas",67:"moana",68:"beret_girl",69:"bridgette_(tdi)",70:"mai_(avatar)",
 71:"astrid_hofferson",72:"sam_sparks",73:"kai_green",74:"merida",75:"miriam_(the_prince_of_egypt)",76:"marceline",77:"courtney_(tdi)",78:"audrey_ramirez",79:"marinette_dupain-cheng",80:"sarah_hawkins",
 81:"colette_tatou",82:"starfire",83:"tinker_bell",84:None,85:"cinderella_(1950_film)",86:"judy_hopps",87:"julie_yamamoto",88:"la_muerte",89:"rebecca_holiday",90:"helga_sinclair",
 91:"elisa_maza",92:"sirena_ong",93:"katara",94:"heather_(tdi)",95:"flame_princess",96:"dexters_mom",97:"izzy_(tdi)",98:"ember_mclain",99:"emily_(corpse_bride)",100:"chicha_(disney)",
 101:"anita_radcliffe",102:"ahsoka_tano"}
INCERTAIN|={("30083716",23),("30083716",57),("81614596",54)}
# liste rule34 du périmètre repérée au-delà des images identifiées (20899730 et 81614596 : tous les noms de fichiers ; 30083716 : planches jusqu'au rang 400 + noms de fichiers)
EXTRA.update({"81614596":{},"30083716":{"marceline":155,"ahsoka_tano":168,"loona_(helluva_boss)":236,"princess_bubblegum":253},
              "20899730":{"nicole_watterson":132,"princess_bubblegum":158,"toph_bei_fong":201}})
R34_DANS_MODELE.update({"81614596":{},"30083716":{},"20899730":{}})
# --- Ajout 24 oct. (suite 2) : vote 80408816 « Waifu anime and cartoon » (modèle « Waifus Anime, Cartoon and Videogames », 381 images, S-D) ---
# Tous médiums. Chaque image porte le nom écrit : lecture des étiquettes (OCR + vérification sur planches), 130 premières images.
# Comptes rule34 hors sélection : autocomplétion du 24 oct. 2026 (ou valeur déjà relevée pour le vote 87784832).
HORS.update({"zero_two_(darling_in_the_franxx)":7389,"sonia_(pokemon)":7691,"nemona_(pokemon)":6584,"komi_shuuko":5781,"jirou_kyouka":2589,
             "pauline_(mario)":1349,"purah":5113,"fujiwara_chika":5604,"misa_amane":1531,"sayori_(doki_doki_literature_club)":6009,
             "mirage_(aladdin)":503,"jolyne_kujo":5302,"bayonetta_(character)":6845,"misato_katsuragi":6161,"yoko_littner":6871})
NOMS.update({"hyuuga_hinata":"Hinata Hyûga","chun-li":"Chun-Li","kitagawa_marin":"Marin Kitagawa","yorha_2b":"2B","d.va":"D.Va","miruko":"Mirko",
 "cynthia_(pokemon)":"Cynthia (Pokémon)","samus_aran":"Samus Aran","yor_briar":"Yor Forger","shihouin_yoruichi":"Yoruichi","fubuki_(one-punch_man)":"Fubuki",
 "tatsumaki":"Tatsumaki","princess_zelda":"Princesse Zelda","makima_(chainsaw_man)":"Makima","kanroji_mitsuri":"Mitsuri Kanroji","princess_rosalina":"Harmonie (Rosalina)",
 "jinx_(league_of_legends)":"Jinx (League of Legends)","cammy_white":"Cammy White","momo_yaoyorozu":"Momo Yaoyorozu","mercy":"Mercy","power_(chainsaw_man)":"Power",
 "android_18":"C-18","kochou_shinobu":"Shinobu Kochô","princess_peach":"Princesse Peach","himiko_toga":"Himiko Toga","lara_croft":"Lara Croft",
 "zero_two_(darling_in_the_franxx)":"Zero Two","sonia_(pokemon)":"Sonia (Pokémon)","tifa_lockhart":"Tifa Lockhart","hilda_(pokemon)":"Hilda (Pokémon)",
 "higashiyama_kobeni":"Kobeni","mikasa_ackerman":"Mikasa Ackerman","widowmaker":"Widowmaker","ochako_uraraka":"Ochako Uraraka","ada_wong":"Ada Wong",
 "matoi_ryuuko":"Ryûko Matoi","bayonetta_(character)":"Bayonetta","hayase_nagatoro":"Hayase Nagatoro","darkness_(konosuba)":"Darkness","bulma_briefs":"Bulma",
 "tracer":"Tracer","komi_shouko":"Shôko Komi","misato_katsuragi":"Misato Katsuragi","rosa_(pokemon)":"Rosa (Pokémon)","nessa_(pokemon)":"Nessa (Pokémon)",
 "aqua_(konosuba)":"Aqua","rebecca_(edgerunners)":"Rebecca (Edgerunners)","kasumi_(pokemon)":"Ondine (Misty)","toph_bei_fong":"Toph","princess_daisy":"Princesse Daisy",
 "inoue_orihime":"Orihime Inoue","alcina_dimitrescu":"Alcina Dimitrescu","mai_shiranui":"Mai Shiranui","monika_(doki_doki_literature_club)":"Monika (DDLC)",
 "nemona_(pokemon)":"Nemona (Pokémon)","komi_shuuko":"Shûko Komi (mère de Komi)","jirou_kyouka":"Kyôka Jirô","kamado_nezuko":"Nezuko","lucy_heartfilia":"Lucy Heartfilia",
 "jill_valentine":"Jill Valentine","palutena":"Palutena","yuri_(doki_doki_literature_club)":"Yuri (DDLC)","tsuyu_asui":"Tsuyu Asui","erza_scarlet":"Erza Scarlet",
 "mina_ashido":"Mina Ashido","dawn_(pokemon)":"Aurore (Dawn)","ahri":"Ahri","tohsaka_rin":"Rin Tôsaka","sakura_haruno":"Sakura Haruno","pauline_(mario)":"Pauline (Mario)",
 "megumin":"Megumin","ashley_graham":"Ashley Graham","yoko_littner":"Yoko Littner","purah":"Purah","mei_(overwatch)":"Mei (Overwatch)",
 "asuka_langley_sohryu":"Asuka Langley","fujiwara_chika":"Chika Fujiwara","violet_parr":"Violette Parr","natsuki_(doki_doki_literature_club)":"Natsuki (DDLC)",
 "misa_amane":"Misa Amane","marnie_(pokemon)":"Rosemary (Marnie)","sayori_(doki_doki_literature_club)":"Sayori (DDLC)","supergirl":"Supergirl",
 "stocking_anarchy":"Stocking Anarchy","rei_ayanami":"Rei Ayanami","mirage_(aladdin)":"Mirage (Aladdin)","jolyne_kujo":"Jolyne Kujo"})
NOMS.setdefault("marinette_dupain-cheng","Marinette Dupain-Cheng"); NOMS.setdefault("marceline","Marceline"); NOMS.setdefault("gwen_tennyson","Gwen Tennyson")
ANIME|={"zero_two_(darling_in_the_franxx)","komi_shuuko","jirou_kyouka","fujiwara_chika","misa_amane","jolyne_kujo","misato_katsuragi","yoko_littner"}
JEUX|={"sonia_(pokemon)","nemona_(pokemon)","pauline_(mario)","purah","sayori_(doki_doki_literature_club)","bayonetta_(character)"}
EV["80408816"]={1:"raven_(dc)",2:"hyuuga_hinata",3:"starfire",4:"chun-li",5:"kitagawa_marin",6:"yorha_2b",7:"d.va",8:"miruko",9:"cynthia_(pokemon)",10:"tsunade",
 11:"samus_aran",12:"yor_briar",13:"gwen_stacy",14:"nami_(one_piece)",15:"shihouin_yoruichi",16:"fubuki_(one-punch_man)",17:"tatsumaki",18:"princess_zelda",19:"makima_(chainsaw_man)",20:"kanroji_mitsuri",
 21:"princess_rosalina",22:"mavis_dracula",23:"jinx_(league_of_legends)",24:"cammy_white",25:"helen_parr",26:"momo_yaoyorozu",27:"mercy",28:"harley_quinn",29:"power_(chainsaw_man)",30:"android_18",
 31:"kochou_shinobu",32:"princess_peach",33:"himiko_toga",34:"lara_croft",35:"shego",36:"nico_robin",37:"wonder_woman",38:"ino_yamanaka",39:"ty_lee",40:"zero_two_(darling_in_the_franxx)",
 41:"chel",42:"sonia_(pokemon)",43:"tifa_lockhart",44:"hilda_(pokemon)",45:"azula",46:"higashiyama_kobeni",47:"jessica_rabbit",48:"mikasa_ackerman",49:"wendy_corduroy",50:"widowmaker",
 51:"daphne_blake",52:"ochako_uraraka",53:"kimberly_ann_possible",54:"ada_wong",55:"gwen_(tdi)",56:"matoi_ryuuko",57:"bayonetta_(character)",58:"hayase_nagatoro",59:"darkness_(konosuba)",60:"bulma_briefs",
 61:"tracer",62:"cass_hamada",63:"komi_shouko",64:"misato_katsuragi",65:"rosa_(pokemon)",66:"nessa_(pokemon)",67:"aqua_(konosuba)",68:"rebecca_(edgerunners)",69:"kasumi_(pokemon)",70:"toph_bei_fong",
 71:"lola_bunny",72:"jessie_(pokemon)",73:"korra",74:"vanessa_doofenshmirtz",75:"princess_daisy",76:"inoue_orihime",77:"alcina_dimitrescu",78:"mai_shiranui",79:"monika_(doki_doki_literature_club)",80:"nemona_(pokemon)",
 81:"belle_(beauty_and_the_beast)",82:"poison_ivy",83:"komi_shuuko",84:"jirou_kyouka",85:"rapunzel",86:"velma_dinkley",87:"kamado_nezuko",88:"lucy_heartfilia",89:"katara",90:"jill_valentine",
 91:"palutena",92:"gogo_tomago",93:"jane_porter",94:"yuri_(doki_doki_literature_club)",95:"tsuyu_asui",96:"erza_scarlet",97:"mina_ashido",98:"dawn_(pokemon)",99:"may_(pokemon)",100:"ahri",
 101:"mulan",102:"tohsaka_rin",103:"sakura_haruno",104:"pauline_(mario)",105:"megumin",106:"jinx_(dc)",107:"ashley_graham",108:"yoko_littner",109:"purah",110:"mei_(overwatch)",
 111:"elsa_(frozen)",112:"asuka_langley_sohryu",113:"fujiwara_chika",114:"violet_parr",115:"natsuki_(doki_doki_literature_club)",116:"misa_amane",117:"marnie_(pokemon)",118:"sayori_(doki_doki_literature_club)",119:"marceline",120:"marinette_dupain-cheng",
 121:"supergirl",122:"stocking_anarchy",123:"ann_possible",124:"rei_ayanami",125:"suki",126:"april_o'neil",127:"gwen_tennyson",128:"mirage_(aladdin)",129:"kida",130:"jolyne_kujo"}
EXTRA["80408816"]={}; R34_DANS_MODELE["80408816"]={}
# 80408816, images 131+ : seules les images du périmètre Comics + Cartoons + Furry sont listées (étiquettes lues sur planches) ;
# une image absente du dictionnaire au-delà de 130 = personnage d'animanga ou de jeu vidéo (hors périmètre), donc ignorée.
# None = étiquette lue mais personnage non rattaché avec certitude (« Ruby » 193, « Kaisa » 225, « Maya » 247, « Cleopatra » 255, « Johanna » 274).
HORS.update({"leni_loud":2514,"bloom_(winx_club)":1340,"vicky_(fairly_odd_parents)":2114,"miss_heed_(villainous)":1172,"madeline_fenton":3690,
             "peni_parker":3306,"jessica_cruz":858,"lori_loud":2685,"other_mother":717,"mabel_pines":3956,"princess_fiona":1081,"desiree":1061,
             "lois_lane":2939,"pacifica_northwest":4647,"huntress_wizard":1667,"kendall_perkins":154,"dolores_madrigal":369,"lucy_loud":1299,
             "demencia_(villainous)":848,"luan_loud":929,"bumblebee_(dc)":500,"jenny_wakeman":6893,"marcy_wu":2066,"luna_loud":1240,"amity_blight":6410})
AMBIGU|={"desiree","princess_fiona"}
NOMS.update({"leni_loud":"Leni Loud","bloom_(winx_club)":"Bloom (Winx Club)","vicky_(fairly_odd_parents)":"Vicky (Mes parrains sont magiques)",
 "miss_heed_(villainous)":"Miss Heed (Villainous)","madeline_fenton":"Maddie Fenton","peni_parker":"Peni Parker","jessica_cruz":"Jessica Cruz (Green Lantern)",
 "lori_loud":"Lori Loud","other_mother":"L'Autre Mère (Coraline)","mabel_pines":"Mabel Pines","princess_fiona":"Princesse Fiona","desiree":"Desiree (Danny Phantom)",
 "lois_lane":"Lois Lane","pacifica_northwest":"Pacifica Northwest","huntress_wizard":"Huntress Wizard","kendall_perkins":"Kendall Perkins",
 "dolores_madrigal":"Dolores Madrigal","lucy_loud":"Lucy Loud","demencia_(villainous)":"Démencia (Villainous)","luan_loud":"Luan Loud",
 "bumblebee_(dc)":"Bumblebee (DC)","jenny_wakeman":"Jenny Wakeman (XJ-9)","marcy_wu":"Marcy Wu","luna_loud":"Luna Loud","amity_blight":"Amity Blight",
 "barbara_gordon":NOMS.get("barbara_gordon","Barbara Gordon / Batgirl")})
COMICS|={"peni_parker","jessica_cruz","lois_lane","bumblebee_(dc)"}
EV["80408816"].update({135:"gardevoir",136:"lifeguard_(lilo_and_stitch)",138:"princess_bubblegum",139:"princess_jasmine",140:"megara",143:"lopunny",
 144:"ariel_(the_little_mermaid)",145:"sam_(totally_spies)",146:"ankha",149:"ahsoka_tano",150:"asami_sato",152:"courtney_(tdi)",154:"honey_lemon",
 157:"anna_(frozen)",158:"astrid_hofferson",159:"leni_loud",161:"clover_(totally_spies)",163:"aurora_(sleeping_beauty)",166:"lindsay_(tdi)",167:"sam_manson",
 168:"nani_pelekai",171:"jackie_lynn_thomas",172:"rouge_the_bat",173:"barbara_gordon",174:"dexters_mom",176:"moana",177:"esmeralda",178:"bloom_(winx_club)",
 180:"fionna_the_human_girl",184:"nicole_watterson",187:"vicky_(fairly_odd_parents)",189:"miss_heed_(villainous)",191:"alex_(totally_spies)",192:"ember_mclain",
 193:None,194:"fluttershy_(mlp)",195:"madeline_fenton",196:"zatanna",198:"heather_(tdi)",199:"peni_parker",200:"jessica_cruz",201:"trixie_tang",
 204:"judy_hopps",207:"isabela_madrigal",208:"pinkie_pie_(mlp)",209:"millie_(helluva_boss)",210:"mai_(avatar)",211:"amy_rose",212:"lori_loud",213:"tiana",
 214:"other_mother",215:"sergeant_calhoun",216:"mabel_pines",219:"charlie_morningstar_(hazbin_hotel)",220:"audrey_ramirez",221:"hekapoo",222:"princess_fiona",
 223:"tinker_bell",225:None,227:"rarity_(mlp)",228:"desiree",229:"snow_white_(disney)",230:"jazz_fenton",233:"lois_lane",234:"pacifica_northwest",
 235:"wasp_(marvel)",237:"frankie_foster",238:"blaze_the_cat",240:"applejack_(mlp)",241:"star_butterfly",242:"twilight_sparkle_(mlp)",243:"pocahontas",
 244:"huntress_wizard",246:"kendall_perkins",247:None,249:"disgust_(inside_out)",250:"dolores_madrigal",253:"lucy_loud",254:"demencia_(villainous)",255:None,
 256:"cinderella_(1950_film)",258:"rainbow_dash_(mlp)",260:"toriel",262:"maleficent",263:"luan_loud",264:"bumblebee_(dc)",265:"jenny_wakeman",267:"marcy_wu",
 268:"lapis_lazuli_(steven_universe)",270:"luna_loud",271:"amity_blight",272:"bo_peep",273:"isabelle_(animal_crossing)",274:None})
NOMS.update({"lopunny":"Lockpin (Lopunny)","ankha":"Ankha","amy_rose":"Amy Rose","blaze_the_cat":"Blaze the Cat","toriel":"Toriel","isabelle_(animal_crossing)":"Marie (Isabelle)"})
EXTRA["80408816"]={"vanilla_the_rabbit":281,"cream_the_rabbit":295,"renamon":298,"princess_luna_(mlp)":310,"princess_celestia_(mlp)":325}  # liste r34 du périmètre au-delà du rang 274 (planches 275-381)
# --- Ajout 24 oct. (suite 3) : vote 30081640 « Biggest Waifu List » (modèle « The Anime Waifu Tier List », 2 050 images, S-D) ---
# Modèle annoncé anime/manga (contient aussi quelques personnages de jeux vidéo : 2B, A2, Tifa, Aerith, Bayonetta, Mitsuru, Cynthia...).
# Identification : nom de fichier + étiquette « personnage / série » écrite sur l'image, vérifiées sur planches (top 100).
# Attention : 3 530 participants pour 2 050 images -> peu de votants par image (médiane 26 sur tout le modèle, 18 à 1 094 dans le top 100).
HORS.update({"esdeath_(akame_ga_kill!)":5424,"sakurajima_mai":2254,"lucyna_kushinada":5808,"mount_lady":4909,"mitsuru_kirijo":4514,
 "nakano_miku":5513,"bambietta_basterbine":2697,"nakano_nino":7308,"midnight_(my_hero_academia)":4749,"kakure_meme":211,"nelliel_tu_odelschwanck":3499,
 "kurotsuchi_nemu":1361,"alisa_mikhailovna_kujou":5169,"witch_(goblin_slayer)":211,"lady_nagant":2939,"vermeil_(kinsou_no_vermeil)":860,
 "akame_(akame_ga_kill!)":1427,"camie_utsushimi":3228,"zenin_maki":7304,"yuki_tsukumo":1996,"unohana_retsu":5260,"princess_hibana":1582,
 "tia_harribel":4722,"yunyun_(konosuba)":2907,"sui-feng":4644,"leone_(akame_ga_kill!)":665,"uzaki_tsuki":6894,"aizawa_tomo":1562,
 "violet_evergarden_(character)":889,"nana_shimura":861,"mirajane_strauss":4851,"ishtar_(fate)":4386,"ayase_seiko":5084,"hyuuga_hanabi":6338,
 "hadou_nejire":2988,"izumo_tenka":534,"wiz_(konosuba)":3915,"c.c.":4327,"tokisaki_kurumi":3446,"jeanne_d'arc_(fate)":4579,"ghislaine_dedoldia":5698,
 "nanakusa_nazuna":1365,"revy_(black_lagoon)":637,"echidna_(re:zero)":2127,"uta_(one_piece)":1940,"nakano_itsuki":3197,"yorha_a2":2954,
 "ereshkigal_(fate)":1477,"hoshino_ai":2401,"elinalise_dragonroad":1066,"hinatsuru_(kimetsu_no_yaiba)":667,"juvia_lockser":4702})
# variantes de tag non fusionnées (autocomplétion du 24 oct.)
VARIANTES_EV={"camie_utsushimi":"utsushimi_camie (753)","zenin_maki":"maki_zenin (2 035)","yuki_tsukumo":"tsukumo_yuki_(jujutsu_kaisen) (314)",
 "princess_hibana":"hibana_(fire_force) (439)","tia_harribel":"tier_harribel (1 605)","sui-feng":"soifon (4 575)","nana_shimura":"shimura_nana (247)",
 "hyuuga_hanabi":"hanabi_hyuuga (843)","kurotsuchi_nemu":"nemu_kurotsuchi (198)","ishtar_(fate)":"ishtar_(fate/grand_order) (949)",
 "jeanne_d'arc_(fate)":"jeanne_d'arc_(fate)_(all) (1 865)"}
NOMS.update({"miruko":"Mirko (Rumi Usagiyama)","esdeath_(akame_ga_kill!)":"Esdeath","reze_(chainsaw_man)":"Reze","albedo_(overlord)":"Albedo",
 "matsumoto_rangiku":"Rangiku Matsumoto","nakano_miku":"Miku Nakano","rias_gremory":"Rias Gremory","frieren":"Frieren","boa_hancock":"Boa Hancock",
 "bambietta_basterbine":"Bambietta Basterbine","sakurajima_mai":"Mai Sakurajima","nakano_nino":"Nino Nakano","rem_(re:zero)":"Rem","akeno_himejima":"Akeno Himejima",
 "kuchiki_rukia":"Rukia Kuchiki","lucyna_kushinada":"Lucy (Edgerunners)","midnight_(my_hero_academia)":"Midnight","kakure_meme":"Meme Kakure",
 "nelliel_tu_odelschwanck":"Nelliel","kurotsuchi_nemu":"Nemu Kurotsuchi","artoria_pendragon":"Saber (Artoria)","alisa_mikhailovna_kujou":"Alya (Roshidere)",
 "yamato_(one_piece)":"Yamato","aerith_gainsborough":"Aerith","witch_(goblin_slayer)":"La Sorcière (Goblin Slayer)","lady_nagant":"Lady Nagant",
 "vermeil_(kinsou_no_vermeil)":"Vermeil","akame_(akame_ga_kill!)":"Akame","camie_utsushimi":"Camie Utsushimi","zenin_maki":"Maki Zen'in",
 "yuki_tsukumo":"Yuki Tsukumo","unohana_retsu":"Retsu Unohana","princess_hibana":"Princesse Hibana","tia_harribel":"Tier Harribel",
 "yunyun_(konosuba)":"Yunyun","sui-feng":"Soi Fon","leone_(akame_ga_kill!)":"Leone","uzaki_tsuki":"Tsuki Uzaki","aizawa_tomo":"Tomo Aizawa",
 "mitsuru_kirijo":"Mitsuru Kirijo","fern_(sousou_no_frieren)":"Fern","violet_evergarden_(character)":"Violet Evergarden","nana_shimura":"Nana Shimura",
 "mount_lady":"Mt. Lady","mirajane_strauss":"Mirajane Strauss","emilia_(re:zero)":"Emilia","ishtar_(fate)":"Ishtar (Fate)","ayase_seiko":"Seiko Ayase",
 "hyuuga_hanabi":"Hanabi Hyûga","hadou_nejire":"Nejire Hadô","izumo_tenka":"Tenka Izumo","yuuki_asuna":"Asuna (SAO)","wiz_(konosuba)":"Wiz","c.c.":"C.C.",
 "tokisaki_kurumi":"Kurumi Tokisaki","jeanne_d'arc_(fate)":"Jeanne d'Arc (Fate)","ghislaine_dedoldia":"Ghislaine Dedoldia","nanakusa_nazuna":"Nazuna Nanakusa",
 "revy_(black_lagoon)":"Revy","echidna_(re:zero)":"Echidna","uta_(one_piece)":"Uta","nakano_itsuki":"Itsuki Nakano","yorha_a2":"A2",
 "ereshkigal_(fate)":"Ereshkigal","hoshino_ai":"Ai Hoshino","elinalise_dragonroad":"Elinalise Dragonroad","hinatsuru_(kimetsu_no_yaiba)":"Hinatsuru",
 "juvia_lockser":"Juvia Lockser","android_18":"C-18"})
ANIME|={"esdeath_(akame_ga_kill!)","sakurajima_mai","lucyna_kushinada","mount_lady","nakano_miku","bambietta_basterbine","nakano_nino",
 "midnight_(my_hero_academia)","kakure_meme","nelliel_tu_odelschwanck","kurotsuchi_nemu","alisa_mikhailovna_kujou","witch_(goblin_slayer)","lady_nagant",
 "vermeil_(kinsou_no_vermeil)","akame_(akame_ga_kill!)","camie_utsushimi","zenin_maki","yuki_tsukumo","unohana_retsu","princess_hibana","tia_harribel",
 "yunyun_(konosuba)","sui-feng","leone_(akame_ga_kill!)","uzaki_tsuki","aizawa_tomo","violet_evergarden_(character)","nana_shimura","mirajane_strauss",
 "ayase_seiko","hyuuga_hanabi","hadou_nejire","izumo_tenka","wiz_(konosuba)","c.c.","tokisaki_kurumi","jeanne_d'arc_(fate)","ghislaine_dedoldia",
 "nanakusa_nazuna","revy_(black_lagoon)","echidna_(re:zero)","uta_(one_piece)","nakano_itsuki","hoshino_ai","elinalise_dragonroad",
 "hinatsuru_(kimetsu_no_yaiba)","juvia_lockser"}
JEUX|={"mitsuru_kirijo","yorha_a2","ishtar_(fate)","ereshkigal_(fate)"}
# Rin Kokonoe (Kodomo no Jikan, n° 92) : personnage enfant -> aucun compte Rule34 relevé ni affiché.
SANS_TAG[("30081640",92)]="Rin Kokonoe (Kodomo no Jikan)"
SANS_R34_ENFANT={("30081640",92)}
EV["30081640"]={1:"shihouin_yoruichi",2:"miruko",3:"yor_briar",4:"yorha_2b",5:"esdeath_(akame_ga_kill!)",6:"cynthia_(pokemon)",7:"reze_(chainsaw_man)",8:"albedo_(overlord)",9:"matsumoto_rangiku",10:"kitagawa_marin",
 11:"nakano_miku",12:"rias_gremory",13:"inoue_orihime",14:"nico_robin",15:"tifa_lockhart",16:"frieren",17:"erza_scarlet",18:"boa_hancock",19:"nami_(one_piece)",20:"fubuki_(one-punch_man)",
 21:"bambietta_basterbine",22:"sakurajima_mai",23:"tsunade",24:"hyuuga_hinata",25:"nakano_nino",26:"kanroji_mitsuri",27:"rem_(re:zero)",28:"makima_(chainsaw_man)",29:"akeno_himejima",30:"darkness_(konosuba)",
 31:"kuchiki_rukia",32:"lucyna_kushinada",33:"midnight_(my_hero_academia)",34:"kakure_meme",35:"nelliel_tu_odelschwanck",36:"kurotsuchi_nemu",37:"artoria_pendragon",38:"alisa_mikhailovna_kujou",39:"yamato_(one_piece)",40:"aerith_gainsborough",
 41:"witch_(goblin_slayer)",42:"lady_nagant",43:"vermeil_(kinsou_no_vermeil)",44:"akame_(akame_ga_kill!)",45:"camie_utsushimi",46:"tohsaka_rin",47:"zenin_maki",48:"yuki_tsukumo",49:"unohana_retsu",50:"bayonetta_(character)",
 51:"princess_hibana",52:"kochou_shinobu",53:"tatsumaki",54:"tia_harribel",55:"yunyun_(konosuba)",56:"power_(chainsaw_man)",57:"sui-feng",58:"zero_two_(darling_in_the_franxx)",59:"leone_(akame_ga_kill!)",60:"uzaki_tsuki",
 61:"aizawa_tomo",62:"asuka_langley_sohryu",63:"mitsuru_kirijo",64:"fern_(sousou_no_frieren)",65:"violet_evergarden_(character)",66:"nana_shimura",67:"mount_lady",68:"aqua_(konosuba)",69:"mirajane_strauss",70:"emilia_(re:zero)",
 71:"ishtar_(fate)",72:"ayase_seiko",73:"hyuuga_hanabi",74:"hadou_nejire",75:"izumo_tenka",76:"yuuki_asuna",77:"mikasa_ackerman",78:"wiz_(konosuba)",79:"c.c.",80:"tokisaki_kurumi",
 81:"komi_shouko",82:"jeanne_d'arc_(fate)",83:"ghislaine_dedoldia",84:"himiko_toga",85:"may_(pokemon)",86:"nanakusa_nazuna",87:"revy_(black_lagoon)",88:"echidna_(re:zero)",89:"uta_(one_piece)",90:"nakano_itsuki",
 91:"yorha_a2",92:None,93:"momo_yaoyorozu",94:"ereshkigal_(fate)",95:"hoshino_ai",96:"bulma_briefs",97:"elinalise_dragonroad",98:"hinatsuru_(kimetsu_no_yaiba)",99:"juvia_lockser",100:"android_18"}
EXTRA["30081640"]={}; R34_DANS_MODELE["30081640"]={}
ANIME_SEUL={"30081640"}  # vote sans personnage du périmètre Comics + Cartoons + Furry : exclu de la comparaison périmètre
# --- Ajout 24 oct. (suite 4) : vote 436045 « Cartoon Hotties » (modèle « Ranking Baddies 2.0 », 295 images, S-D ; vote encore ouvert, relevé du 24 oct. 2026) ---
# Malgré le titre, le modèle mêle cartoons, comics et beaucoup d'anime. Identification : noms de fichiers vérifiés sur planches (rangs 1 à 175).
# Rangs 1-100 : tout est rattaché. Rangs 101-175 : seules les images du périmètre Comics + Cartoons + Furry (une image absente = anime, hors périmètre).
HORS.update({"madelyne_pryor":477,"carol_danvers":2767,"talia_al_ghul":460,"viper_(marvel)":42,"mockingbird_(marvel_comics)":93,"star_sapphire_(dc)":312,
 "anissa_(invincible)":349,"enchantress_(amora)":242,"ellen_yin":56,"giganta":595,"jean_grey":4029,"charmcaster":928,"maria_hill":286,"wilhamena":1379,
 "karen_plankton":462,"superwoman":732,"shrinking_rae":322,"vixen_(dc)":717,"debbie_grayson":1537,"paulina_sanchez":999,"duplikate":3,"eve_(wall-e)":343,
 "vicki_vale":70,"adora":2605,"susan_test":519,"amy_wong":1537,"ashi_(samurai_jack)":465,"lilith_morningstar_(hazbin_hotel)":1244,
 "verosika_mayday_(helluva_boss)":4075,"teela":439,"carmilla_carmine":1251,"catra":2794,"dragon_(shrek)":426,"cheetah_(dc)":658,"lute_(hazbin_hotel)":2562,
 "garnet_(steven_universe)":2658,"amethyst_(steven_universe)":3140,"kyoshi":125,"mei_hatsume":2194,"mari_illustrious_makinami":1831,"nefertari_vivi":4497,
 "mei_terumi":3761,"kochou_kanae":797,"daki_(kimetsu_no_yaiba)":2356,"jessica_(rick_and_morty)":818,"jubilee":2983})
VARIANTES_EV.update({"madelyne_pryor":"goblin_queen_(x-men) (393)","carol_danvers":"captain_marvel (2 019, générique)","mockingbird_(marvel_comics)":"bobbi_morse (76)",
 "anissa_(invincible)":"anissa (1 561)","mei_hatsume":"hatsume_mei (755)","mei_terumi":"terumi_mei (1 634)","verosika_mayday_(helluva_boss)":"verosika_mayday (775)",
 "enchantress_(amora)":"enchantress (61)","viper_(marvel)":"madame_hydra (74)"})
AMBIGU|={"adora","kyoshi","superwoman"}
NOMS.update({"madelyne_pryor":"Goblin Queen (Madelyne Pryor)","carol_danvers":"Captain Marvel (Carol Danvers)","talia_al_ghul":"Talia al Ghul","viper_(marvel)":"Viper (Marvel)",
 "mockingbird_(marvel_comics)":"Mockingbird","star_sapphire_(dc)":"Star Sapphire","anissa_(invincible)":"Anissa (Invincible)","enchantress_(amora)":"L'Enchanteresse (Amora)",
 "ellen_yin":"Ellen Yin","giganta":"Giganta","jean_grey":"Jean Grey","charmcaster":"Charmcaster","maria_hill":"Maria Hill","wilhamena":"Wilhamena",
 "karen_plankton":"Karen Plankton","superwoman":"Superwoman","shrinking_rae":"Shrinking Rae","vixen_(dc)":"Vixen","debbie_grayson":"Debbie Grayson",
 "paulina_sanchez":"Paulina (Danny Phantom)","duplikate":"Duplikate","eve_(wall-e)":"EVE (WALL-E)","vicki_vale":"Vicki Vale","adora":"Adora (She-Ra)",
 "susan_test":"Susan et Mary Test","amy_wong":"Amy Wong","ashi_(samurai_jack)":"Ashi","lilith_morningstar_(hazbin_hotel)":"Lilith (Hazbin Hotel)",
 "verosika_mayday_(helluva_boss)":"Verosika Mayday","teela":"Teela","carmilla_carmine":"Carmilla Carmine","catra":"Catra","dragon_(shrek)":"Dragonne (Shrek)",
 "cheetah_(dc)":"Cheetah","lute_(hazbin_hotel)":"Lute","garnet_(steven_universe)":"Garnet","amethyst_(steven_universe)":"Améthyste","kyoshi":"Avatar Kyoshi",
 "mei_hatsume":"Mei Hatsume","mari_illustrious_makinami":"Mari Makinami","nefertari_vivi":"Vivi","mei_terumi":"Mei Terumî","kochou_kanae":"Kanae Kochô",
 "daki_(kimetsu_no_yaiba)":"Daki","jessica_(rick_and_morty)":"Jessica (Rick et Morty)","jubilee":"Jubilee","chichi":"Chichi","carol_danvers":"Captain Marvel (Carol Danvers)"})
for _t,_n in {"huntress_(dc)":"Huntress","hawkgirl":"Hawkgirl","terra_(dc)":"Terra","storm_(x-men)":"Tornade (Storm)","catwoman":"Catwoman","rogue_(x-men)":"Malicia (Rogue)",
 "black_widow_(marvel)":"Black Widow","black_cat_(marvel)":"Black Cat","atom_eve":"Atom Eve","poison_ivy":"Poison Ivy","wasp_(marvel)":"La Guêpe (Wasp)",
 "temari":"Temari","lois_lane":"Lois Lane"}.items(): NOMS.setdefault(_t,_n)
COMICS|={"madelyne_pryor","carol_danvers","talia_al_ghul","viper_(marvel)","mockingbird_(marvel_comics)","star_sapphire_(dc)","anissa_(invincible)",
 "enchantress_(amora)","giganta","jean_grey","maria_hill","superwoman","shrinking_rae","vixen_(dc)","debbie_grayson","duplikate","vicki_vale","jubilee","cheetah_(dc)"}
FURRY|={"catra","dragon_(shrek)"}
ANIME|={"daki_(kimetsu_no_yaiba)","mei_hatsume","mari_illustrious_makinami","nefertari_vivi","mei_terumi","kochou_kanae"}
SANS_TAG[("436045",18)]="Makio, Suma et Hinatsuru (Demon Slayer, image de groupe)"
SANS_TAG[("436045",116)]="Cleopatra (Clone High)"
SANS_TAG_MEDIUM={("436045",18):"Animanga"}  # sinon Cartoons
INCERTAIN|={("436045",116),("436045",74),("436045",107)}
EV["436045"]={1:"chel",2:"helen_parr",3:"jessica_rabbit",4:"raven_(dc)",5:"black_canary",6:"shego",7:"starfire",8:"cass_hamada",9:"wonder_woman",10:"nami_(one_piece)",
 11:"tsunade",12:"lola_bunny",13:"korra",14:"madelyne_pryor",15:"daphne_blake",16:"mount_lady",17:"fubuki_(one-punch_man)",18:None,19:"black_widow_(marvel)",20:"nico_robin",
 21:"gogo_tomago",22:"lifeguard_(lilo_and_stitch)",23:"atom_eve",24:"harley_quinn",25:"black_cat_(marvel)",26:"kimberly_ann_possible",27:"blackfire",28:"boa_hancock",29:"midnight_(my_hero_academia)",30:"miruko",
 31:"rogue_(x-men)",32:"carol_danvers",33:"barbara_gordon",34:"talia_al_ghul",35:"zatanna",36:"android_18",37:"supergirl",38:"gwen_(tdi)",39:"asami_sato",40:"sara_bellum",
 41:"hyuuga_hinata",42:"viper_(marvel)",43:"catwoman",44:"momo_yaoyorozu",45:"april_o'neil",46:"kanroji_mitsuri",47:"huntress_(dc)",48:"ochako_uraraka",49:"mikasa_ackerman",50:"velma_dinkley",
 51:"ino_yamanaka",52:"azula",53:"daki_(kimetsu_no_yaiba)",54:"tatsumaki",55:"misato_katsuragi",56:"lady_nagant",57:"poison_ivy",58:"asuka_langley_sohryu",59:"bulma_briefs",60:"mockingbird_(marvel_comics)",
 61:"rei_ayanami",62:"star_sapphire_(dc)",63:"astrid_hofferson",64:"mei_hatsume",65:"mari_illustrious_makinami",66:"nefertari_vivi",67:"hadou_nejire",68:"wendy_corduroy",69:"anissa_(invincible)",70:"vanessa_doofenshmirtz",
 71:"mei_terumi",72:"enchantress_(amora)",73:"kochou_shinobu",74:"ellen_yin",75:"nani_pelekai",76:"lindsay_(tdi)",77:"terra_(dc)",78:"temari",79:"himiko_toga",80:"gwen_tennyson",
 81:"kochou_kanae",82:"hawkgirl",83:"mirage_(the_incredibles)",84:"bridgette_(tdi)",85:"ty_lee",86:"giganta",87:"jean_grey",88:"nana_shimura",89:"gwen_stacy",90:"tsuyu_asui",
 91:"mina_ashido",92:"marceline",93:"wasp_(marvel)",94:"storm_(x-men)",95:"nicole_watterson",96:"hex_girls",97:"chichi",98:"fire_(dc)",99:"tinker_bell",100:"charmcaster",
 101:"courtney_(tdi)",102:"izzy_(tdi)",104:"heather_(tdi)",105:"maria_hill",106:"lois_lane",107:"wilhamena",109:"jinx_(dc)",110:"honey_lemon",111:"karen_plankton",112:"miss_heed_(villainous)",
 114:"superwoman",115:"shrinking_rae",116:None,117:"desiree",118:"vixen_(dc)",120:"mai_(avatar)",121:"debbie_grayson",122:"turanga_leela",123:"flame_princess",125:"paulina_sanchez",
 126:"katara",127:"fionna_the_human_girl",128:"duplikate",129:"mary_jane_watson",130:"eve_(wall-e)",132:"vicki_vale",133:"adora",135:"sam_manson",136:"loona_(helluva_boss)",138:"jazz_fenton",
 140:"jessica_(rick_and_morty)",141:"sally_carrera",142:"susan_test",143:"amy_wong",144:"princess_bubblegum",145:"madeline_fenton",146:"ashi_(samurai_jack)",147:"marge_simpson",148:"lilith_morningstar_(hazbin_hotel)",149:"verosika_mayday_(helluva_boss)",
 152:"teela",154:"carmilla_carmine",155:"princess_yue",156:"jubilee",157:"catra",158:"dragon_(shrek)",159:"jessie_(toy_story)",160:"suki",161:"millie_(helluva_boss)",162:"ember_mclain",
 163:"kyoshi",164:"bo_peep",166:"lois_griffin",167:"beth_smith",168:"cheetah_(dc)",170:"lute_(hazbin_hotel)",171:"garnet_(steven_universe)",172:"amethyst_(steven_universe)",173:"linda_flynn-fletcher",174:"kai_green",175:"huntress_wizard"}
EXTRA["436045"]={}; R34_DANS_MODELE["436045"]={}
# --- Ajout 24 oct. (suite 5) : vote 73568440 « Ranking Female Video Game Charecters » (modèle most-popular-female-video-game-characters-902887, 617 images, 7 paliers) ---
# Images portant le nom et le jeu écrits. Rangs 1-100 : tout ; au-delà : toutes les images du périmètre Comics + Cartoons + Furry repérées sur les 617 (noms de fichier + planches).
_N73={"yorha_2b":"2B","tifa_lockhart":"Tifa Lockhart","samus_aran":"Samus Aran","chun-li":"Chun-Li","princess_zelda":"Zelda","cynthia_(pokemon)":"Cynthia (Pokémon)",
 "lara_croft":"Lara Croft","ada_wong":"Ada Wong","princess_rosalina":"Harmonie (Rosalina)","black_cat_(marvel)":"Black Cat","bayonetta_(character)":"Bayonetta",
 "invisible_woman":"Femme invisible (Sue Storm)","d.va":"D.Va","mercy":"Ange (Mercy)","ciri":"Ciri","jill_valentine":"Jill Valentine","cammy_white":"Cammy",
 "aerith_gainsborough":"Aerith","juri_han":"Juri Han","eve_(stellar_blade)":"EVE (Stellar Blade)","yorha_a2":"A2","purah":"Purah","palutena":"Palutena",
 "psylocke":"Psylocke","ranni_the_witch":"Ranni","princess_daisy":"Daisy","catwoman":"Catwoman","princess_peach":"Peach","luna_snow":"Luna Snow",
 "mai_shiranui":"Mai Shiranui","sonia_(pokemon)":"Sonia (Pokémon)","fire_keeper":"Gardienne du feu (Dark Souls)","raiden_shogun":"Raiden Shogun","widowmaker":"Fatale (Widowmaker)",
 "yelan_(genshin_impact)":"Yelan","emma_frost":"Emma Frost","melina_(elden_ring)":"Melina (Elden Ring)","lusamine_(pokemon)":"Elsa-Mina (Lusamine)","harley_quinn":"Harley Quinn",
 "artoria_pendragon":"Artoria (Saber)","ashe_(overwatch)":"Ashe (Overwatch)","panam_palmer":"Panam Palmer","urbosa":"Urbosa","nessa_(pokemon)":"Donna (Nessa)",
 "makoto_niijima":"Makoto Niijima","lady_(devil_may_cry)":"Lady (Devil May Cry)","yennefer":"Yennefer","tohsaka_rin":"Rin Tohsaka","yae_miko":"Yae Miko",
 "ashley_graham":"Ashley Graham","sakura_futaba":"Futaba Sakura","morrigan_aensland":"Morrigan","jinx_(league_of_legends)":"Jinx (LoL)","ahri":"Ahri",
 "ann_takamaki":"Ann Takamaki","queen_marika_the_eternal":"Marika (Elden Ring)","lady_maria_of_the_astral_clocktower":"Lady Maria (Bloodborne)","jade_(mortal_kombat)":"Jade (Mortal Kombat)",
 "baiken":"Baiken","miss_fortune":"Miss Fortune (Sarah Fortune)","tae_takemi":"Tae Takemi","kiriko_(overwatch)":"Kiriko","pyra_(xenoblade)":"Pyra",
 "kafka_(honkai:_star_rail)":"Kafka (Star Rail)","malenia_blade_of_miquella":"Malenia","pauline_(mario)":"Pauline","claire_redfield":"Claire Redfield",
 "aegir_(azur_lane)":"Ägir (Azur Lane)","jane_doe_(zenless_zone_zero)":"Jane Doe (ZZZ)","caitlyn_kiramman":"Caitlyn","mitsuru_kirijo":"Mitsuru Kirijo",
 "burnice_white":"Burnice","jessie_rasberry":"Jessie (FF VII)","magik_(illyana_rasputin)":"Magik","lisa_(genshin_impact)":"Lisa (Genshin)","kaine_(nier)":"Kainé",
 "camilla_(fire_emblem)":"Camilla","shenhe_(genshin_impact)":"Shenhe","hilda_(pokemon)":"Hilda (Pokémon)","juliet_starling":"Juliet Starling","nicole_demara":"Nicole Demara",
 "arlecchino_(genshin_impact)":"Arlecchino","nina_williams":"Nina Williams","may_(pokemon)":"Flora (Pokémon)","lucifer_(helltaker)":"Lucifer (Helltaker)",
 "lucina_(fire_emblem)":"Lucina","bea_(pokemon)":"Faïza (Bea)","marie_rose":"Marie Rose","judy_alvarez":"Judy Alvarez","acheron_(honkai:_star_rail)":"Acheron",
 "mavuika_(genshin_impact)":"Mavuika","beidou_(genshin_impact)":"Beidou","lulu_(final_fantasy)":"Lulu (FF X)","modeus_(helltaker)":"Modeus","sae_niijima":"Sae Niijima",
 "aphrodite_(hades)":"Aphrodite (Hades)","mona_(genshin_impact)":"Mona","jessie_(pokemon)":"Jessie (Team Rocket)","quiet_(metal_gear)":"Quiet","tracer":"Tracer",
 "poison_ivy":"Poison Ivy","barbara_gordon":"Batgirl (Barbara Gordon)","ankha":"Ankha","hornet_(hollow_knight)":"Hornet","felicia_(darkstalkers)":"Felicia (Darkstalkers)",
 "amy_rose":"Amy Rose","gamora":"Gamora","squirrel_girl_(marvel)":"Squirrel Girl (Doreen Green)","blaze_the_cat":"Blaze the Cat","toriel":"Toriel",
 "isabelle_(animal_crossing)":"Marie (Isabelle)","rabbid_peach":"Lapin Peach (Rabbid Peach)","amaterasu":"Amaterasu (Okami)","rivet_(ratchet_and_clank)":"Rivet",
 "lamb_(league_of_legends)":"Kindred (Agneau)","kamala_khan":"Kamala Khan (Ms. Marvel)"}
for _t,_n in _N73.items(): NOMS.setdefault(_t,_n)
HORS.update({"bayonetta_(character)":HORS.get("bayonetta_(character)",6845),"psylocke":7511,"ranni_the_witch":4793,"luna_snow":5508,"fire_keeper":1075,"melina_(elden_ring)":3125,
 "ashe_(overwatch)":6445,"panam_palmer":7821,"urbosa":3895,"lady_(devil_may_cry)":2465,"sakura_futaba":6317,"queen_marika_the_eternal":6276,
 "lady_maria_of_the_astral_clocktower":884,"jade_(mortal_kombat)":2187,"baiken":2855,"miss_fortune":6820,"tae_takemi":3077,"pyra_(xenoblade)":4054,
 "malenia_blade_of_miquella":2357,"aegir_(azur_lane)":1495,"jane_doe_(zenless_zone_zero)":10365,"caitlyn_kiramman":6927,"burnice_white":6868,"jessie_rasberry":2625,
 "magik_(illyana_rasputin)":5617,"lisa_(genshin_impact)":6655,"kaine_(nier)":2314,"camilla_(fire_emblem)":7940,"juliet_starling":2067,"nina_williams":2594,
 "lucifer_(helltaker)":3306,"bea_(pokemon)":6914,"marie_rose":8052,"judy_alvarez":6752,"acheron_(honkai:_star_rail)":2770,"mavuika_(genshin_impact)":5747,
 "beidou_(genshin_impact)":3215,"lulu_(final_fantasy)":3176,"modeus_(helltaker)":2704,"sae_niijima":1949,"aphrodite_(hades)":828,"quiet_(metal_gear)":4179,
 "felicia_(darkstalkers)":6113,"gamora":820,"squirrel_girl_(marvel)":7874,"rabbid_peach":295,"amaterasu":1810,"rivet_(ratchet_and_clank)":3745,"kamala_khan":1876})
VARIANTES_EV.update({"invisible_woman":"sue_storm (10 290)","psylocke":"psylocke_(marvel_rivals) (5 177), psylocke_(kwannon) (2 743)","luna_snow":"luna_snow_(marvel_rivals) (5 299)",
 "miss_fortune":"sarah_fortune (1 237)","caitlyn_kiramman":"caitlyn_(league_of_legends) (1 035)","magik_(illyana_rasputin)":"magik_(marvel_rivals) (4 315)",
 "squirrel_girl_(marvel)":"squirrel_girl_(marvel_rivals) (6 956), squirrel_girl (4 910), doreen_green (3 244)","amaterasu":"amaterasu_(okami) (661)",
 "kamala_khan":"ms._marvel_(kamala_khan) (835)","tohsaka_rin":"rin_tohsaka (1 417)","princess_rosalina":"rosalina (2 256)"})
AMBIGU|={"amaterasu","fire_keeper"}
JEUX|={"bayonetta_(character)","ranni_the_witch","luna_snow","fire_keeper","melina_(elden_ring)","ashe_(overwatch)","panam_palmer","urbosa","lady_(devil_may_cry)",
 "sakura_futaba","queen_marika_the_eternal","lady_maria_of_the_astral_clocktower","jade_(mortal_kombat)","baiken","miss_fortune","tae_takemi","pyra_(xenoblade)",
 "malenia_blade_of_miquella","aegir_(azur_lane)","jane_doe_(zenless_zone_zero)","caitlyn_kiramman","burnice_white","jessie_rasberry","lisa_(genshin_impact)","kaine_(nier)",
 "camilla_(fire_emblem)","juliet_starling","nina_williams","lucifer_(helltaker)","bea_(pokemon)","marie_rose","judy_alvarez","acheron_(honkai:_star_rail)",
 "mavuika_(genshin_impact)","beidou_(genshin_impact)","lulu_(final_fantasy)","modeus_(helltaker)","sae_niijima","aphrodite_(hades)","quiet_(metal_gear)"}
COMICS|={"psylocke","magik_(illyana_rasputin)","gamora","squirrel_girl_(marvel)","kamala_khan"}
FURRY|={"felicia_(darkstalkers)","rabbid_peach","amaterasu","rivet_(ratchet_and_clank)"}
SANS_TAG[("73568440",443)]="Blanche-Neige (Fables / The Wolf Among Us)"
SANS_TAG_MEDIUM[("73568440",443)]="Comics"
EV["73568440"]={1:"yorha_2b",2:"tifa_lockhart",3:"samus_aran",4:"chun-li",5:"princess_zelda",6:"cynthia_(pokemon)",7:"lara_croft",8:"ada_wong",9:"princess_rosalina",10:"black_cat_(marvel)",
 11:"bayonetta_(character)",12:"invisible_woman",13:"d.va",14:"mercy",15:"ciri",16:"jill_valentine",17:"cammy_white",18:"aerith_gainsborough",19:"juri_han",20:"eve_(stellar_blade)",
 21:"yorha_a2",22:"purah",23:"palutena",24:"psylocke",25:"ranni_the_witch",26:"princess_daisy",27:"catwoman",28:"princess_peach",29:"luna_snow",30:"mai_shiranui",
 31:"sonia_(pokemon)",32:"fire_keeper",33:"raiden_shogun",34:"widowmaker",35:"yelan_(genshin_impact)",36:"emma_frost",37:"melina_(elden_ring)",38:"lusamine_(pokemon)",39:"harley_quinn",40:"artoria_pendragon",
 41:"ashe_(overwatch)",42:"panam_palmer",43:"urbosa",44:"nessa_(pokemon)",45:"makoto_niijima",46:"lady_(devil_may_cry)",47:"yennefer",48:"tohsaka_rin",49:"yae_miko",50:"ashley_graham",
 51:"sakura_futaba",52:"morrigan_aensland",53:"jinx_(league_of_legends)",54:"ahri",55:"ann_takamaki",56:"queen_marika_the_eternal",57:"lady_maria_of_the_astral_clocktower",58:"jade_(mortal_kombat)",59:"baiken",60:"miss_fortune",
 61:"tae_takemi",62:"kiriko_(overwatch)",63:"pyra_(xenoblade)",64:"kafka_(honkai:_star_rail)",65:"malenia_blade_of_miquella",66:"pauline_(mario)",67:"claire_redfield",68:"aegir_(azur_lane)",69:"jane_doe_(zenless_zone_zero)",70:"caitlyn_kiramman",
 71:"mitsuru_kirijo",72:"burnice_white",73:"jessie_rasberry",74:"magik_(illyana_rasputin)",75:"lisa_(genshin_impact)",76:"kaine_(nier)",77:"camilla_(fire_emblem)",78:"shenhe_(genshin_impact)",79:"hilda_(pokemon)",80:"juliet_starling",
 81:"nicole_demara",82:"arlecchino_(genshin_impact)",83:"nina_williams",84:"may_(pokemon)",85:"lucifer_(helltaker)",86:"lucina_(fire_emblem)",87:"bea_(pokemon)",88:"marie_rose",89:"judy_alvarez",90:"acheron_(honkai:_star_rail)",
 91:"mavuika_(genshin_impact)",92:"beidou_(genshin_impact)",93:"lulu_(final_fantasy)",94:"modeus_(helltaker)",95:"sae_niijima",96:"aphrodite_(hades)",97:"mona_(genshin_impact)",98:"jessie_(pokemon)",99:"quiet_(metal_gear)",100:"tracer",
 147:"poison_ivy",193:"barbara_gordon",201:"ankha",249:"hornet_(hollow_knight)",274:"felicia_(darkstalkers)",291:"amy_rose",319:"gamora",345:"squirrel_girl_(marvel)",374:"blaze_the_cat",
 396:"toriel",409:"isabelle_(animal_crossing)",443:None,561:"rabbid_peach",568:"amaterasu",573:"rivet_(ratchet_and_clank)",576:"lamb_(league_of_legends)",591:"kamala_khan"}
EXTRA["73568440"]={}; R34_DANS_MODELE["73568440"]={}
# --- Ajout 24 oct. (suite 6) : vote 99761754 « Top Tier Waifu » (modèle best-anime-waifus-2025-17820038, 311 images, S-D ; événement réglé en « most votes », relu en Average Vote) ---
# Modèle 100 % anime, images sans nom écrit (noms de fichier = hachages) : identification visuelle sur planches agrandies ; 34 images du top 100 non identifiées avec assez de certitude.
_N99={"yor_briar":"Yor Forger","makima_(chainsaw_man)":"Makima","yorha_2b":"2B","kitagawa_marin":"Marin Kitagawa","tsunade":"Tsunade","shihouin_yoruichi":"Yoruichi",
 "miruko":"Mirko (Rumi Usagiyama)","sakurajima_mai":"Mai Sakurajima","boa_hancock":"Boa Hancock","rias_gremory":"Rias Gremory","kanroji_mitsuri":"Mitsuri Kanroji",
 "esdeath_(akame_ga_kill!)":"Esdeath","albedo_(overlord)":"Albedo","inoue_orihime":"Orihime Inoue","frieren":"Frieren","power_(chainsaw_man)":"Power",
 "hyuuga_hinata":"Hinata Hyûga","nami_(one_piece)":"Nami","emilia_(re:zero)":"Emilia","lucyna_kushinada":"Lucy (Edgerunners)","akeno_himejima":"Akeno Himejima",
 "zero_two_(darling_in_the_franxx)":"Zero Two","fubuki_(one-punch_man)":"Fubuki","alisa_mikhailovna_kujou":"Alya (Alisa Kujou)","momo_yaoyorozu":"Momo Yaoyorozu",
 "mikasa_ackerman":"Mikasa Ackerman","jabami_yumeko":"Yumeko Jabami","nakano_miku":"Miku Nakano","tohsaka_rin":"Rin Tohsaka","nakano_nino":"Nino Nakano",
 "artoria_pendragon":"Artoria (Saber)","yuuki_asuna":"Asuna","rem_(re:zero)":"Rem","himiko_toga":"Himiko Toga","kochou_shinobu":"Shinobu Kochô",
 "darkness_(konosuba)":"Darkness","yunyun_(konosuba)":"Yunyun","zenin_maki":"Maki Zen'in","hestia_(danmachi)":"Hestia","hoshino_ai":"Ai Hoshino","wiz_(konosuba)":"Wiz",
 "fern_(sousou_no_frieren)":"Fern","mount_lady":"Mount Lady","oze_maki":"Maki Oze","akame_(akame_ga_kill!)":"Akame","tatsumaki":"Tatsumaki","hori_kyouko":"Kyôko Hori",
 "hadou_nejire":"Nejire Hadô","violet_evergarden_(character)":"Violet Evergarden","daki_(kimetsu_no_yaiba)":"Daki","kugisaki_nobara":"Nobara Kugisaki","ayase_momo":"Momo Ayase",
 "misa_amane":"Misa Amane","shinomiya_kaguya":"Kaguya Shinomiya","himeno_(chainsaw_man)":"Himeno","android_18":"C-18","bulma_briefs":"Bulma",
 "asuka_langley_sohryu":"Asuka Langley","megumin":"Megumin","mizuhara_chizuru":"Chizuru Mizuhara","komi_shouko":"Shôko Komi","raphtalia":"Raphtalia",
 "aqua_(konosuba)":"Aqua","mei_hatsume":"Mei Hatsume","nakano_itsuki":"Itsuki Nakano","maomao_(kusuriya_no_hitorigoto)":"Maomao","gotou_hitori":"Hitori Gotô (Bocchi)"}
for _t,_n in _N99.items(): NOMS.setdefault(_t,_n)
HORS.update({"jabami_yumeko":2819,"hestia_(danmachi)":6058,"oze_maki":1474,"hori_kyouko":553,"shinomiya_kaguya":5310,"himeno_(chainsaw_man)":4791,
 "mizuhara_chizuru":3600,"raphtalia":4767,"maomao_(kusuriya_no_hitorigoto)":3485,"gotou_hitori":7249})
ANIME|=set(_N99)-{"yorha_2b","artoria_pendragon","tohsaka_rin"}
ANIME_SEUL|={"99761754"}
INCERTAIN|={("99761754",47),("99761754",57)}  # n° 9 = Nico Robin (correction utilisateur 24/10 ; d'abord pris pour Boa Hancock)
EV["99761754"]={1:"yor_briar",2:"makima_(chainsaw_man)",3:"yorha_2b",4:"kitagawa_marin",5:"tsunade",6:"shihouin_yoruichi",7:"miruko",8:"sakurajima_mai",9:"nico_robin",10:"rias_gremory",
 11:None,12:"kanroji_mitsuri",13:"esdeath_(akame_ga_kill!)",14:"albedo_(overlord)",15:"inoue_orihime",16:"frieren",17:"power_(chainsaw_man)",18:None,19:"hyuuga_hinata",20:"nami_(one_piece)",
 21:"emilia_(re:zero)",22:"lucyna_kushinada",23:None,24:"akeno_himejima",25:"zero_two_(darling_in_the_franxx)",26:"fubuki_(one-punch_man)",27:"alisa_mikhailovna_kujou",28:"momo_yaoyorozu",29:"mikasa_ackerman",30:"jabami_yumeko",
 31:"nakano_miku",32:None,33:"tohsaka_rin",34:"nakano_nino",35:"artoria_pendragon",36:None,37:"yuuki_asuna",38:None,39:"rem_(re:zero)",40:None,
 41:None,42:None,43:"himiko_toga",44:None,45:"kochou_shinobu",46:None,47:"yunyun_(konosuba)",48:"darkness_(konosuba)",49:"zenin_maki",50:"hestia_(danmachi)",
 51:"hoshino_ai",52:None,53:"wiz_(konosuba)",54:"fern_(sousou_no_frieren)",55:None,56:"mount_lady",57:"oze_maki",58:"akame_(akame_ga_kill!)",59:None,60:None,
 61:"tatsumaki",62:None,63:"hori_kyouko",64:"hadou_nejire",65:None,66:"violet_evergarden_(character)",67:None,68:"daki_(kimetsu_no_yaiba)",69:"kugisaki_nobara",70:None,
 71:"ayase_momo",72:None,73:None,74:None,75:None,76:None,77:"misa_amane",78:"shinomiya_kaguya",79:None,80:None,
 81:"himeno_(chainsaw_man)",82:"android_18",83:"bulma_briefs",84:"asuka_langley_sohryu",85:"megumin",86:"mizuhara_chizuru",87:"komi_shouko",88:None,89:"raphtalia",90:"aqua_(konosuba)",
 91:None,92:"mei_hatsume",93:None,94:None,95:None,96:"nakano_itsuki",97:"maomao_(kusuriya_no_hitorigoto)",98:None,99:None,100:"gotou_hitori"}
EXTRA["99761754"]={}; R34_DANS_MODELE["99761754"]={}

# --- Ajout 24 oct. (relevés 281-300) : tags rattachés aux personnages entrés dans la sélection 243 ---
# Batgirl : la sélection compte batgirl + barbara_gordon et versions (union) ; Kyoka Jiro : tag principal rule34 kyoka_jiro (jirou_kyouka = 2e tag)
REMAP_243 = {"barbara_gordon": "batgirl", "jirou_kyouka": "kyoka_jiro"}
for _e, _d in EV.items():
    for _k, _t in list(_d.items()):
        if _t in REMAP_243: _d[_k] = REMAP_243[_t]
NOMS.update({"batgirl": "Batgirl (Barbara Gordon)", "kyoka_jiro": "Kyôka Jirô"})
COMICS |= {"batgirl"}
ANIME |= {"kyoka_jiro"}
HORS.update({"batgirl": 7875, "kyoka_jiro": 7493})
