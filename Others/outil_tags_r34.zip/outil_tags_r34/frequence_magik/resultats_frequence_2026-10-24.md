# Fréquence de publication : Magik vs Jinx, Gwen/Spider-Gwen, Nami, Frieren, Psylocke (24 oct. 2026)

Requêtes r34 : `requetes_r34.json`. Danbooru : `danbooru_12mois.py` → `danbooru_12mois_2026-10-24.json`.

## rule34.xxx (comptage = dernier pid + 21 ; fenêtres par ID de post)

- F1 = `id:>11883999` (≈ 30 nov. 2024 → 24 oct. 2026) : site = 6 191 955 posts
- F2 = `id:>13689999` (≈ 12 fév. 2026 → 24 oct. 2026) : site = 4 669 539 posts
- Entre-deux (F1 − F2, ≈ déc. 2024 → fév. 2026) : site = 1 522 416 posts
- Ancres non datées directement (rafales de co-tags : révélation SG / X-Men Tōkon). Le volume du site a explosé en 2026 → comparer en part du site.

| Personnage | F1 | F2 | Entre-deux | /10k F1 | /10k F2 | /10k entre-deux | Magik / perso (F2) |
|---|---|---|---|---|---|---|---|
| Nami | 30 051 | 21 063 | 8 988 | 48.5 | 45.1 | 59.0 | 0.17 |
| Frieren | 23 457 | 19 257 | 4 200 | 37.9 | 41.2 | 27.6 | 0.19 |
| Jinx | 10 143 | 7 329 | 2 814 | 16.4 | 15.7 | 18.5 | 0.49 |
| Gwen Stacy / Spider-Gwen | 8 085 | 5 607 | 2 478 | 13.1 | 12.0 | 16.3 | 0.64 |
| Psylocke | 8 085 | 5 313 | 2 772 | 13.1 | 11.4 | 18.2 | 0.68 |
| Magik | 5 082 | 3 591 | 1 491 | 8.2 | 7.7 | 9.8 | 1.00 |

Magik F1 = 5 733 − 651 (avant `id:<11884000`) ; Gwen = union 4 tags Gwen Stacy ; Psylocke = Betsy + Kwannon + Rivals.

## Danbooru (oct. 2025 → sept. 2026, date de mise en ligne)

| Personnage | Tag | 12 mois | /mois | /10k |
|---|---|---|---|---|
| Frieren | frieren | 5 028 | 419 | 23.23 |
| Nami | nami_(one_piece) | 3 021 | 252 | 13.96 |
| Magik | magik_(x-men) | 578 | 48 | 2.67 |
| Jinx | jinx_(league) (skins impliqués) | 481 | 40 | 2.22 |
| Psylocke | psylocke (skins impliqués) | 481 | 40 | 2.22 |
| Gwen / Spider-Gwen | ~gwen_stacy ~spider-gwen | 316 | 26 | 1.46 |

Magik sans août 2026 (122, sortie Tōkon) : 456 / 11 mois ≈ 41/mois → au niveau de Jinx/Psylocke.
