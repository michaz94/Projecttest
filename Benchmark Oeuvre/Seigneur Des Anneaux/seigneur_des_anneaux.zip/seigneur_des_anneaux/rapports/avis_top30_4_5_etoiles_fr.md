# Goodreads, avis à 5★ et 4★ : éloges et reproches (traduits)

Base : les 30 avis les plus en avant à 5★ et à 4★ (`data/goodreads_communaute_top30_4_5_raw.json`). Après retrait des 15 avis qui contiennent des mots annonçant la suite de la saga : **45 avis lus** (25 à 5★, 20 à 4★). **Niveau de preuve : lecture manuelle des extraits de 700 caractères ; ce qui se trouve dans la partie tronquée n'est pas compté.** Les nombres ci-dessous sont mes comptages à la main, approximatifs (±1). Cinq avis n'ont pas de jugement visible (4★ n°6, 13, 18, 20, 22 : parodie, citation, résumé, ironie). Les références « 5★ n°5 » renvoient aux traductions plus bas.

## Éloges (ce que ces lecteurs louent)

| Éloge | Nombre | Avis |
|---|---|---|
| **Le monde, sa richesse, ses détails (worldbuilding, lore)** | environ 11 | 5★ n°5, 6, 16, 18, 21, 22, 27 ; 4★ n°9, 10, 12, 26 |
| **Les personnages et les amitiés** (Sam et Frodon, Legolas et Gimli, Aragorn, la Communauté) | environ 10 | 5★ n°5, 9, 11, 12, 16, 17, 21, 22 ; 4★ n°9, 14 |
| **Le livre grandit à la relecture** (« je l'apprécie davantage à chaque lecture ») | 7 | 5★ n°6, 8, 9, 14, 26 ; 4★ n°19, 27 |
| **L'écriture, la poésie, les chansons** | 5 à 6 | 5★ n°3, 7, 14, 16, 27 (voix du livre audio) ; 4★ n°26 |
| **Fondateur du genre, influence** | 5 | 5★ n°3, 6, 21 ; 4★ n°12, 23 |
| **Ambiance douillette, nostalgique, innocence de la Comté** | 4 | 5★ n°12, 17, 26 ; 4★ n°28 |
| **Thèmes** (amitié, courage, responsabilité, justice contre pouvoir) | 3 | 5★ n°11 ; 4★ n°9, 21 |
| **Plus riche que le film** | 3 | 5★ n°10, 18 ; 4★ n°19 |
| **Frodon est plus mûr et plus sage dans le livre** | 1 | 4★ n°14 |
| **Lecture à voix haute ou partagée** (avec sa fille, ses fils) | 3 | 5★ n°14 ; 4★ n°24 ; 5★ n°29 (contexte) |
| **Édition et traduction** (belles illustrations, traduction presque parfaite) | 1 | 4★ n°27 |

Exemples : « Seul Tolkien pouvait écrire un prologue de 20 pages de lore de hobbits en vrac et me le faire apprécier » (5★ n°12). « Chaque chose est à sa place et je n'ai jamais senti que quelque chose était en trop » (4★ n°10, persan). « Donnez-moi la première demi-douzaine de chapitres… et j'en ferai un petit paradis sur terre » (5★ n°17).

## Reproches (ce que ces mêmes lecteurs critiquent)

| Reproche | Nombre | Avis |
|---|---|---|
| **Première tentative ratée, abandon ou ennui** (qui s'est résolu à la relecture ou plus tard) | environ 8 | 5★ n°6, 8, 9, 11, 26, 29 ; 4★ n°19, 27 |
| **Rythme lent, début lent, chapitres longs, Conseil long** | 5 | 5★ n°5, 9 ; 4★ n°9, 24, 26 |
| **Style ou vocabulaire difficile, jugé démodé** | 4 | 4★ n°4, 12, 19 ; 5★ n°29 (sa fille ne comprenait pas les mots) |
| **Tom Bombadil** | 3 | 5★ n°8 (abandon après lui) ; 4★ n°26 (« pas très fan »), 27 |
| **Détails superflus, minutie** | 2 | 4★ n°19, 27 (tous deux sur des lectures antérieures) |
| **Pas conquis, malgré le statut de classique** | 2 | 4★ n°4, 11 |
| **Frodon moins attachant que dans le film** | 1 | 5★ n°5 |
| **Fin sur un cliffhanger, jugée surprenante** | 1 | 5★ n°5 |

Exemples : « Je me suis ennuyée de voir les personnages passer tant de temps à marcher (et marcher, puis marcher encore) » (5★ n°9). « Peut-être que le Conseil est un peu trop long et répétitif » (4★ n°26). « Le style d'écriture est assez démodé » (4★ n°4).

## Ce que cela montre

- **Les reproches sont les mêmes que chez les mécontents** (lenteur, marche, Tom Bombadil, style, détails), mais ils sont **plus rares et plus doux**, et presque toujours **dépassés** : le lecteur dit qu'il a eu du mal au début, ou la première fois, puis a fini par aimer.
- **Le reproche « début lent » est donc partagé par les fans.** Il ne les empêche pas de donner 5 étoiles. Cela rejoint les 9/10 de SensCritique accompagnés du mot « laborieux ».
- **Éloges dominants :** le monde et les personnages, très loin devant le reste. Aucun avis ne loue l'intrigue ou le suspense en tant que tel, sauf 5★ n°3 (« suspense », « page-turner »), 4★ n°9 (« action ») et n°19 (« danger et intrigue »).
- **Limites :** 45 avis seulement, choisis par le tri de popularité de Goodreads ; extraits tronqués ; les reproches placés après 700 caractères ne sont pas vus. Les avis écartés par le filtre anti-spoil peuvent contenir d'autres reproches.

---

# Traductions

Traduction par moi (IA) des extraits de `avis_top30_4_5_etoiles.md` (700 caractères maximum chacun ; « [tronqué] » = la suite n'est pas dans l'extrait). Trois extraits sont en persan, un en arabe, un en serbe ou croate, deux en espagnol : je les ai traduits sans vérification par un locuteur natif. Les mots entre crochets sont de moi. Les poèmes et citations du livre sont rendus en français courant, pas dans la traduction de Francis Ledoux. Avis du filtre anti-spoil : 15 retirés (voir `avis_top30_4_5_etoiles.md`).

## 5 étoiles

**5★ n°2 — Lyndz** (1601 j'aime, 2011-06-08)

> Je refuse d'écrire un avis sur l'un des meilleurs livres jamais écrits. Demander à un vrai fan de fantasy d'écrire un avis sur *Le Seigneur des Anneaux*, c'est comme demander à un chrétien d'écrire un avis sur la Bible. Alors je vais plutôt vous fournir ce graphique : [le graphique n'est pas dans l'extrait]

**5★ n°3 — Savage Bookwolf (new Mario the lone bookwolf)** (439 j'aime, 2021-11-05)

> Fonder un genre comme un chef. Voler tout ce qu'on peut à la mythologie et aux vieux classiques, peut-être parfois un tout petit peu ennuyeux. La belle tradition d'utiliser les idées des autres pour créer du neuf est très présente ici, d'autant que Tolkien avait le parcours idéal pour puiser partout où il trouvait de l'inspiration : des œuvres antiques, médiévales et, à l'époque, modernes. Ce serait particulièrement intéressant de lire ou relire *Le Seigneur des Anneaux* en regardant comment il a laissé les classiques muter vers de nouvelles formes, transformé des clichés démodés pour un public moderne, et surtout en a fait un livre captivant, bien écrit et plein de suspense. Ne vous fâchez pas, vieux classiques, ce n'est pas votre faute…

**5★ n°5 — SK** (306 j'aime, 2022-09-09)

> Ahhh c'était GÉNIAL ! Pourquoi ne l'ai-je pas lu plus tôt ? Ça me dépasse. Le worldbuilding est si riche, si immersif, si détaillé, on s'y perd tellement facilement. Oui, le rythme est plus lent que ce que j'attendais, mais ça a continué à m'intéresser. J'adore les personnages, surtout (et évidemment) Aragorn. Il est écrit à la perfection. Il me faudra peut-être plus de temps pour m'attacher à Frodon, j'ai préféré sa version du film. Je ne sais pas pourquoi je pensais que le livre ne se terminerait pas sur un cliffhanger 😂 Mais j'ai hâte de lire le suivant. Je comprends pourquoi ces livres ont un tel battage. [suite tronquée : elle vient de voir les films avec une amie et veut lire toute la série]

**5★ n°6 — Saranya [uni- kinda ia]** (251 j'aime, 2026-05-17)

> Un mot : CHEF-D'ŒUVRE. Point. Je ne sais pas pourquoi j'avais abandonné ce livre la première fois. J'ai dû tomber dans une panne de lecture et perdre mon élan, parce que cette fois il m'a complètement soufflée. J'aurais dû le lire plus tôt ! Si vous n'avez ni lu le livre ni vu les films, honnêtement, qu'est-ce que vous faites ? Lisez-le, tout de suite. C'est de la high fantasy à son sommet absolu. Une épopée immense, le modèle fondateur de toute création moderne de mythes ou de fantasy. Penser que cette richesse de worldbuilding immersif a été écrite dès les années 1950 est vertigineux. Considérez-moi officiellement convertie : je suis maintenant l'une des plus grandes fans de Tolkien de la planète. [tronqué]

**5★ n°7 — Carolyn Marie** (243 j'aime, 2024-05-11)

> C'est l'un des livres les plus enchanteurs et les mieux construits que j'aie jamais lus !

**5★ n°8 — Matthew** (224 j'aime, 2013-01-09)

> Levez la main si vous vous souvenez des super foires du livre ou des bons de commande Scholastic de votre enfance ! Eh bien, au collège j'ai pris cette belle lecture dans un coffret avec le reste de la trilogie et *Le Hobbit*. Malheureusement, même si j'ai toujours aimé lire, je n'ai pas trouvé la motivation de le finir pendant près de 15 ans. Au début des années 90, j'ai lu *Le Hobbit*. Puis j'ai commencé celui-ci mais j'ai perdu l'intérêt peu après Tom Bombadil. Tolkien est formidable, mais ça peut faire beaucoup pour un collégien. Même quand je l'ai enfin fini vers 2001 (juste avant le film), cela restait un peu un travail d'amour. Au final pourtant, sans aucun doute, 5 étoiles… [tronqué]

**5★ n°9 — Hannah Greendale (Hello, Bookworm)** (260 j'aime, 2015-12-26)

> [Publicité pour sa chaîne BookTube.] Des vallées de la Comté au sommet d'Amon Hen, *La Communauté de l'Anneau* est une aventure extraordinaire de personnages attachants qui défient des obstacles impossibles. Je dois avouer que, la première fois que j'ai lu ce livre, je me suis ennuyée de voir les personnages passer tant de temps à marcher (et marcher, puis marcher encore). Mais à chaque lecture, je l'apprécie davantage. Tolkien était vraiment un écrivain extraordinaire. La clé pour apprécier la trilogie est de la savourer lentement. Ne soyez pas pressé de la finir… [tronqué]

**5★ n°10 — Tharindu Dissanayake** (206 j'aime, 2020-11-11)

> « Chantez, hé ! pour le bain à la fin du jour qui lave la boue de la fatigue ! Fou celui qui ne chante pas : Ô ! l'eau chaude est une noble chose ! » « Il ne faut pas écouter tout ce qu'on entend. » Quand j'ai vu le film *La Communauté de l'Anneau* (environ trois heures), je l'ai trouvé incroyablement long. Mais maintenant que j'ai enfin lu le livre, je suis stupéfait que le film ait réussi à faire tenir au moins la moitié du contenu en trois heures, car c'est une histoire longue et riche en événements avec beaucoup plus d'informations. « Le conseil est un cadeau dangereux, même des sages aux sages. » Tolkien n'a jamais connu de limites à son imagination vive… [tronqué ; les citations sont tirées du livre]

**5★ n°11 — Will Byrnes** (195 j'aime, 2008-11-05)

> L'une des grandes œuvres de la littérature du XXe siècle. J'ai essayé au lycée sans réussir à aller au bout. Le deuxième essai, au début de la vingtaine, a été le bon. Frodon part en quête et le livre aborde la morale, l'amitié, la responsabilité envers les autres, affronter ses peurs, le courage, le danger. En décrivant une bataille mondiale entre le bien et le mal, Tolkien donne un visage humain (ou hobbit) à ce conflit. Ses thèmes sont universels et ses personnages très accessibles. Frodon, Sam et Gandalf sont des héros pour les siècles, et Gollum est ce qui peut arriver quand quelqu'un de normal est corrompu par les ténèbres. C'est ma série préférée… [tronqué]

**5★ n°12 — Jaime Fok** (196 j'aime, 2026-01-16)

> Seul Tolkien pouvait écrire un prologue de 20 pages de lore de hobbits en vrac et me le faire apprécier. Franchement le meilleur déversement d'informations de tous les temps. La façon dont ce livre passe d'une aventure à hauts enjeux à « les hobbits adorent les champignons » dans la phrase suivante est à étudier. C'est fantaisiste, douillet, mais aussi inquiétant par moments. Sam et Frodon, Legolas et Gimli sont peut-être mes deux amitiés fictives préférées. Je suis tellement amoureuse de ce monde.

**5★ n°14 — Bradley** (185 j'aime, 2013-03-26)

> Relecture 29/06/25 : j'ai sorti ma belle édition reliée et je me suis offert une relecture lente, luxueuse et langoureuse d'une des plus belles histoires jamais écrites. Après tant de lectures, je me suis simplement délecté de TOUS les détails, des longues histoires, même de la forme des poèmes. C'est un chemin connu, mais accueillant. Gimli, fils de Glóin, sait. Il sait exactement ce que je ressens. Relecture 07/01/24 : lu à voix haute avec ma fille, à l'ancienne, avec les voix, les chansons nouvelles et les larmes aux yeux. Rien ne vaut la lecture à voix haute. Le rythme est d'un autre monde : il nous plonge dans toute la nature, le monde lui-même, et c'est incroyablement bon. Et c'est bien au-delà de l'histoire principale que nous connaissons… [tronqué]

**5★ n°16 — Game0ftomes** (171 j'aime, 2024-03-21)

> *La Communauté de l'Anneau* est un chef-d'œuvre absolu qui captive de la première à la dernière page. Riche en worldbuilding et en lore, il fait découvrir la Terre du Milieu dans tous ses détails à couper le souffle, avec des personnages inoubliables et des aventures épiques. L'histoire de la quête de Frodon pour détruire l'Anneau unique est à la fois palpitante et très émouvante, mêlant action à hauts enjeux et moments poignants d'amitié et de courage. L'écriture de Tolkien est belle et immersive, le mélange parfait de fantasy et de narration intemporelle. [lien Instagram]

**5★ n°17 — Jason Koivu** (164 j'aime, 2008-11-23)

> Donnez-moi quelques amis, une étendue de collines agréables et un bois inquiétant. Laissez-nous batifoler dans les restes de l'innocence, à l'abri de la peur qui parcourt les veines du monde plus vaste. Donnez-moi la première demi-douzaine de chapitres de *La Communauté de l'Anneau* et j'en ferai volontiers un petit paradis sur terre. Après avoir fini *Le Hobbit* tout jeune, il me fallait quelque chose de plus mûr. Heureusement, Tolkien l'avait fait avec sa trilogie épique. *La Communauté…*, premier livre, est mon préféré des trois. Je suis tombé amoureux des quatre petits amis qui partent seuls, avec leurs aventures et leurs mésaventures… [tronqué]

**5★ n°18 — Alexia** (154 j'aime, 2026-06-28)

> J'ai regardé les films pendant mon enfance et je les ai adorés ; mais si les films rendent honorablement l'essence de l'histoire, le livre est, comme souvent, bien plus détaillé et riche. Le monde créé par l'auteur est tout simplement magnifique, avec des détails complexes et des descriptions vivantes qui lui donnent vie. Chaque fois que l'auteur révélait un nouveau détail de la Terre du Milieu, cela donnait un sentiment réconfortant d'appartenance et de familiarité. Sa façon de décrire les elfes, les hobbits, les nains et les hommes était brillante, montrant sa maîtrise du worldbuilding. Chaque peuple a des coutumes, des traditions et des cultures si distinctes que je me suis surprise… [tronqué]

**5★ n°20 — Manny** (139 j'aime, 2017-10-18)

> Mon éducation de jeune Allemand continue. Je lis des livres pour enfants sans difficulté depuis un moment, mais les livres pour adultes sont encore difficiles. J'ai pensé que lire *Le Seigneur des Anneaux* en traduction pourrait aider, car pour moi il se situe entre la littérature jeunesse et la littérature adulte. Le vocabulaire et la grammaire sont ceux de la littérature adulte ; mais l'écriture est concrète et directe comme dans la littérature jeunesse, avec peu d'abstractions, de généralisations et de structures narratives compliquées. Je pense que ça a bien marché, et j'ai senti mon vocabulaire s'élargir. Mais surtout, ça augmente… [tronqué]

**5★ n°21 — Maddie Fisher** (143 j'aime, 2025-02-12)

> C'est là que mon amour de la fantasy a commencé. Tolkien est l'auteur fondateur des mondes de fantasy épique, et à ce jour je n'ai pas encore lu son égal en matière de worldbuilding. La géographie, l'histoire, les peuples, les langues et les cultures de la Terre du Milieu me semblent aussi réels que le monde où nous vivons. Il a bâti la « famille choisie » originelle : la Communauté incarne l'acceptation, le sacrifice, la protection, l'honneur, le devoir et le but auxquels je compare toute autre troupe de héros. Cette quête fondatrice a les enjeux, la tension, les chances défavorables et l'espoir désespéré auxquels toute autre quête aspire. Ce livre est la réponse à la question « Pourquoi lisez-vous ? » et l'étalon auquel je compare tous les autres livres de fantasy épique. [tronqué]

**5★ n°22 — Rebecca** (151 j'aime, 2024-12-21)

> « Tout ce qui est or ne brille pas, / Tous ceux qui errent ne sont pas perdus ; / Le vieux qui est fort ne se flétrit pas, / Les racines profondes ne sont pas atteintes par le gel. / Des cendres un feu s'éveillera, / Une lumière jaillira des ombres ; / Renouvelée sera la lame qui fut brisée, / Le sans-couronne sera de nouveau roi. » Si vous aimez les aventures épiques, une bande de marginaux attachants et un bon soupçon de chaos magique, *La Communauté de l'Anneau* est fait pour vous. Tolkien ouvre la trilogie avec une histoire si riche en worldbuilding qu'on sent presque l'herbe de la Comté sous les pieds et l'haleine des orques dans la Moria (même si, honnêtement, on s'en passerait). Le livre commence avec Frodon Sacquet… [tronqué]

**5★ n°23 — Jo** (132 j'aime, 2017-01-21)

> C'était ma quatrième ou cinquième lecture, et franchement, c'était de loin la meilleure.

**5★ n°24 — Henry Avila** (122 j'aime, 2022-12-07)

> Un livre lu trois fois par une même personne (moi), inutile de dire qu'il est bon, l'évidence est claire pour tous. Tel est le premier roman du brillant *Seigneur des Anneaux*… *La Communauté de l'Anneau*. Frodon Sacquet, neveu (cousin en réalité) adopté par M. Bilbon Sacquet, suit à contrecœur ses pas hésitants depuis la paisible Comté où rien ne se passe, jusqu'aux petits Hobbits moitié moins grands que les humains mais au cœur plus grand. Il rejoint le combat épique contre le Seigneur des Ténèbres Sauron, sous la direction du magicien mystérieux, imposant et distant Gandalf le Gris ; les autres Hobbits de Hobbitebourg trouvent les Sacquet bizarres, leurs errances anormales dans ce lieu presque parfait… [tronqué]

**5★ n°25 — Anish Kohli** (109 j'aime, 2017-07-24)

> On ne critique pas simplement *Le Seigneur des Anneaux* !! Pourtant me voici à essayer. Avec les mots de Sam Gamegie le sage, je peux résumer : « Oh, ça ne leur rend pas justice, de loin. » C'était une lecture partagée avec celui qui l'a abandonné et celui qui ne l'a pas aimé. Incroyants, vous dis-je ! J'ai pris tout mon temps avec ce livre, savourant chaque page et chaque mot, en regardant le film pendant ma lecture. Ça a été un grand moment ! « N'est-ce pas un étrange destin que nous souffrions tant de peur et de doute pour si peu de chose ? » C'est le 111e anniversaire de Bilbon Sacquet. Toute la Comté est invitée à célébrer l'événement d'un hobbit bizarre dont on dit qu'il a de immenses trésors… [tronqué]

**5★ n°26 — Anna [Bran. San. Stan]** (115 j'aime, 2024-03-24)

> 2025 : première relecture ! 2024 : Rares sont les livres qui me mettent dans mon endroit heureux spécial ; qui me donnent cette sensation douillette et réconfortante et me rendent heureuse d'être dans ce monde. *La Communauté de l'Anneau* fait exactement cela ; la magie de l'histoire était telle que faire partie du voyage de Frodon était merveilleux, plein de merveilles, et m'a laissé un sentiment d'émerveillement longtemps après avoir cessé de lire pour la journée. Franchement, je ne m'attendais pas à l'aimer autant, surtout que mes tentatives précédentes avaient échoué. Je suis contente de ne pas m'être forcée à le finir il y a dix ans, ou pire, vingt ans. Je n'étais pas prête alors et je n'aurais pas pu l'apprécier. [tronqué]

**5★ n°27 — Dream.M** (110 j'aime, 2022-08-28)

> [Persan] Wow ! Béni soit Dieu, le meilleur des créateurs : voilà ce qu'on appelle ça ! Comment ce livre peut-il être aussi bien écrit ? Est-il possible de créer un monde à partir de rien avec autant de détails et de logique ? Tolkien, par Dieu, tu n'es pas un humain. Ou bien tu as vu des choses et tu sais ce que les autres n'ont pas vu. … J'ai écouté le livre audio sur Fidibo (le compte d'un ami). Bravo à lui ♡ C'était un très, très bon choix, car en plus du plaisir de l'histoire elle-même, la voix puissante du narrateur et son ton de narration extrêmement « sexy » étaient excellents, un régal. … Lire *Le Silmarillion* et voir les films m'ont sûrement fait mieux comprendre le livre et en profiter davantage.

**5★ n°28 — Kimberly** (107 j'aime, 2022-06-30)

> Je l'ai lu il y a des décennies et il s'est retrouvé, je ne sais comment, dans ma liste de lectures en cours. Je pense que tout ce qui était possible a été dit sur cette histoire. Elle m'a envoûtée et m'a fait entrer dans le monde de Tolkien sans l'ombre d'un effort. Dieu merci !

**5★ n°29 — Julie  G** (113 j'aime, 2025-12-20)

> J'ai relu *Le Hobbit* l'an dernier avec ma plus jeune (15 ans), et j'ai été ravie qu'elle devienne instantanément fan. Je ne m'étais jamais aventurée dans la trilogie elle-même, bien que j'aie vu tous les films. Je dois être honnête : je regardais les films pour une seule raison : Viggo Mortensen. Si on m'avait demandé ce qui se passait d'autre dans l'histoire, j'aurais sans doute répondu : « Ses yeux. » Alors, il y a deux mois, cette même fille m'a demandé d'essayer le premier livre de la trilogie. J'étais au milieu d'un gros livre, alors j'ai suggéré qu'elle le lise seule, mais elle a échoué avant le premier chapitre. Elle a dit qu'elle ne comprenait pas beaucoup de mots. Si vous l'avez lu, vous comprenez. [tronqué]

**5★ n°30 — فؤاد** (103 j'aime, 2016-05-25)

> [Persan] Depuis l'âge de treize ou quatorze ans, je rêvais du *Seigneur des Anneaux*. La première fois, j'ai vu à la télévision des morceaux épars du film : des créatures naines vivant dans un beau village, un vieux magicien qui lance des feux d'artifice, un anneau maléfique qui trouble la paix du monde de l'histoire, des cavaliers noirs, et un œil de feu qui observe toujours. Même si je n'ai jamais pu voir toute la trilogie, ces seuls éléments ont tellement excité mon imagination d'adolescent que connaître l'histoire complète est toujours resté un de mes regrets. Puis, au lycée, un camarade lisait le livre et nous en parlions. Enfin, nous ne parlions pas vraiment : c'était surtout lui qui racontait, et moi j'étais de plus en plus fasciné. Le livre était à portée de main, et moi, rat de bibliothèque… [tronqué]

## 4 étoiles

**4★ n°4 — Matt's Fantasy Book Reviews** (326 j'aime, 2021-11-17)

> [Publicité pour sa chaîne YouTube.] Même si le style d'écriture est assez démodé, ce livre reste un plaisir à lire pour un premier lecteur. Même si c'est difficile à croire pour quelqu'un qui ne lit que de la fantasy, je n'avais en fait pas lu ce livre avant très récemment. Je n'aimais pas la fantasy enfant, et quand j'y suis venu adulte, je pensais que ce livre ne m'intéresserait pas. Et même si je ne l'ai pas apprécié autant que les fanatiques qui disent que c'est la plus grande histoire de fantasy jamais racontée, c'était une lecture qui valait la peine et qui tient toujours la route sur beaucoup de points. Il faut constamment se rappeler l'année… [tronqué]

**4★ n°6 — Lyn** (136 j'aime, 2011-07-30)

> [Parodie d'interview] Ce soir, dans Anderson Cooper 360, nous voici à Murfreesboro, Tennessee, au Green Dragon Public House and Brewery, un pub inspiré de Tolkien. Notre invité spécial est nul autre que LE Hobbit, M. Bilbon Sacquet, de la Comté. Nous allons faire connaissance avec celui qui a tant compté pour des générations de lecteurs puis pour une nouvelle génération de spectateurs dans cette dernière décennie. Bilbon, comment allez-vous ce soir ? — Bien, merci, Anderson, et vous ? — Très bien, merci. Dites-moi, comment était-ce de travailler avec Peter Jackson ? — Qu'y a-t-il à ne pas aimer ? C'est un professionnel accompli, avec un grand souci du détail… [tronqué ; avis humoristique, sans jugement visible]

**4★ n°7 — James** (133 j'aime, 2012-01-08)

> 4+ sur 5 pour *La Communauté de l'Anneau*, premier roman de la trilogie de J.R.R. Tolkien, adaptée plus tard en une franchise cinématographique à un milliard de dollars. Je me considère chanceux d'avoir pu lire ce livre avant qu'il devienne un film, même si j'ai aussi aimé le film. Pourquoi ce livre : j'avais 13 ans quand je suis tombé dessus alors qu'un ami le lisait. C'était un grand joueur de jeux vidéo, passionné de sport fantasy et de science-fiction. Bons amis, mais nous avions des loisirs différents. Il en était au tiers du livre, me parlait de Bilbon, Frodon et Gandalf… et je crois que j'ai répondu quelque chose comme : « Mais où sont les lions, les ours et les tigres… oh… » [tronqué]

**4★ n°9 — Gillian** (108 j'aime, 2022-10-31)

> « Un Anneau pour les gouverner tous. Un Anneau pour les trouver. Un Anneau pour les amener tous et dans les ténèbres les lier. » 4,5 étoiles ! Une fantasy épique pleine d'action sur l'amitié, le pouvoir, le choix de sa voie et la résilience face aux défis. *La Communauté de l'Anneau* suit Frodon Sacquet, un hobbit cousin de « Biblo », dans un voyage épique pour détruire un puissant anneau et empêcher le Seigneur des Ténèbres d'accomplir ses plans. En chemin, Frodon rencontre de nouveaux amis et affronte plusieurs épreuves. Ce livre était si bon ! Le rythme du début était lent, mais une fois qu'il s'est accéléré, j'étais complètement plongée dans le monde fantastique et détaillé créé par l'auteur. Le worldbuilding… [tronqué]

**4★ n°10 — Sara Kamjou** (104 j'aime, 2017-02-27)

> [Persan] J'ai vu le film du *Seigneur des Anneaux* il y a environ trois ans et, même si j'avais très envie de lire le livre, j'ai décidé d'attendre que l'image du film, malgré sa splendeur, s'estompe dans mon esprit, pour ne pas empêcher mon imagination de visualiser le livre de façon créative. *Le Seigneur des Anneaux* n'est certainement pas un livre, c'est un monde ! Un monde complet et unique que Tolkien a bâti avec talent. Dans ce monde, chaque chose est à sa place et je n'ai jamais senti que quelque chose était en trop ou que sa présence ou son absence ne changeait rien. L'histoire tourne autour des anneaux de pouvoir : parmi les vingt anneaux, celui qui est le plus maléfique, d'après une histoire qui remonte au *Hobbit*, est tombé entre les mains de Frodon. *La Communauté de l'Anneau* est l'histoire du porteur de l'anneau et de ses aventures. Bien que *Le Seigneur des Anneaux* soit en réalité un livre, je pense pourtant… [tronqué]

**4★ n°11 — Lena** (91 j'aime, 2021-08-05)

> Je crois qu'écrire un avis sur un classique absolu est inutile. Je dirai donc seulement que je n'ai été ni impressionnée ni emballée, mais que je l'ai lu avec intérêt. Même si je ne l'ai pas aimé, je reconnais que c'est un chef-d'œuvre absolu.

**4★ n°12 — Celeste** (84 j'aime, 2015-03-17)

> Où en serait la fantasy sans Tolkien ? Il nous a donné le premier monde de fantasy profondément développé, et des clichés de personnages et d'intrigue qui sont toujours des valeurs sûres pour les auteurs de fantasy. Ces clichés sont-ils maintenant usés ? Oui, comme dans d'autres genres. Comme disait le roi Salomon : « Il n'y a rien de nouveau sous le soleil. » Nous réutilisons sans cesse les idées des autres en essayant de les améliorer et de les faire nôtres. Et nous devons à Tolkien beaucoup de ces idées. Je le respecte énormément ainsi que la Terre du Milieu qu'il a créée. Cela dit, j'ai toujours eu du mal avec *Le Seigneur des Anneaux*. Il y a quelque chose dans le style d'écriture de Tolkien (hors son style dans *Le Hobbit*, radicalement différent)… [tronqué]

**4★ n°13 — Mrs.Martos** (99 j'aime, 2022-12-18)

> [Espagnol] « Que les étoiles brillent pour toi jusqu'à la fin du chemin. »

**4★ n°14 — R.K. Gold** (81 j'aime, 2017-12-02)

> C'était attendu depuis longtemps et je suis très content d'avoir enfin lu le premier livre. Je finirai les livres 2 et 3 parmi mes premiers objectifs de 2018. Je n'en dirai jamais assez sur combien j'ai aimé ce livre. C'est toujours amusant de lire sur un personnage en mouvement. L'action constante, même répétitive, comme éviter un sentier et marcher dans les bois pendant deux jours, gardait la narration ancrée, ce qui était important pour montrer l'immensité de la Terre du Milieu. J'aime les films pour eux-mêmes, mais je crois que je préfère Frodon dans les livres. Rien contre la direction de Peter Jackson, mais j'ai trouvé Frodon bien plus mûr et sage dans le livre. [tronqué]

**4★ n°18 — Eric** (59 j'aime, 2017-04-15)

> « Je ne peux pas lire les lettres de feu », dit Frodon d'une voix tremblante. « Non, dit Gandalf, mais moi je le peux. Les lettres sont elfiques, d'un mode ancien, mais la langue est celle du Mordor, que je ne prononcerai pas ici. Mais voici en langue commune ce qui est dit, à peu près : Un Anneau pour les gouverner tous… » [citation du livre (inscription de l'Anneau et poème) ; pas de jugement visible dans l'extrait]

**4★ n°19 — Ashley Marie** (51 j'aime, 2014-03-25)

> Relecture 2020 : une histoire si bien construite. Je l'ai lu pour la première fois il y a une quinzaine d'années, au lycée, et j'ai trouvé tout *Le Seigneur des Anneaux* laborieux. Je n'aimais pas le style d'écriture et je le trouvais alourdi par des détails superflus et de la minutie. Cette fois, l'histoire s'écoule avec danger, intrigue et beauté éblouissante à chaque page. Avoir vu les films un nombre incalculable de fois m'a énormément aidée, car j'ai maintenant des visages chéris pour les noms de ces personnages bien-aimés, et j'ai en tête les passages qui n'étaient peut-être pas dans les films. Quitter la Lórien m'a fait pleurer : les cadeaux de Sam et de Gimli étaient si touchants.

**4★ n°20 — Saadia  B.** (53 j'aime, 2019-06-25)

> 3,5 étoiles. [Résumé de l'intrigue : Bilbon adopte Frodon comme héritier et l'emmène vivre à Cul-de-Sac. Ils préparent leurs anniversaires, le même jour. Bilbon disparaît de sa propre fête grâce à l'Anneau… etc.] [tronqué ; aucun jugement visible dans l'extrait]

**4★ n°21 — Nayra.Hassan** (60 j'aime, 2020-08-05)

> [Arabe] « Ce n'est pas tout vagabond qui est perdu, et ce n'est pas seulement l'incroyant qui dit adieu quand le chemin s'assombrit. » — Combien j'aurais voulu que cela n'arrive pas de mon temps. — Moi aussi, et tous ceux qui vivent pour voir de tels temps, mais ce n'est pas à eux de décider. Tout ce que nous avons à décider, c'est ce que nous faisons du temps qui nous est donné. Ah, combien d'entre nous répètent cette conversation maintenant ! En ces temps difficiles matériellement et psychologiquement, où le gramme d'or augmente de cent livres par jour, qui effraient les jeunes pour leur avenir, attristent les adultes devant un sort inconnu et font regretter aux vieux d'avoir vécu jusqu'ici. Cela explique pourquoi *Le Seigneur des Anneaux* convient à tout lieu et tout temps, comme l'or. Les batailles et aventures de la compagnie de l'anneau d'or enchanté, les neuf, malgré leurs différences, se résument à réaliser la justice, pour que le pouvoir, ou « l'anneau », avec toutes ses tentations, soit entre les mains de qui le mérite… [tronqué]

**4★ n°22 — Roy Lotz** (46 j'aime, 2014-10-14)

> [Satire] Comme on le sait tous, les films du *Seigneur des Anneaux*, réalisés par l'incomparable Peter Jackson, comptent sans conteste parmi les plus grands triomphes artistiques du XXIe siècle. De telles réussites attirent des imitateurs ; les fanfictions abondent, les hommages surgissent partout, et les parodies sont inévitables. Mais l'œuvre la plus notable née de cet engouement est peut-être la série de livres d'un certain J.R.R. Tolkien. Quand j'en ai entendu parler, j'étais intéressé. Une adaptation du film en livre ? Chouette ! Mais comment un auteur, aussi talentueux soit-il, pourrait-il espérer capturer la magie quasi divine des films ? Tolkien s'était fixé une sacrée tâche… [tronqué ; texte ironique qui inverse l'ordre du livre et du film]

**4★ n°23 — Franco  Santos** (46 j'aime, 2014-10-27)

> [Espagnol] Je crois que si quelqu'un prononce le mot « fantasy », la première chose qui nous vient à l'esprit est Tolkien. Alors je ne sais pas ce que je pourrais dire de ce livre. Je pense que tout le monde sait ce que cet auteur représente pour le genre et la littérature. La saga du *Seigneur des Anneaux* est une relique. « Trois Anneaux pour les rois elfes sous le ciel. Sept pour les seigneurs nains dans leurs palais de pierre. Neuf pour les hommes mortels condamnés à mourir. Un pour le Seigneur Ténébreux sur son sombre trône dans le pays de Mordor où s'étendent les ombres. Un Anneau pour les gouverner tous… » [tronqué]

**4★ n°24 — Brittany** (46 j'aime, 2022-07-06)

> 4,5 étoiles ✨ « Un Anneau pour les gouverner tous. Un Anneau pour les trouver. Un Anneau pour les amener tous et dans les ténèbres les lier. » C'était ma première lecture de *La Communauté de l'Anneau*. Je n'avais vu que des morceaux des films au fil des ans et j'avais toujours voulu le lire. Mère de deux garçons de 11 et 13 ans, j'ai décidé d'attendre qu'ils soient assez grands pour le lire avec eux. Je suis si contente de l'avoir fait : ce fut une belle expérience. J'ai adoré voir leurs expressions quand quelque chose de très excitant ou drôle arrivait, et nos discussions sur le livre. Je suis si fière d'eux d'avoir tenu et d'avoir vraiment apprécié le voyage. Notre seule plainte : quelques chapitres très longs qui étaient un peu écrasants, mais c'est Tolkien et il faut… [tronqué]

**4★ n°26 — Marianna Neal** (40 j'aime, 2017-08-20)

> 4,5 sur 5. Évidemment, j'ai adoré ! Sauf Tom Bombadil : je n'ai pas été très fan de cette partie, et je suis contente qu'il ait été laissé de côté dans le film. Et peut-être que le Conseil est un peu trop long et répétitif, mais ça ne m'a pas trop dérangée. Le reste est fantastique ! J'ai vraiment aimé les chansons (je sais que certains les détestent) : elles se lisent comme une belle poésie fantasy et ajoutent à l'atmosphère générale. Je ne vais pas mentir, comme j'avais évidemment vu les films avant de lire (et que j'AIME les films), je ne pouvais pas m'empêcher d'imaginer les personnages comme dans la trilogie, ce qui a rendu le livre encore plus amusant pour moi. Tout le lore détaillé est fascinant… [tronqué]

**4★ n°27 — Danilo** (36 j'aime, 2018-12-10)

> [Serbe/croate] J'ai pris beaucoup plus de plaisir que la première fois, il y a 10-15 ans. J'ai trouvé de la patience pour les chansons, pour chaque repas qu'ils ont cuisiné, les descriptions et les noms, l'introduction sur l'histoire des Hobbits et de la Terre du Milieu, et Tom Bombadil (bon, pour lui peut-être pas). C'est probablement aussi dû à la saison : je ne crois pas que j'aurais lu avec autant de patience au printemps ou en été. L'autre part du plaisir tenait à l'édition : de belles illustrations, une fabrication de qualité (même si je ne suis pas fan du papier brillant de cette édition), la traduction est presque parfaite, sans fautes de frappe : enfin quelqu'un a fait sérieusement son travail.

**4★ n°28 — sissi˚｡౨ৎ** (38 j'aime, 2024-10-21)

> Relecture : il y a juste quelque chose dans le fait d'y revenir. Si douillet, si familier, si nostalgique, si magique. Je l'aime de tout mon cœur. — Avant la relecture : blottie avec ma lecture réconfort ultime parce que je suis très malade et que rien n'apaise l'âme (ou une fièvre) comme un petit voyage en Terre du Milieu.

**4★ n°30 — Dilushani Jayalath** (37 j'aime, 2021-11-21)

> « Un Anneau pour les gouverner tous… » Si vous n'entendez pas ces mots iconiques avec la voix de Cate Blanchett, vous n'avez pas vécu l'une des plus grandes sagas de l'histoire récente. S'il y a quelqu'un parmi nous qui n'a pas vu cette saga épique, j'ai peu de mots pour lui. En tant que geek autoproclamée, *Le Seigneur des Anneaux* fait partie de nos vies. Je suis donc un peu honteuse de n'avoir pas lu l'histoire originale qui a alimenté ce chef-d'œuvre cinématographique. C'est avec encore plus de regret que j'ai lu l'un des plus grands livres que j'aie jamais lus (en partie par mon penchant pour la saga, donc à prendre avec des pincettes)… [tronqué]
