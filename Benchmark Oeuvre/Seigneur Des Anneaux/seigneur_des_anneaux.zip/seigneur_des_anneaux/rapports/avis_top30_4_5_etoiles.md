# Goodreads : les 30 avis les plus en avant à 5★ et à 4★ (*The Fellowship of the Ring*)

Source : API Goodreads, tri par défaut du site (un seul lot de 30 par note). `data/goodreads_communaute_top30_4_5_raw.json` (script : `collecter_top30_4_5.py`). **Ce tri est la « popularité » de Goodreads, pas un classement strict par nombre de « j'aime »** : les avis sont listés ci-dessous dans l'ordre du site, avec leur nombre de « j'aime ».
Extraits de 700 caractères maximum, en langue d'origine (non traduits). **Les avis dont le texte contient des mots qui annoncent la suite de la saga sont retirés de ce fichier** (ils restent dans le JSON) : 5 à 5★ et 10 à 4★. Le filtre est par mots-clés : il peut retirer des avis sans spoiler et en laisser passer certains.

## 5 étoiles — 25 avis affichés sur 30 (total d'avis avec texte à 5★ : 30 602)

**2. Lyndz** — 1601 j'aime, 8 commentaires, 2011-06-08

> I refuse to write a review for one of the best books ever written. Asking a serious fantasy fan to write a review for Lord of the Rings is like asking a Christian to write a review for The Bible. So instead I will supply you with this graph: 

**3. Savage Bookwolf (new Mario the lone bookwolf)** — 439 j'aime, 17 commentaires, 2021-11-05

> Founding a genre like a boss Stealing everything possible from mythology and the, maybe sometimes a tiny bit boring, old, classics. The beloved tradition of using others' ideas to create something new is big here, especially because Tolkien had the perfect background to milk everything from wherever he could find inspirations, from ancient to medieval and, at the time, modern works. It would especially be interesting to read or reread LotR with a focus on how he let the classics mutate to new forms, transformed oldfashioned tropes to fit for a modern audience, and especially made it a compelling, well written, and suspenseful pageturner. Don´t be angry, good old classics, it´s not your fault…

**5. SK ** — 306 j'aime, 67 commentaires, 2022-09-09

> Ahhh this was AMAZING! Why did I not read this sooner? It's just beyond me. The world building is so rich, so immersive, so detailed, it's so easy to get lost in it. Yes the pacing is slower than what I expected it to be but it still continued to keep me interested. I love the characters especially (and obviously) Aragorn. He's just written so perfectly. I might need some more time to warm up to Frodo tho, I preferred the movie version of him. Idk why I thought the book was not going to end on a cliffhanger 😂🤷‍♀️ But can't wait to read the next one. I see why the books are so hyped. ~•~•~ Just watched the movies with my girl @Leonie.. now have got to read the series as well, cause am obsesse…

**6. Saranya [uni- kinda ia]** — 251 j'aime, 63 commentaires, 2026-05-17

> One word: MASTERPIECE. Periodt. I have no idea why I dropped this book the first time around. I must have hit a massive reading slump and lost my momentum, because reading it this time completely blew me away. I should have picked this up sooner! If you haven’t read the book or watched the movies yet, honestly, what are you even doing? Go read it, ASAP. This is high fantasy at its absolute peak. It is a sweeping epic and the foundational blueprint for all modern myth or fantasy making. To think this level of rich, immersive worldbuilding was written all the way back in the 1950s is mind-boggling. Consider me officially converted- I am now one of the biggest Tolkien fans on the planet. Tolkie…

**7. Carolyn Marie** — 243 j'aime, 2 commentaires, 2024-05-11

> This was one of the most enchanting and brilliantly crafted books I’ve ever read! 

**8. Matthew** — 224 j'aime, 26 commentaires, 2013-01-09

> Raise your hand if you remember the awesome book fairs or Scholastic book order forms from back when you were a kid? Well, in middle school I picked up this sweet read in a box set with the rest of the trilogy and The Hobbit. Unfortunately, while I have always been enthusiastic about reading, I did not find the motivation to complete it for almost 15 years. In the early 90s I read the Hobbit. Then I followed it up by starting this one but lost interest shortly after Tom Bombadil. Tolkien is great, but can be a bit much for a middle schooler. Even when I finally did finish it around 2001 (just in time for the movie), it was still a bit of a labor of love. In the end, though - no doubt, 5 star…

**9. Hannah Greendale (Hello, Bookworm)** — 260 j'aime, 18 commentaires, 2015-12-26

>  I have a new BookTube channel! Come find me at Hello, Bookworm 📚🐛 Click here to watch a video review of this book on my (old) channel, From Beginning to Bookend. From the valleys of the Shire to the summit of Amon Hen, The Fellowship of the Ring is an extraordinary adventure of endearing characters defying impossible odds. Here I must confess that the first time I read this book, I was bored by how much time the characters spend walking (and walking, followed by more walking). But every time I read the book, I come to appreciate it more. Tolkien truly was an extraordinary writer. The key to appreciating the Lord of the Rings trilogy is to enjoy it slowly. Don't be in a hurry to get through …

**10. Tharindu Dissanayake** — 206 j'aime, 13 commentaires, 2020-11-11

> "Sing hey! for the bath at close of day that washes the weary mud away! A loon is he that will not sing: O! Water Hot is a noble thing!" "You shouldn't listen to all you hear," When I first watched LOTR TFOTR, a movie that is around 3 hours long, I thought the movie to be insanely long. But now that I've finally gotten around to reading the book, I'm shocked that the movie did manage to fit at least half of the contents of the book in to that three hour run, for this is one long and eventful story with so much more information. "advice is a dangerous gift, even from the wise to the wise," Tolkien was never one to have any kind of limitations when it came to vivid imagination. This is somethi…

**11. Will Byrnes** — 195 j'aime, 39 commentaires, 2008-11-05

> One of the great works of 20th century literature. I first tried this in high school, but was not able to get through on the first try. The second try, in my early 20s was the charm. Frodo goes on a quest that take in issues of morality, friendship, one's responsibility towards others, facing one's fears, courage, danger. While depicting a global battle between good and evil, Tolkien puts a human (or hobbit-ish) face on that conflict. His themes are universal and his characters are very accessible. Frodo, Sam and Gandalf are heroes for the ages, and Gollum is what can happen when normal is corrupted by darkness. This is my favorite series, and taken together with the succeeding pair my favor…

**12. Jaime Fok** — 196 j'aime, 2 commentaires, 2026-01-16

> Only Tolkien could write a 20 page info dump about hobbit lore as a prologue and make me enjoy it. Genuinely the best info dump ever. The way this book goes from high stakes adventure to “hobbits love mushrooms” in the next sentence is something that needs to be studied. It’s whimsical, it’s cozy but also eerie in many moments. Sam & Frodo / Legolas & Gimli are maybe my 2 favourite fictional friendships ever. I am so in love with this world.

**14. Bradley** — 185 j'aime, 13 commentaires, 2013-03-26

> Re-Read 6/29/25 Pulled out my gorgeous hardcover and allowed myself a slow, luxurious, and languorous re-read of one of the best stories ever written. After so many reads, I just gloried in ALL the details, the long histories, even the shapes of all the poetry. It's a well-known path, but welcome and welcoming. Gimli, son of Gloin knows. He knows exactly how I feel. Re-Read 1/7/24: Read with my daughter, aloud, the old way with voice, fresh song, and tears in my eyes. There's nothing quite like reading this one aloud, ourselves. The pacing is just otherworldly -- it forces us into all of nature, of the world itself, and it's shockingly good. And that's well beyond the core story that we know…

**16. Game0ftomes** — 171 j'aime, 0 commentaires, 2024-03-21

> The Fellowship of the Ring is an absolute masterpiece that captivates from the first page to the last. Rich in world building and lore, it introduces readers to Middle earth in all its breathtaking detail, filled with unforgettable characters and epic adventures. The story of Frodo’s quest to destroy the One Ring is both thrilling and deeply emotional, balancing high stakes action with poignant moments of friendship and courage. Tolkien’s writing is beautiful and immersive, making this the perfect blend of fantasy and timeless storytelling. https://www.instagram.com/rocknreadga... 

**17. Jason Koivu** — 164 j'aime, 27 commentaires, 2008-11-23

> Give me a few friends, a stretch of pleasant hills and an ominous wood. Let us romp in the remnants of innocence, free of the fear coursing through the veins of the greater world. Give me the first half dozen chapters of The Fellowship of the Ring and I will gladly make a little heaven on earth out of it. After finishing The Hobbit as a young boy, I needed something else, something a little more mature to meet my growing needs. Lucky for me, Tolkien had done just that in the form of his epic trilogy The Lord of the Rings. Fellowship... , the first book in the trilogy, is my favorite of the three. I fell in love with the four little friends striking out on their own, having adventures and mis…

**18. Alexia** — 154 j'aime, 71 commentaires, 2026-06-28

> I watched the movies during my childhood and loved them; however, while the films do a commendable job of capturing the essence of the story, the book is, as is often the case, far more detailed and richer in content. The world the author created is nothing short of magnificent, with intricate details and vivid descriptions that bring it vividly to life. Every time the author revealed another detail about Middle-earth, it provided a comforting sense of belonging and familiarity. The way he described elves, hobbits, dwarves, and men was brilliant, showcasing his mastery of world-building. Each race possesses unique customs, traditions, and cultures so distinct from one another that I found my…

**20. Manny** — 139 j'aime, 45 commentaires, 2017-10-18

> My education as a young German continues. I have been able to read children's books easily for some time, but books for grown-ups are still challenging. I thought that reading The Lord of the Rings in translation might be helpful, since for me it's intermediate between children's literature and adult literature. The vocabulary and grammar are more like adult literature; but the writing is concrete and straightforward as children's literature tends to be, with little of the abstractions, generalisations and complicated narrative structures that characterise adult fiction. I think it's worked well, and I could positively feel the book stretching my vocabulary. But most importantly, it's increa…

**21. Maddie Fisher** — 143 j'aime, 1 commentaires, 2025-02-12

> This is where my love of fantasy began. Tolkien is the foundational author of epic fantasy worlds, and to this day, I've yet to read his equal for world-building. Middle Earth's geography, history, peoples, languages, and cultures feel as real to me as the world we live in. He built the original found family—the fellowship embodies the acceptance, sacrifice, protection, honor, duty, and purpose that I hold every other band of heroes to. This foundational quest has the stakes, the tension, the stacked odds, and the desperate hope that every other quest aspires to. This book is the answer to the question "Why do you read" and it is the standard to which I compare all other epic fantasy books. …

**22. Rebecca** — 151 j'aime, 31 commentaires, 2024-12-21

>  ‘All that is gold does not glitter, Not all those who wander are lost; The old that is strong does not wither, Deep roots are not reached by the frost. From the ashes a fire shall be woken, A light from the shadows shall spring; Renewed shall be blade that was broken, The crownless again shall be king.’ If you’re into epic adventures, a lovable band of misfits, and a good sprinkle of magical chaos, The Fellowship of the Ring is your jam. Tolkien kicks off The Lord of the Rings trilogy with a story so rich in world building that you can almost feel the grass of the Shire under your feet and smell the orc breath in Moria (though, honestly, you might not want to). The book starts with Frodo Ba…

**23. Jo ** — 132 j'aime, 11 commentaires, 2017-01-21

> This was my fourth or fifth read through, and to be frank, it was most definitely the best read through.

**24. Henry Avila** — 122 j'aime, 10 commentaires, 2022-12-07

> A book read by a person three times,( I) need not say that its good , the obvious is apparent to all. Such is the first novel of the brilliant, The Lord of the Rings...The Fellowship of the Ring. Frodo Baggins nephew (cousin in reality) that was adopted by Mr. Bilbo Baggins , reluctantly follows in his shaky footsteps from the peaceful Shire where nothing happens, to the little Hobbits half the size of humans, but with a bigger heart. Joins through the epic fight against the Dark Lord Sauron, under the direction of the mysterious , grand, remote wizard Gandalf the Grey, the other Hobbits in Hobbiton feel the Baggins are strange people their wanderings are not normal in the almost perfect pla…

**25. Anish Kohli** — 109 j'aime, 41 commentaires, 2017-07-24

> One does not simply review the LOTR!! Yet here I am, trying to do so. In the words of Sam-the-wise Gamgee, I can sum up my review. “Oh, that doesn’t do them justice by a long road.” This was a BR with The one who DNF’d it and The one who didn't like it . Non believers, I tell you! I have taken my own sweet time with this book, relishing each of its pages and words and watching the movie as I read the book. It has been a great time! “Is it not a strange fate that we should suffer so much fear and doubt for so small a thing?” It is Bilbo Baggins’ eleventy first (111th) birthday. All of the Shire is invited to celebrate the event of a queer hobbit who is rumored to have immense treasures accumu…

**26. Anna [Bran. San. Stan]** — 115 j'aime, 35 commentaires, 2024-03-24

> 2025: First reread! 2024: Rare are the books that put me in my special happy place; books that give me that fuzzy, comfy feeling and just, well, make me happy to be in that world. The Fellowship of the Ring does just that; the magic of the story was such that being part of Frodo’s journey was nothing short of wonderful, as in full of wonders, and it left me with that sense of wonder long after I finished reading for the day. To be honest, I never expected to love this that much, especially since my previous attempts had failed. I‘m now glad that I didn’t force myself to finish this book ten years ago, or worse, twenty years ago. I was not ready then and I couldn’t have appreciated it. What I…

**27. Dream.M** — 110 j'aime, 12 commentaires, 2022-08-28

> آقا! فتبارک الله احسن الخالقین که میگن همینه . یعنی چی که این کتاب اینقدر خوب نوشته شده؟ مگه میشه یک دنیایی رو از هیچی با این جزئیات و منطق خلق کرد؟ تالکین بخدا تو آدم نیستی. یا یه چیزایی دیدی و میدونی که بقیه آدم ها ندیدن. ... من کتاب صوتیش رو از فیدیبو دوستم گوش دادم. دمش گرم♡ بسیار بسیار انتخاب خوبی بود نسخه صوتی، چون علاوه بر لذت بردن از خود داستان جذابش، صدای خفن راوی و لحن روایت فوق العاده سکسی اش توی یه بعد دیگه ای عالی بود و کیف داد. ... قطعا خوندن سیلماریلیون و دیدن فیلم هاش باعث شد بیشتر کتاب رو بفهمم و بیشتر لذت ببرم

**28. Kimberly ** — 107 j'aime, 1 commentaires, 2022-06-30

> I read this decades ago and it somehow found its way to my currently reading list. I think everything possible has been said about this story. It enthralled me and brought me into Tolkien's world with nary a bit of struggle. Thank goodness!

**29. Julie  G** — 113 j'aime, 30 commentaires, 2025-12-20

> I reread THE HOBBIT last year with my youngest child (my 15-year-old), and I was quite pleased when she became an instant fan of the story. I’d never ventured into the actual trilogy, despite having seen all of the movies. I’ll be honest, though, I watched the movies for one reason: Viggo Mortensen. If you’d asked me what else was going on in the story, I’d probably have said, “His eyes.” So, two months ago, this same daughter of mine asked if we could try the first book in the trilogy. I was in the middle of a huge book, so I suggested that she read it alone, but she failed before the first chapter. She shared that she couldn’t understand a lot of the words. If you’ve read it, you get it. T…

**30. فؤاد** — 103 j'aime, 17 commentaires, 2016-05-25

> من از سیزده چهارده سالگی رؤیای ارباب حلقه ها را داشتم. اولین بار بخش های پراکنده ای از فیلمش را در تلویزیون دیدم: موجوداتی کوتوله ساکن روستایی زیبا، با جادوگری پیر که آتش بازی راه می اندازد، و حلقه ای شیطانی که آرامش دنیای داستان را بر هم می زند، و سواران تاریک، و چشم آتشینی که همواره ناظر است. هر چند هیچ وقت نتوانستم تمام سه گانه را ببینم، ولی همین عناصر به قدری تخیل نوجوانانه ام را تهییج کرد، که همیشه سر در آوردن از ماجرای کامل کوتوله ها و حلقه ی شیطانی، یکی از حسرت هایم باقی ماند. گذشت تا این که در دوره ی دبیرستان، یکی از رفقایم کتاب را می خواند و با هم راجع به آن صحبت می کردیم. صحبت که نمی کردیم. بیشتر او تعریف می کرد و من مجذوب و مجذوب تر می شدم. کتاب دم دستم بود، و من هم خوره ی کتاب بو…

## 4 étoiles — 20 avis affichés sur 30 (total d'avis avec texte à 4★ : 15 883)

**4. Matt's Fantasy Book Reviews** — 326 j'aime, 12 commentaires, 2021-11-17

>  Check out my YouTube channel where I show my instant reactions upon finishing reading fantasy books. While the writing style is quite outdated, this book still is a joy to read for first-time readers While it may be hard to believe for someone who exclusively reads fantasy books, I actually didn't read this book until very recently. I just wasn't into fantasy as a child, and when I got into it as an adult I figured this book wouldn't catch my interest. And while I did not enjoy this book nearly as much as the fanatics who claim this is the greatest fantasy story every told, it was a worthwhile read that still holds up today in many regards. You do have to constantly remind yourself of the y…

**6. Lyn** — 136 j'aime, 21 commentaires, 2011-07-30

> Tonight on Anderson Cooper 360, we find ourselves in Murfreesboro, Tennessee and at The Green Dragon Public House and Brewery , a Tolkien inspired pub. Our special guest tonight is none other than THE Hobbit, Mr. Bilbo Baggins, formerly of the Shire. We’ll have a moment to get to know the individual that has meant so much to generations of literary fans and then to a new generation of movie going fans in this last decade. Bilbo, how are you tonight? Bilbo Baggins: I’m well; thank you, Anderson, and how about yourself? Anderson Cooper: I’m fine, thanks. Tell me, what was it like working with Peter Jackson? BB: What’s not to like? He’s a consummate professional, with great attention to detail …

**7. James** — 133 j'aime, 6 commentaires, 2012-01-08

> 4+ out of 5 stars to The Fellowship of the Ring , J.R.R. Tolkien 's first novel in the "Lord of the Rings" trilogy, later made into a billion dollar movie franchise. I count myself lucky to have been able to read this book before it became a movie, though I loved the movie, too. Why This Book I was 13 years old when I stumbled upon this book while a friend was reading it. He was a major video gamer, fantasy sports leaguer and avid reader of science fiction. Though we were good friends, I had different hobbies. He was about a third of the way into the book, talking about Bilbo, Frodo and Gandalf... and I think my response was something like... "but what about the lions, bears and tigers... oh…

**9. Gillian** — 108 j'aime, 36 commentaires, 2022-10-31

>  “One Ring to rule them all. One Ring to find them. One Ring to bring them all and in the darkness bind them.” 4.5 stars! This was an action-packed and epic fantasy about friendship, power, choosing your path, and resilience in the face of challenges. The Fellowship of the Ring follows Frodo Baggins, a hobbit and cousin of Biblo as he goes on an epic journey to destroy a powerful ring and prevent the Dark Lord from fulfilling his plans. Along the way Frodo meets new friends and faces several challenges. This book was so good! The pacing in the beginning was slow, but once the pace picked up I was completely immersed in the fantastic and detailed world that the author created. The world build…

**10. Sara Kamjou** — 104 j'aime, 0 commentaires, 2017-02-27

> فیلم ارباب حلقه‌ها رو حدودا سه سال پیش دیدم و با اینکه خیلی مشتاق بودم کتابش رو بخونم، تصمیم گرفتم صبر کنم تا تصویر فیلم با وجود فوق‌العاده بودنش تو ذهنم کمرنگ بشه تا مانع این نشه که ذهنم با خود کتاب به صورت خلاقانه تصویرسازی کنه. ارباب حلقه‌ها قطعا یه کتاب نیست، یه دنیاست! دنیایی کامل و منحصر به فرد که تالکین ماهرانه به پا کرده. تو این دنیا هر چیزی سر جای خودشه و هیچ‌وقت احساس نکردم چیزی اضافیه یا بود و نبودش فرقی نداره. داستان حول محور حلقه‌‌های قدرت هست که از بین بیست حلقه، یکی که از همه شیطانی‌تره بر اساس داستانی که به کتاب هابیت برمی‌گرده به دست فردو افتاده. یاران حلقه داستان حامل حلقه‌ست و ماجراهایی که در این بین اتفاق میفته. گرچه ارباب حلقه‌ها در واقع یه کتابه، با این حال من فکر می‌کن…

**11. Lena** — 91 j'aime, 2 commentaires, 2021-08-05

> I believe writing a review on ultimate classic is pointless. So I'll just say that I wasn't impressed or exited but read it with interest. Although I didn't love it I would I agree its an absolute masterpiece. 

**12. Celeste** — 84 j'aime, 12 commentaires, 2015-03-17

> Where would the fantasy genre be without Tolkien? He gave us the first deeply developed fantasy world, and character and plot tropes that are still go-tos for fantasy writers. Are these tropes now overused? Yes, as are tropes in other genres. As King Solomon said, “There’s nothing new under the sun.” We are constantly reusing the ideas of others while trying to improve upon them and make them our own. And we have Tolkien to thank for many of those ideas. I respect him and the Middle-Earth he created immensely. All that being said, I have always struggled with The Lord of the Rings . There’s something about Tolkien’s style of writing (excepting his style in The Hobbit , which is radically dif…

**13. Mrs.Martos ** — 99 j'aime, 0 commentaires, 2022-12-18

> "Que las estrellas brillen para ti hasta el final del camino."

**14. R.K. Gold** — 81 j'aime, 4 commentaires, 2017-12-02

> This was long overdue and I am so happy to have finally read the first book. Finishing Books 2 and 3 will be among my early goals of 2018. I can't say enough about how much I loved this book. It's always fun to read about a character who is on the move. The constant action, even if it's as repetitive as avoiding a trail and walking through the woods for two days, kept the narration grounded, which was important in painting a picture of how vast middle earth was. I love the movies in their own right, but I think I prefer Frodo in the books over the movies. Nothing against the direction Peter Jackson took it, I just thought Frodo came across as far more mature and wise in the book. We had the …

**18. Eric** — 59 j'aime, 5 commentaires, 2017-04-15

>  'I cannot read the fiery letters,' said Frodo in a quavering voice. 'No,' said Gandalf, 'but I can. The letters are Elvish, of an ancient mode, but the language is that of Mordor, which I will not utter here. But this in the Common Tongue is what is said, close enough: One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them. It is only two lines of a verse long known in Elven-lore: Three Rings for the Elven-kings under the sky, Seven for the Dwarf-lords in their halls of stone, Nine for Mortal Men doomed to die, One for the Dark Lord on his dark throne In the Land of Mordor where the Shadows lie. One Ring to rule them all, One Ring to find …

**19. Ashley Marie ** — 51 j'aime, 12 commentaires, 2014-03-25

> 2020 reread: Such a well-crafted story. I first read this fifteen-ish years ago, in high school, and found the whole LOTR book a slog. I disliked the writing style and found it bogged down with extraneous details and minutiae. This time through, the story flows along with danger and intrigue and stunning beauty on every page. Having seen the films a gazillion times helped immensely because now I have cherished faces for the names of these beloved characters, and I now have the bits in my mind that may not have made it into the films. Parting from Lothlorien made me cry - Sam and Gimli's gifts were so touching.

**20. Saadia  B.** — 53 j'aime, 0 commentaires, 2019-06-25

> 3.5 Stars Bilbo adopted Frodo as his heir and brought him to live at Bag End. They both were planning for their birthdays which came on the same day. Bilbo vanished from his own party with the help of the Ring, as he wanted to go for a long holiday without informing anyone. He left the Ring for Frodo among other things, on Gandalf's suggestion. The Ring belonged to the Dark Lord which upon his capture came into Gollum's hands, he called it his Precious. It was a wretched Ring of Power and always looked after itself. Sauron the Dark Lord had risen and returned to the Dark Tower of Mordor. Frodo, the ring bearer, after Bilbo Baggins was given the task to take the Ring to Mordor in order to des…

**21. Nayra.Hassan** — 60 j'aime, 7 commentaires, 2020-08-05

>  ليس كل من تجول:تاه وعديم الإيمان فقط هو من يقول وداعا عندما يُظلم الطريق كم كنت أتمنى ألايحدث ذلك في زمني_ وأنا كذلك،وكذلك يفعل كل من يعيش- ليري مثل هذه الأوقات لكن هذا ليس لهم أن يقرروه كل ما علينا أن نقرره هو ما يجب أن نفعله بالوقت المتاح لنا ياااااه كم منا يردد هذه المحادثة الان؟ في تلك الاوقات الصعبة مادياً و نفسياً ؛ الازمنة التي يزداد فيها جرام الذهب مائة جنيه يومياً؛ ازمنة ترعب الشباب علي مستقبلهم و تكدر الكهول من مصير مجهول؛ و تحسر الشيوخ انهم عاشوا ليروا هذا الزمن و هذا يوضح لنا لماذا تصلح سيد الخواتم لكل مكان و زمان كالذهب تماما فالمعارك و المغامرات التي عاشها صحبة الخاتم الذهبي المسحور التسعة علي اختلافهم؛ تلخصلت في تحقيق :العدل لتكون السلطة او"الخاتم" بكل اغرائاته في يد من يستحق…

**22. Roy Lotz** — 46 j'aime, 6 commentaires, 2014-10-14

> As we all know, the Lord of the Rings movies, directed by the incomparable Peter Jackson, are easily among the greatest artistic triumphs of the 21st century. Such magnificent accomplishments often attract imitators; fan fiction abounds, tributes crop up left and right, and parodies are inescapable. But perhaps the most notable piece of artwork to come from the post-LOTR crave is the book series by one J.R.R. Tolkien. When I first heard of it, I was interested. A book adaptation of a movie? Neat! But how could any author, however skilled, hope to capture the almost divine magic of the films? Tolkien had set himself quite a task. A book version of, say, The Shining or One Flew Over the Cuckoo…

**23. Franco  Santos** — 46 j'aime, 1 commentaires, 2014-10-27

> Creo que su alguien menciona la palabra fantasía lo primero que se nos viene a la cabeza es Tolkien. Así que no sé qué podría decir de este libro. Pienso que todos saben lo que significa este autor para el género y la literatura. La saga de El Señor de los Anillos es una reliquia. «Tres Anillos para los Reyes Elfos bajo el cielo. Siete para los Señores Enanos en palacios de piedra. Nueve para los Hombres Mortales condenados a morir. Uno para el Señor Oscuro, sobre el trono oscuro en la Tierra de Mordor donde se extienden las Sombras. Un Anillo para gobernarlos a todos. Un Anillo para encontrarlos, un Anillo para atraerlos a todos y atarlos en las tinieblas en la Tierra de Mordor donde se ext…

**24. Brittany** — 46 j'aime, 10 commentaires, 2022-07-06

> 4.5 Stars ✨ “One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.” This was my first time reading FOTR. I’ve only seen bits and pieces of the movies over the years and have always wanted to read it. As a mother of two boys 11&13, I decided to wait until they were old enough to buddy read it with them. I’m so glad I did - it was a great experience. I loved seeing their expressions when something really exciting or funny happened and having LOTR book chats. I’m so proud of them for sticking with it and actually enjoying the journey. Our only complaint was a few super long chapters that were a little overwhelming, but it’s Tolkien and you h…

**26. Marianna Neal** — 40 j'aime, 2 commentaires, 2017-08-20

>  4.5 out of 5 stars Obviously, I loved this! Except for Tom Bombadil—wasn't a big fan of that part, and I'm glad he was left out of the movie. OK, and maybe the council is a little too long and repetitive, but it really didn't bother me too much. The rest is fantastic! I actually really enjoyed the songs (I know some people hate them)—they read as this beautiful fantasy poetry, adding to the overall atmosphere. Not going to lie, since I obviously saw the movies before reading (and I LOVE the movies), I just couldn't help picturing the characters as they were portrayed in the movie trilogy, which actually made the book even more fun for me. All of the detailed lore is fascinating, and as far …

**27. Danilo** — 36 j'aime, 0 commentaires, 2018-12-10

> Mnogo sam više uživao nego kad sam prvi put čitao pred 10-15 godina. Našao sam strpljenja i za pesme, za svaki ručak koji su skuvali, opise i imena, uvod o istoriji Hobita i Srednje Zemlje, Toma Bombadila (dobro, za njega možda i nisam). Verovatno je i do godišnjeg doba, ne verujem da bih čitao ovako strpljivo da je proleće ili leto. Drugi deo uživanja je bilo u izdanju. Lepe ilustracije, kvalitetna izrada (mada ja i nisam fan sjajnog papira koji se u ovom izdanju koristi), prevod je skoro perfektan, nema slovnih grešaka, napokon je neko ozbiljno uradio svoj posao.

**28. sissi˚｡౨ৎ** — 38 j'aime, 12 commentaires, 2024-10-21

> ˏˋ°•*⁀➷ Reread there’s just something about coming back to this. so cozy, so familiar, so nostalgic, so magical. i love this with my whole heart. __________________________________ ˏˋ°•*⁀➷ Pre-Read Curled up with my ultimate comfort read because I’m very sick and nothing soothes the soul (or a fever) like a little journey through Middle-earth.

**30. Dilushani Jayalath** — 37 j'aime, 1 commentaires, 2021-11-21

>  "One Ring to rule them all, One Ring to find them One Ring to bring them all and in darkness bind them." If you cannot hear the above iconic words in Cate Blanchett's voice, you have not lived through one of the greatest sagas of the recent past. If there is any among us who have not watched this epic saga, I have few found words to tell them. As a self proclaimed geek, LOTR as it's fondly called is part of our lives. So I am somewhat ashamed to say that I had not written the original story that fuelled this ultimate motion masterpiece. It is with further grief I read along, one of the greatest books I've ever read (This is partly due to my bias towards LOTR so do take it with a grain of sa…
