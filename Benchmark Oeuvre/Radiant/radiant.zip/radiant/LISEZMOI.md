# Radiant (manga de Tony Valente) : données et extraits

## rapports/
- `Radiant_extraits_fiches_oeuvres.md` : les passages sur Radiant copiés tels quels depuis `fiches_oeuvres_v3.md` (fiche et « Force et Faiblesse enrichies ») et depuis ton fichier d'origine `fiches_oeuvres (2).md` (Radiant et cas Seth / Killua). Aucun texte réécrit.

## donnees/ (avis bruts, avec noms d'utilisateurs)
- `goodreads_radiant_t1_t3_raw.json`, `goodreads_radiant_t4_t6_raw.json` : avis Goodreads des tomes 1 à 6.
- `goodreads_full_parsed.json`, `gr_ep_raw.json` : avis Goodreads des tomes 1 à 3 (version analysée et brute).
- `critiques_manga_autres_sites_raw.json`, `senscritique_raw.json` : autres sites (Manga-News, SensCritique, magazines).
- `codage_critiques_radiant_manga.json` (303 avis codés) et `codage_critiques_radiant_anime_MAL.json` (48 avis de l'anime sur MyAnimeList, codés).

## Non inclus
- `coffre/radiant_apres_tome6.md` : contenu au-delà du tome 6 (ta limite anti-spoil).
- Les mentions de Radiant dans le YAML, la vue, `DECISIONS_RECENTES`, `tester_fiches.py` : quelques lignes parmi d'autres œuvres.
