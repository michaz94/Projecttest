# Radiant : extraits des fiches d'œuvres (verbatim)

Extraits copiés tels quels, sans réécriture. Limite anti-spoil : fin du tome 6.

---

## A. `fiches_oeuvres_v3.md` : fiche Radiant (lignes 837 et suivantes)

# Radiant — 2013 🔒

*Tony Valente · Ankama Éditions · depuis le 4 juillet 2013 · **19 volumes** en français (le **tome 20** est annoncé pour le **30 octobre 2026**) ✅ · plus d'un million d'exemplaires, 20+ langues · **premier manfra publié au Japon** (2015, Euromanga / Asukashinsha) · Viz Media en anglais · anime de 42 épisodes (Lerche) sur NHK Educational TV, **6 oct. 2018 – 26 févr. 2020** ✅ : saison 1 (21 ép., oct. 2018 – févr. 2019) = **tomes 1 à 4** ✅ ; saison 2 (21 ép., oct. 2019 – févr. 2020)*

> ## ⚠️ LIMITE ANTI-SPOIL — **fin du tome 6**
> La fiche couvre les **tomes 1 à 6**, soit environ le premier tiers de la saison 2.
> **Sont exclus et non nommés :** tout ce qui relève des **tomes 7 et suivants**.
> **Correction :** la v1 contenait, dans ce même encadré, des **noms hors limite** — contradiction avec la règle. Ils sont retirés ; aucun équivalent n'est donné.
> **Dis-moi quand tu passes au tome 7.**

**Genres / tags :** Shōnen / Nekketsu, Aventure, Fantasy, Comédie, **Steampunk partiel** (Rumble Town, ère industrielle)

**Goal :** **Trouver le Radiant**, le berceau légendaire des Némésis, pour les détruire et mettre fin à la malédiction des Infectés. Clair, personnel, choisi — de la même famille que FMA (« défaire quelque chose »).

**Éléments distinctifs :**
- **Les Némésis** — créatures tombées du ciel, sources de l'infection
- **Les Infectés** — survivants d'un contact avec un Némésis, capables de manipuler le **Fantasia**, mais **stigmatisés et persécutés**
- ⬅ **Seth est le seul sorcier capable de manipuler le Fantasia sans outil.** Tous les autres ont besoin d'un instrument.**
- **Les cornes de Seth** — marqueur visuel du héros, **stigmatisant** (« le cornu ») : signature et exclusion sont le même signe
- **L'Inquisition** — l'autorité persécutrice ; **l'Ordre des Chevaliers-Sorciers** ; **l'Institut Artémis** — grand repaire de sorciers
- **Master Lord Majesty** (le roi chat) · **Draccoon** · **Yaga**, le maître · **la Bravery Quartet**
- **Cyfandir / Caislean Merlin**, l'îlot-continent des chevaliers-sorciers · **la reine Boadicée**
- ⬅ **Les Némésis Spectraux** (tome 6) : nouvelle classe d'ennemis qui apparaît partout sur Cyfandir et plonge Seth au cœur d'une **machination**, la suspicion gagnant le château lui-même
- **Les Barons-Marchands** — présents et mystérieux dès le tome 6 ; leur rôle reste à préciser
- **Lord Brangoire** · les capitaines **Dragunov** et **Liselotte** se lancent aux trousses de Seth

**Emprunts culturels (par échelle) :** ⬅ *le cas qui inverse le sens habituel*
- *forme industrielle* : un auteur **français** qui emprunte le shōnen nekketsu japonais dans ses codes entiers — publié à Tokyo, adapté par la première chaîne publique japonaise. **Toutes les autres œuvres empruntent un contenu ; Radiant emprunte une forme industrielle.** Seul cas avec lequel la grille doit distinguer *forme* et *matière*.
- *folklore* : **celtique et irlandais** — *Caislean Merlin* (« château de Merlin »), **Boadicée** (reine celtique historique), le **Dullahan** (figure du folklore irlandais), Caillte.
- *actualité* : la persécution des sorciers est explicitement inspirée du climat français contemporain (déclaration de l'auteur 🔎 source à retrouver).

**Peak de l'œuvre :** ❌ **donnée manquante.** Aucun sondage d'arcs (pas de sondage d'éditeur de type Shōnen Jump). Aucun classement n'est proposé.

**Personnages les plus appréciés :** ❌ **donnée manquante.** Les seules mesures publiques sont des notes par tome (SensCritique & cie), qui mesurent l'œuvre, **pas les personnages**.

**Personnages (dans la limite, tomes 1-6) :**

| | Profil |
|:---|:---|
| **Seth** | Infecté aux cornes, seul à manipuler le Fantasia sans outil |
| **Mélie** | sorcière au « dédoublement de personnalité » : douce, timide, serviable dans son état premier ; **agressive, grossière et hautement compétente au combat** quand le stress ou le combat la déclenche. Compagne la plus loyale de Seth, « ciment émotionnel du groupe » |
| **Doc** | amitié réticente et chamaillée, d'abord purement intéressé ; découvre progressivement la loyauté |
| **Alma** | mère adoptive et mentor ; sorcière respectée, a perdu un bras ; « son rôle est d'abord celui d'un guide » |
| **Piodon** | **frère de Seth**, de la même lignée à cornes ; lien « mystérieux et antagoniste » ; sa nature est explicitée au tome 5 |
| ⬅ **Ocoho** | Entrée au chap. 33 / ép. 22 **par le camp de l'autorité** (aspirante de l'Ordre). Elle est le **Dullahan**, figure de superstition de Cyfandir. **Son infection : quiconque presse le grain de beauté derrière son cou peut lui ordonner n'importe quoi, et elle n'en garde aucun souvenir.** C'est ainsi qu'elle attaque Mélie, avant que Seth ne l'arrête. **Elle rejoint le groupe à la fin de l'arc de Caislean Merlin** (tome 6) |

**Schéma narratif répété :**
1. Arrivée dans un lieu-refuge de sorciers → **autorité locale hostile**
2. L'autorité se révèle ambiguë — Valente refuse le tout-blanc / tout-noir : « ses personnages ne sont ni tout blancs ni tout noirs et ont leurs propres motivations »
3. Intervention de Seth, qui déborde le cadre et se met tout le monde à dos
4. Fuite → lieu suivant
5. **L'enquête et le combat alternent** : Seth cherche des textes sur le Radiant autant qu'il se bat

**Force :** La stigmatisation n'est pas un décor mais **le moteur** : chaque lieu la rejoue sous une forme nouvelle, ce qui donne une unité thématique à un récit de voyage par ailleurs épisodique ; **les antagonistes ont des motivations** — refus constant du manichéisme ; le héros porte **la marque de son exclusion**, ce qui rend le thème visible en permanence ; format et clarté du nekketsu, avec un traitement plus appuyé de la différence et de l'exclusion.

📚 **Ce que disent les lecteurs — vision globale** (Goodreads, Babelio, Manga-News, SensCritique, avis en espagnol, ukrainien, allemand, croate, portugais, indonésien…, Reddit, sites sur l'anime). Chaque extrait est entre guillemets, avec sa source, le tome et la note du lecteur quand elle existe ; « trad. » = traduit par moi. **Tout ce qui porte sur les tomes 7 et suivants ou sur l'ensemble de la saison 2 de l'anime est volontairement absent d'ici : c'est rangé dans `coffre/radiant_apres_tome6.md`.**

- **Un manga français qui se lit comme un manga japonais.** Éloge très fréquent, souvent dès la première phrase : « Ils sont rares, voire inexistants, les shonen français dont on peut dire que visuellement ils reproduisent à la quasi perfection le trait de leurs homologues japonais » *(SensCritique, T1, 7/10)* ; « l'auteur maîtrise son trait à la perfection, nous offrant des planches vraiment riches en détails (rares sont les cases blanches) » *(Manga-News, T1, 15/20)* ; « l'artwork est sublime : un artiste français qui a saisi l'essence de l'art japonais à la perfection tout en y ajoutant des influences de la BD occidentale » *(Goodreads, T1, 5/5, trad.)*. Même un lecteur peu adepte du genre le reconnaît : « moi qui ne suis pas particulièrement adepte de l'univers manga, je dois quand même reconnaître que l'on assiste à du bel ouvrage » *(Babelio, T3, 4/5)*. Le dessin est salué sur la durée : « le trait de l'auteur se fait vraiment de plus en plus classe et plus en plus pop » *(Babelio, T4)* ; « Les dessins de Tony Valente sont vraiment le gros plus de cette saga. » *(Babelio, T6)* ; « le dessin de Tony Valente est l'un des meilleurs que j'aie vus dans un shōnen » *(Goodreads, en espagnol, T3, 4/5, trad.)* ; « Tony Valente est spectaculaire et assure toujours à 100 % » *(Goodreads, en espagnol, T5, trad.)*. Les pages en couleurs reviennent souvent : « une action tjrs aussi fluide tant dans le dessin que dans la narration et de très belles pages couleurs » *(Manga-News, T2, 17/20)* ; « les scènes en couleurs sont incroyables ! » *(Reddit r/manga, trad.)*.
- **Un humour qui vient de chez nous.** Plusieurs lecteurs francophones y voient un vrai atout, parce que les jeux de mots passent sans note de traduction : « pour une fois dans un manga on se passe de traduction » *(Babelio, T1, 5/5)* ; « Les réparties de certains personnages -je pense notamment à Alma- sont de vraies pépites mêlant sarcasme et ironie comme on aime si bien le faire en France » *(Babelio, T1, 5/5)* ; « L'humour est sans doute le gros point fort de cette série. Tony Valente fait preuve d'un véritable tempo comique. » *(Babelio, T1, 4/5)*. Mélange avec le drame : « L'humour et le drame se succèdent et toujours avec un savoir-faire exceptionnel. » *(Manga-News, T4, 19/20)* ; « un humour simple et franc mêlé à une critique sociale très dure, ce qui est très appréciable » *(Goodreads, en espagnol, T2, 4/5, trad.)*.
- **Un univers et un thème pris au sérieux.** « Cette approche de la magie étant assez originale » *(Babelio, T1, 5/5)* ; « des questions actuelles, politiques et morales sont habilement glissées par le mangaka » *(Babelio, T1, 5/5)* ; sur le traitement de l'intolérance : « c'est dénoncé comme il le faut, et bien traité » *(Babelio, T2, 4.5/5)* ; « Ce monde est mystérieux, et super intéressant. » *(SensCritique, T3, 9/10)*. Des lecteurs réservés sur le reste le disent aussi : « Radiant a une magie et un lore fascinants, avec un monde intéressant derrière » *(Goodreads, T1, 3/5, trad.)*. L'imaginaire s'élargit au fil des tomes : « Tony Valente arrive à se renouveler en élargissant fortement le périmètre du monde de son manga » *(Babelio, T5)* ; « un bel imaginaire où clichés et inventions se mélangent bien et offrent surtout des planches splendides » *(Babelio, T5)*.
- **Des antagonistes qui ont leurs raisons** (ce qui rejoint ta remarque) : « Les ennemis ont des raisons tout à fait valables pour être mauvais, ils défendent une cause respectable. » *(Manga-News, T4, 18/20)* ; « Les scènes, drôles, tristes, dramatiques, épiques, etc... sonnent très juste et humanisent petit-à-petit les personnages pour les éloigner de leurs archétypes standards » *(Manga-News, T4, 18/20)*.
- **Une action lisible et spectaculaire.** « les scènes d'action sont très fluides et agréables à lire, et les personnages évoluent vraiment » *(Reddit r/manga, trad.)* ; « Les moments de bastons pures sont explosifs et immersifs. » *(Babelio, T4)* ; « des scènes de bataille spectaculaires qui saturent la rétine » *(Goodreads, en espagnol, T3, 4/5, trad.)* ; « L'auteur n'est jamais meilleur que dans ces scènes là. » *(Babelio, T6)*
- **Un premier tome qui avance.** « On reproche aux premiers tomes de ne pas avancer. C'est tout le contraire avec Radiant ! » *(Babelio, T1, 5/5)* « Ce premier volume est clair, limpide tout en présentant efficacement son background. » *(Babelio, T1, 4/5)*
- **Un ton qui surprend.** « Ce qui va différencier Radiant de Dragon Ball ou Naruto, c'est son ton. Tour à tour humoristique et tragique, il prend à contre-pied les lecteurs » *(Babelio, T1, 5/5)*
- **Des personnages attachants, surtout les seconds rôles.** « Alma m'a impressionnée dès son apparition » *(Babelio, T1, 4/5)* ; un lecteur salue Seth pour ce qu'il n'est pas : « Seth est un héros intéressant : il n'est pas surpuissant et il est « un peu mais pas trop » arrogant » *(Goodreads, T1, 4/5, trad.)*. Au tome 2, Grimm et Dragunov ont « une classe absolue » *(Manga-News, T2, 17/20)* ; au tome 3 : « Dart Dragunov est clairement en haut de ma liste de personnages préférés » *(Goodreads, T3, 4/5, trad.)*. Un héros qui évolue : « le héros commence idiot mais grandit en intelligence, sur le plan émotionnel et physique » *(Reddit r/manga, trad.)* ; un lecteur ukrainien, d'abord agacé : « au début de l'histoire, le héros m'énervait en permanence » *(Goodreads, en ukrainien, T1, 4/5, trad.)*, puis « vers la fin, les blagues idiotes ne semblent plus telles » *(Goodreads, en ukrainien, T1, 4/5, trad.)*. « plus on avance plus la série prends de relief, et plus on s'attache à ces personnages » *(Babelio, T6)*.
- **Une série qui monte en puissance.** « La série se bonifie au cours de ce tome 2. » *(Babelio, T2, 4.5/5)* « le deuxième tome a sauvé la série pour moi : les personnages gagnent en profondeur, ce qui les distingue des autres personnages de manga » *(Goodreads, T2, 3/5, trad.)* « Je trouvais que la série décollait avec le tome précédent, je le confirme, elle a pris son envol » *(Babelio, T4)* ; « Très joli rebonds pour la série que ce tome 5 qui retrouve l'équilibre action/aventure/humour. » *(Babelio, T5)* ; « chaque tome est un cran meilleur que le précédent » *(Goodreads, en croate, T1, 3/5, trad.)* ; « par rapport au tome précédent, qui comptait une énorme quantité de dialogues, tout est ici plus dynamique » *(Goodreads, en ukrainien, T3, 4/5, trad.)*. Le même schéma revient sur Reddit : « le tout début n'a rien de spécial, mais très vite c'est vraiment bon » *(Reddit r/manga, trad.)* ; « au début ça ne m'a pas accroché, c'était un peu dérivatif, mais l'intrigue a vite pris de l'élan » *(Reddit r/manga, trad.)*.
- **Un plaisir qui passe les frontières.** « j'aime beaucoup le système de magie, j'adore la variété des personnages, je trouve le manga très bien dessiné et j'adhère à l'humour » *(Goodreads, en allemand, T1, 5/5, trad.)* ; « j'ai lu tant de mauvais mangas cette semaine : celui-ci a été comme une limonade par un jour étouffant » *(Goodreads, en portugais, T1, 4/5, trad.)* ; « il prend les éléments classiques du shōnen et les rend un peu plus européens. C'est une merveille » *(Goodreads, en espagnol, T1, 4/5, trad.)*.
- **L'anime (saison 1) : une réalisation soignée.** « l'animation est très bien faite ; la série paraît lumineuse, vive et juvénile, comme One Piece ou Fairy Tail » *(Sequential Planet, anime ép. 1, trad.)* ; « bien coloré et bien animé » *(Babelio, avis sur le tome 1, à propos de l'anime)* ; « une série de fantasy de chasse aux monstres très directe, adaptée aux familles » *(Anime Feminist, anime ép. 1, trad.)*.

**Faiblesse :** ⬅ **Le point central : Seth étant le seul à pouvoir manipuler le Fantasia sans outil, il n'a structurellement besoin de personne.** Or toutes les œuvres du corpus où un second rôle écrase le héros reposent sur l'inverse — Gon n'est pas le plus talentueux (Killua l'est), Yusuke n'est pas le plus fort (Hiei l'est). **Un héros sans manque n'appelle pas de contre-poids, il appelle des témoins.** Et les témoins ne gagnent jamais les sondages. Ajouté à cela : l'adaptation animée a pris d'importantes libertés et beaucoup ralenti (21 épisodes pour 4 tomes en saison 1).

📚 **Ce que les lecteurs reprochent — vision globale** (mêmes sources ; même règle pour les tomes 7+ et la saison 2, rangés dans le coffre) :

- **Du déjà-vu.** Le reproche le plus répandu, surtout au tome 1 : « clairement un pot pourri de tous les nekketsu les plus populaires » *(SensCritique, T1, 7/10)* ; « ça n'invente pas grand chose tant il y a d'emprunts à beaucoup de classiques » *(SensCritique, T1, 5/10)* ; plus durement : « Radiant ressemble à un Black Clover du pauvre » *(Goodreads, T1, 2/5, trad.)* ; « Si les autres mangas de fantasy n'existaient pas déjà, celui-ci aurait pu paraître frais et nouveau » *(Goodreads, T1, 3/5, trad.)* ; « il a des problèmes d'originalité » *(Goodreads, en ukrainien, T1, 3/5, trad.)*. Sur la série entière, les avis vont de l'enthousiasme — « j'ai été bluffé » puis « Radiant n'a rien à envier au grand shonen connu de tous » *(SensCritique, série, 10/10)* — au rejet : « Mais il ressemble tant à ce qui se fait au Japon qu'il en est résolument quelconque » *(SensCritique, série, 2/10)* ; « une mauvaise copie de manga » *(SensCritique, série, 1/10)*. Beaucoup tempèrent : « tout ça sent un petit peu le réchauffé, mais c'est fait avec tellement d'amour, de talent et d'humour qu'on s'y laisse prendre sans forcer » *(SensCritique, T1, 9/10)* ; « On sent que ce manga a été inspiré d'autres shonen connus mais ça ne gêne en rien la lecture. » *(Goodreads, T1, 3/5)* ; « on reste dans les archétypes du genre et que ça fait forcément penser à un Black Clover ou un Shaman King, mais c'est extrêmement bien fait » *(Babelio, T4)* ; « il a pris le meilleur de chaque source pour en faire quelque chose de personnel » *(Goodreads, en croate, T1, 3/5, trad.)*.
- **Un héros qui agace.** « l'un des protagonistes les plus insupportablement idiots que j'aie vus ; je ne l'ai vraiment pas aimé » *(Goodreads, T1, 2/5, trad.)* ; « j'en ai assez des histoires où le jeune combattant odieux hurle à quel point il est fort » *(Goodreads, T1, 3/5, trad.)* ; « Seth est un peu un mix de tous les héros de shonens phares » *(Goodreads, T1, 3/5)* ; « le principal problème de la série, c'est son protagoniste » *(Goodreads, en espagnol, T1, trad.)*, et « n'importe quel autre personnage de la série aurait été un meilleur protagoniste que Seth » *(Goodreads, en espagnol, T1, trad.)* ; « Seth est un énième personnage irritant, immature et inconscient des dégâts qu'il cause autour de lui » *(Goodreads, en croate, T1, 3/5, trad.)*, même si « plus tard, je remarque un changement chez lui » *(Goodreads, en croate, T1, 3/5, trad.)* ; « j'ai trouvé Seth plutôt pénible dans son entêtement et sa bonne volonté mal placée » *(Goodreads, en suédois, T1, 3/5, trad.)* ; « beaucoup de courage, mais très peu de jugeote » *(Goodreads, en italien, T1, 2/5, trad.)*. Pour des lecteurs conquis, cette idiotie fait au contraire partie du charme : « le lecteur n'aura de cesse de se morfondre devant la stupidité du jeune héros Seth » *(Babelio, T1, 5/5)*.
- **Trop de texte, trop d'explications, une mise en place parfois confuse** — un reproche qui dure du tome 1 au tome 6 : « beaucoup d'explications plutôt que de la mise en scène » *(Goodreads, T1, 3/5, trad.)* ; « la composition des planches est infernale. Des cases minuscules, engorgées de texte » *(Askear, T1, 3.8/5)* ; « trop de blabla explicatif » *(Manga-News, T3)* ; « la narration trop fouillie et fournie » *(Goodreads, T2, 3/5)* ; « l'histoire est un peu confuse, avec beaucoup d'exposition » *(Goodreads, T1, 3/5, trad.)* ; « La mise en place du récit m'a un peu embrouillée à certains moments » *(Babelio, T1, 3/5)* ; « il y a des pages avec trop de texte qui gênent parfois le rythme narratif comme la lecture » *(Goodreads, en espagnol, T2, 4/5, trad.)* ; « je trouve toujours cette BD trop bavarde : elle explique au lieu de montrer » *(Goodreads, en indonésien, T2, 3/5, trad.)* ; « la narration de l'auteur, encore une fois, est bien trop chargée au début, avec des cases présentant trop de textes au vu du type d'histoire, ce qui casse et ralentit le rythme de lecture sans raison » *(Babelio, T5)* ; « il se passe tant de choses que j'ai envie de survoler une partie du texte » *(Goodreads, T5, trad.)*. Le format compte aussi : « du coup les cases paraissent minuscules et on profite mal du dessin » *(Goodreads, en indonésien, T1, 3/5, trad.)* ; « pour un tel niveau de détail, on aimerait un livre de plus grand format » *(Goodreads, en ukrainien, T1, 3/5, trad.)*. Nuance d'un lecteur du tome 6 : « Si parfois sa narration est trop touffue pour moi, en revanche, il l'allège allègrement lors des phases d'action et c'est alors très percutant. » *(Babelio, T6)*
- **Des longueurs et des débuts d'arc lents.** « Le rythme m'a paru un peu trop lent, même si le dessin était superbe » *(Goodreads, T1, 3/5, trad.)* ; au début du tome 2 : « pendant les 50 premières pages, j'étais persuadé·e que j'allais abandonner la série » *(Goodreads, T2, 2/5, trad.)* ; au tome 3 : « le combat m'a paru vraiment étiré » *(Goodreads, T3, 3/5, trad.)* ; « il n'aurait rien perdu à être grandement raccourci pour gagner en dynamisme » *(Babelio, T3, 4/5)* ; le retour en arrière du tome 3 : « le flashback devient trop lent par rapport au reste » *(Goodreads, en espagnol, T3, 4/5, trad.)* ; « le flashback dure, dure et dure » *(Goodreads, en espagnol, T3, 4/5, trad.)*. Un schéma relevé au tome 6 : « l'auteur semble avoir besoin de quelques chapitres de rodage avant de faire décoller son histoire » *(Babelio, T6)*.
- **Un humour qui divise.** « certains gags un peu lourd à la longue » *(Manga-News, T2, 17/20)* ; « l'humour du texte et les dessins et remarques sexistes font que je ne lirais pas la suite » *(Goodreads, T1, 1/5)* ; « il y a plus d'humour scatologique (vomi, pipi, vieux messieurs qui pelotent des femmes) qu'avant » *(Goodreads, T2, 2/5, trad.)* ; « et un humour très inégal : tantôt des blagues scatologiques, tantôt sur la superstition ou la cupidité » *(Goodreads, en ukrainien, T1, 3/5, trad.)* ; « l'histoire et le dessin sont un peu puérils pour mon goût » *(Goodreads, T1, 3/5, trad.)*. Côté femmes : « ce n'est pas drôle qu'un type pervers tripote une fille » *(Goodreads, en espagnol, T2, 4/5, trad.)* ; « beaucoup de critique du racisme, mais le traitement des femmes, ce sera pour un autre jour » *(Goodreads, en espagnol, T2, 4/5, trad.)*. À l'inverse, un lecteur du tome 3 en regrette l'absence : « on manquerait presque d'humour (là où on en avait un peu trop dans le tome 2... Y aura t-il un jour une juste mesure ?) » *(SensCritique, T3, 7/10)*.
- **Un public plutôt jeune.** « Radiant est, à mon avis, un manga destiné à des lecteurs plus jeunes » *(Goodreads, en croate, T1, 3/5, trad.)* ; « je pense que les dessins sont pour un public plus jeune » *(Goodreads, T1, 3/5)*.
- **Un propos jugé appuyé ou manichéen (tomes 2 et 3), mais le débat existe.** « Beaucoup trop manichéen » *(Manga-News, T3)* ; un lecteur du tome 3 juge le thème de la discrimination gratuit et écrit : « J'aurais aimé plus de justesse » *(Manga-News, T3, 12/20)* ; « il m'a semblé devenir un peu moralisateur » *(Goodreads, T2, 3/5, trad.)* ; « le thème de l'exclusion des gens différent est appuyé » *(Babelio, T3, 3.5/5)* ; sur Reddit : « il y a les bons d'un côté et les méchants de l'autre, bien séparés, avec un protagoniste qui doit être bon à tout prix » *(Reddit r/manga, en italien, trad.)* — alors que d'autres lecteurs, plus haut, voient au contraire des antagonistes qui ont leurs raisons.
- **Un monde pas toujours cohérent.** « j'ai trouvé le nombre de sorcier existant beaucoup trop importants » *(SensCritique, T3, 9/10)* (mais ce lecteur, qui met 9/10, parle lui-même de « chipotage ») ; « Tony Valente n'est peut-être pas bon pour écrire des visions du monde et une logique crédibles » *(Goodreads, T3, 4/5, trad.)* ; « pourquoi le gouvernement censé veiller à la sécurité de ses citoyens se consacre-t-il à pourchasser et arrêter les sorciers ? » *(Goodreads, en espagnol, T1, 2/5, trad.)* ; « je n'ai même pas compris comment fonctionnait le monde » *(Goodreads, en espagnol, T1, 2/5, trad.)* ; « la logique est un peu bizarre, à mon avis » *(Goodreads, en indonésien, T1, 3/5, trad.)*.
- **Des personnages de départ mis de côté.** « les personnages de Doc et Mélie très en retrait dans ce tome » *(Manga-News, T4, 18/20)*, ce qui donne au tome « un goût de trop-peu » ; « les personnages originels sont un peu mis de côté dans ce volume » *(Babelio, T5)*.
- **Même les lecteurs sévères aiment le dessin, et beaucoup veulent la suite.** « Le dessin est incroyable, mais je ne suis pas vraiment investi dans l'histoire » *(Goodreads, T1, 2/5, trad.)* ; « J'aime le dessin de ce manga […] c'est tout ce que j'ai aimé » *(Goodreads, T1, 2/5, trad.)* ; « ça donne envie d'en savoir plus sur cet univers » *(Goodreads, T1, 3/5)*
- **L'anime, saison 1 : du remplissage et des libertés.** « je ne peux appeler le reste de la saison 1 autrement que du remplissage » *(Lost in Anime, anime ép. 21, trad.)*, tout en saluant les parties fidèles au manga, « excellentes » mais trop rares ; « un passage à vide rempli de fillers » *(Babelio, avis sur le tome 1, à propos de l'anime)* ; « une fois le manga découvert, je n'ai plus ressenti le besoin de regarder l'anime : il n'ajoute pas grand-chose et il enlève un peu » *(Reddit r/RadiantManga, trad.)* ; « se repose beaucoup trops sur une intrigue qui n'avance pas » *(Manga-News, avis sur l'anime)* et « des vrais ARCS et pas 3 ep par micro aventure » *(Manga-News, avis sur l'anime)* ; « des digressions philosophiques pesantes » *(Anime Feminist, anime ép. 1, trad.)*.

⚠️ Lecture prudente : les avis des tomes 2 et suivants viennent de lecteurs qui ont poursuivi, donc plutôt indulgents. La matière vient surtout des tomes 1 à 3 ; les tomes 4 à 6 ne sont couverts que par des extraits de pages Babelio et Manga-News, et la série entière par six critiques SensCritique.

**Point d'entrée conseillé :** le manga, tome 1 (l'anime ne couvre que les tomes 1 à ≈ 10 et s'écarte du texte).

**Confiance :** données éditoriales ✅ (Manga-News, Wikipédia, Ankama) · contenu des tomes : repris de la v1 🔎 (non rouvert). · rubriques 📚 : extraits d'avis de lecteurs (tes fichiers pour les tomes 1 à 3, y compris les 81 avis en d'autres langues ; pages Babelio et Manga-News pour les tomes 4 à 6 ; blogs et Reddit pour l'anime), choisis par thème ; les extraits de tes fichiers sont vérifiés mot pour mot, ceux du web sont recopiés des pages ; les traductions sont les miennes.

---


---

## B. `fiches_oeuvres_v3.md` : « G. Radiant — Force et Faiblesse enrichies »

## G. Radiant — Force et Faiblesse enrichies (6 octobre 2026)
- Texte d'origine **conservé intégralement** (y compris la phrase sur Seth). Ajout, dans chaque rubrique, d'une synthèse **qualitative** avec extraits d'avis, sans chiffres. Version « vision globale » : tous les avis fournis (dont les 81 en espagnol, ukrainien, allemand, croate, indonésien, etc.), des extraits des pages Babelio et Manga-News des tomes 4 à 6, six avis de série SensCritique, des avis Reddit et des critiques de l'anime saison 1.
- **Spoils** : aucune critique contenant un passage « spoiler » masqué n'est citée ; aucun détail d'intrigue au-delà du tome 6. Les jugements sur les tomes 7 et suivants et sur la saison 2 de l'anime sont rangés dans `coffre/radiant_apres_tome6.md`.


---

## C. `uploads/fiches_oeuvres (2).md` : Radiant et cas Seth / Killua (ton texte d'origine, jusqu'à la fin du fichier)

# Radiant — 2013

*Tony Valente · Ankama Éditions · depuis le 4 juillet 2013 · **19 volumes** en français (nov. 2024) · plus d'un million d'exemplaires, 20+ langues · **premier manfra publié au Japon** (2015, Euromanga / Asukashinsha) · Viz Media en anglais · anime de 42 épisodes (Lerche) sur NHK Educational TV, oct. 2018 – févr. 2020*

> ## ⚠️ LIMITE ANTI-SPOIL — **mise à jour : fin du tome 6**
> **Correspondance vérifiée :** saison 1 (21 ép.) = **tomes 1 à 4** ; saison 2 (21 ép.) = **tome 5 au tome 10 environ**.
> La fiche couvre donc désormais **les tomes 1 à 6**, soit environ le premier tiers de la saison 2.
> **Sont exclus et NON NOMMÉS :** tout ce qui relève des **tomes 7 et suivants** — l'adoubement, la suite de la machination des Némésis Spectraux, l'identité de Diabal, les arcs postérieurs à Cyfandir, Bôme, et le reste du casting. **Dis-moi quand tu passes au tome 7.**

**Genres / tags :** Shōnen / Nekketsu, Aventure, Fantasy, Comédie, **Steampunk partiel** (Rumble Town, ère industrielle)

**Goal :** **Trouver le Radiant**, le berceau légendaire des Némésis, pour les détruire et mettre fin à la malédiction des Infectés. Goal clair, personnel, choisi — de la même famille que celui de FMA (« défaire quelque chose »).

**Éléments distinctifs :**
- **Les Némésis** — créatures tombées du ciel, sources de l'infection
- **Les Infectés** — survivants d'un contact avec un Némésis, désormais capables de manipuler le **Fantasia**, mais **stigmatisés et persécutés**
- ⬅ **Seth est le seul sorcier capable de manipuler le Fantasia sans outil.** Tous les autres ont besoin d'un instrument. **C'est la pièce structurante de l'œuvre — voir plus bas.**
- **Les cornes de Seth** — marqueur visuel du héros, et il est **stigmatisant** (il est « le cornu ») : signature et exclusion sont le même signe
- **L'Inquisition** — l'autorité persécutrice ; **l'Ordre des Chevaliers-Sorciers** ; **l'Institut Artémis** — le grand repaire de sorciers
- **Master Lord Majesty** (le roi chat) · **Draccoon** · **Yaga**, le maître · **la Bravery Quartet**
- **Cyfandir / Caislean Merlin**, l'îlot-continent des chevaliers-sorciers · **la reine Boadicée**
- ⬅ **Les Némésis Spectraux** (tome 6) : nouvelle classe d'ennemis qui apparaît partout sur Cyfandir et plonge Seth au cœur d'une **machination**, la suspicion gagnant le château lui-même
- **Les Barons-Marchands** — présents et mystérieux dès le tome 6 ; leur rôle reste à préciser
- **Lord Brangoire** · les capitaines **Dragunov** et **Liselotte** se lancent aux trousses de Seth

**Emprunts culturels :** ⬅ **le cas le plus singulier du corpus, et il inverse le sens habituel**
- **Emprunt de forme :** un auteur **français** qui emprunte le shōnen nekketsu japonais dans ses codes entiers — au point d'être publié à Tokyo et adapté par la première chaîne publique japonaise. **Toutes les autres œuvres de la grille empruntent un contenu ; Radiant emprunte une forme industrielle.**
- **Emprunt de matière :** folklore **celtique et irlandais** — *Caislean Merlin* (« château de Merlin »), **Boadicée** (reine celtique historique), le **Dullahan** (figure du folklore irlandais), Caillte.
- **Emprunt d'actualité :** la persécution des sorciers est explicitement inspirée du climat français contemporain.

**Peak de l'œuvre :** ⚠️ **donnée manquante.** Aucun sondage d'arcs n'existe pour Radiant — pas de sondage d'éditeur de type Shōnen Jump. Je ne classe pas à l'aveugle.

**Personnages les plus appréciés :** ⚠️ **donnée manquante, même raison.** Aucun sondage de personnages. Les seules mesures publiques sont des notes par tome (SensCritique & cie), qui mesurent l'appréciation de l'œuvre, **pas celle des personnages**.

**Personnages (dans la limite, tomes 1-6) :**
| | profil |
|:---|:---|
| **Seth** | Infecté aux cornes, seul à manipuler le Fantasia sans outil |
| **Mélie** | sorcière au « dédoublement de personnalité » : douce, timide, serviable dans son état premier ; **agressive, grossière et hautement compétente au combat** quand le stress ou le combat la déclenche. Compagne la plus loyale de Seth, « ciment émotionnel du groupe » |
| **Doc** | amitié réticente et chamaillée, d'abord purement intéressé ; se découvre progressivement de la loyauté |
| **Alma** | mère adoptive et mentor ; sorcière respectée, a perdu un bras ; « son rôle est d'abord celui d'un guide » |
| **Piodon** | **frère de Seth**, de la même lignée à cornes ; lien « mystérieux et antagoniste ». Sa nature est explicitée au tome 5 |
| ⬅ **Ocoho** | **Le cas qui compte.** Entrée au chap. 33 / ép. 22 **par le camp de l'autorité** (aspirante de l'Ordre). Elle est le **Dullahan**, la figure de superstition de Cyfandir. **Son infection : quiconque presse le grain de beauté derrière son cou peut lui ordonner n'importe quoi, et elle n'en garde aucun souvenir.** C'est ainsi qu'elle attaque Mélie, avant que Seth ne l'arrête. **Elle rejoint le groupe à la fin de l'arc de Caislean Merlin** (tome 6) |

**Schéma narratif répété :**
1. Arrivée dans un lieu-refuge de sorciers → découverte d'une **autorité locale hostile**
2. L'autorité se révèle ambiguë — Valente refuse le tout-blanc/tout-noir : « ses personnages ne sont ni tout blancs ni tout noirs et ont leurs propres motivations »
3. Intervention de Seth, qui déborde le cadre et se met tout le monde à dos
4. Fuite → lieu suivant
5. **L'enquête et le combat alternent** : Seth cherche des textes sur le Radiant autant qu'il se bat

**Force :** La stigmatisation n'est pas un décor mais **le moteur** : chaque lieu la rejoue sous une forme nouvelle, ce qui donne une unité thématique à un récit de voyage par ailleurs épisodique ; **les antagonistes ont des motivations** — refus constant du manichéisme ; le héros porte **la marque de son exclusion**, ce qui rend le thème visible en permanence ; format et clarté du nekketsu, avec un traitement plus appuyé de la différence et de l'exclusion.

**Faiblesse :** ⬅ **Le point central : Seth étant le seul à pouvoir manipuler le Fantasia sans outil, il n'a structurellement besoin de personne.** Or toutes les œuvres du corpus où un second rôle écrase le héros reposent sur l'inverse — Gon n'est pas le plus talentueux (Killua l'est), Yusuke n'est pas le plus fort (Hiei l'est). **Un héros sans manque n'appelle pas de contre-poids, il appelle des témoins.** Et les témoins ne gagnent jamais les sondages. Ajouté à cela : l'adaptation animée a pris d'importantes libertés et beaucoup ralenti (21 épisodes pour 4 tomes en saison 1).

---

# Le cas Seth / Killua — **verdict après le tome 6**

## Ce qui s'est débloqué

Au tome 5, Ocoho venait d'apparaître. Au tome 6, tout est en place :

1. **Elle arrive par le mauvais côté** — aspirante de l'Ordre des Chevaliers-Sorciers, l'institution qui persécute les sorciers. ✅ *C'est le profil d'entrée de Killua et de Hiei.*
2. **Elle a une blessure privée, antérieure à l'intrigue** — pas une blessure qui sert le récit, mais **une faille d'agentivité** : n'importe qui peut la commander, et elle ne s'en souviendra pas. ✅
3. **Elle est dangereuse pour de vrai** — elle attaque Mélie sous contrainte, et il faut Seth pour l'arrêter. ✅
4. **Le groupe la recueille quand même.** ✅

**Les quatre conditions du diagnostic sont remplies. La case existe.**

## Mais la polarité est inversée

C'est là que ça se joue, et c'est subtil.

Compare la phrase du sondage officiel de Yu Yu Hakusho sur Hiei :
> « il a l'air froid, mais il est vraiment gentil avec sa sœur. »

**Hiei est dangereux par choix, et tendre en privé.** Killua : froid, tueur, et lié à Gon par un besoin qu'il ne contrôle pas. Ce qui produit l'attachement, c'est **la fascination mêlée de crainte** — ce quelqu'un *pourrait* partir, et *pourrait* faire le mal.

**Ocoho est dangereuse par contrainte, et vulnérable en public.** Sa faille n'est pas morale, elle est **subie** : on la commande, elle oublie. Ce n'est pas « elle pourrait partir », c'est « elle pourrait être retournée ».

| | Hiei / Killua | Ocoho |
|:---|:---|:---|
| danger | **choisi** | **subi** |
| lien | besoin qu'il ne contrôle pas | faille que d'autres exploitent |
| ce qu'elle inspire | fascination + crainte | **protection + pitié** |

**Les données du corpus disent que c'est la fascination qui gagne, pas la protection.** Kuwabara, Ron et Nobara — les trois personnages du corpus qui suscitent de la loyauté et de l'affection simple — finissent 4ᵉ, 5ᵉ et 14ᵉ.

## Ce qu'il faudrait pour que ça bascule

Non pas ajouter un personnage, mais **rendre à Ocoho son agentivité**. Tant que sa dangerosité est une contrainte externe, elle reste un objet de protection. Le moment où elle deviendrait un Killua, c'est celui où **elle ferait volontairement ce qu'on lui ordonnait de force** — où la faille deviendrait un choix.

C'est un renversement qui ne demande pas un nouveau personnage, mais une scène.

## Réserve

⚠️ **Tout ceci est une inférence structurelle, pas un résultat mesuré.** Il n'existe **aucun sondage de popularité pour Radiant** — pas de sondage d'éditeur —, donc je ne peux pas vérifier si Ocoho est effectivement aimée ou non. Je raisonne par analogie avec onze autres œuvres, sur un mécanisme que le corpus documente bien. **C'est une hypothèse testable, pas une conclusion.**
