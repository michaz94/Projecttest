"""Codage manuel (numérotation FINALE C1–C8) des avis ajoutés par le fichier complet fourni par l'utilisateur.
Lu : tous les avis Mitigé / Négatif / Non noté (texte complet pour EN/FR/hors-EN-FR courts ; les très longs
Babelio via extraction des phrases à réserve + début + fin) ; les avis Positif en anglais/français via
extraction des phrases à réserve ; les Positif dans d'autres langues lus (aperçu)."""
CODES2={
# Goodreads T1 (nouveaux)
'GR1-4832287395':['C1','C4','C3'],'GR1-4127270846':['C3','C6'],'GR1-4924255516':['C2','C6'],'GR1-3419879787':['C1'],'GR1-3566076066':['C6'],
'GR1-3091906853':['C1','C3','C5'],'GR1-4564513442':['C2','C6'],'GR1-3945109126':['C1','C2'],'GR1-4814333879':['C3'],'GR1-6309687863':['C4','C3','C2'],
'GR1-4685643922':['C1'],'GR1-3449071456':['C2'],'GR1-4357299567':['C1'],'GR1-4339019526':['C3','C6'],'GR1-5441728159':['C3'],
'GR1-2861957702':['C2'],'GR1-3434546208':['C3'],'GR1-7036192683':['C5'],'GR1-5936052743':['C4'],
'GR1-8548861860':['C3'],'GR1-4821499435':['C5'],'GR1-8733061956':['C2'],'GR1-2855687946':['C5'],'GR1-2700378034':['C1','C2'],
'GR1-2678253068':['C1'],'GR1-2721675243':['C2'],'GR1-4781301884':['C5'],'GR1-6042306041':['C1','C2'],'GR1-5439357108':['C4','C3','C2','C6'],
'GR1-2545279294':['C1','C2','C5','C6'],'GR1-3464980146':['C6'],'GR1-3261149369':['C3'],'GR1-2952947638':['C1','C2'],
# Manga-News T3
'MN3-01':['C8'],'MN3-02':['C4','C8'],'MN3-03':['C3'],
# Babelio
'BB1-2164068':['C1','C4','C2'],'BB1-2304803':['C3'],'BB1-4453457':['C5','C7'],'BB1-1274023':['C5'],'BB1-1561751':['C6'],
'BB2-2164941':['C4','C6'],'BB3-1601576':['C8'],
# réserves dans des avis Positif
'GR1-5856369683':['C5'],'GR1-4804420195':['C2'],'GR1-8693534366':['C1'],'MN2-04':['C4'],'BB1-4109322':['C2'],
'BB2-3173176':['C3'],'BB2-4225150':['C4'],'BB3-1214020':['C5'],'GR1-3655705303':['C1'],
}
