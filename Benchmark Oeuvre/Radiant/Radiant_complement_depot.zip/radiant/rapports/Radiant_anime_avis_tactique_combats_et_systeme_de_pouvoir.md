# *Radiant* (anime, MAL) — avis sur les tactiques de combat, les combats et le système de pouvoir

**Source** : les 48 critiques MAL de l'anime (saison 1 : 36 ; saison 2 : 12), texte déjà filtré (phrases sur les épisodes filler du début de la saison 1 retirées). Extraits en anglais exacts. **Rien n'est quoté qui dévoile la fin de la saison 2** : un avis est listé avec son extrait masqué, un autre est coupé.

## Réponse courte
- **Tactique de combat : aucun des 48 avis ne parle de stratégie ou de tactique dans les combats.** Mon repérage par mots-clés (tactic, strategy, outsmart, clever, plan, intelligent, reckless, choreography, stakes…) ne ressort que des faux positifs et des remarques indirectes (tableau 1).
- Les avis parlent des combats surtout pour juger **la chorégraphie, la fluidité et l'animation** (tableau 3). Le système de pouvoir est commenté en peu de mots (tableau 4).
- Je ne peux pas dire *pourquoi* les critiques n'en parlent pas : tu as lu l'œuvre, pas moi.

**Limites** : 48 avis MAL, pas un échantillon représentatif. Un avis qui parle de tactique sans ces mots a pu m'échapper. Le classement « Sens » est ma lecture.

## 1. Avis proches de la question « tactique » (5)
*Aucun ne parle de stratégie de combat au sens strict. Ils portent sur le style de combat de l'équipe, la logique des pouvoirs, la variété des combats ou la comparaison avec HxH.*

| # | Auteur | Saison | Verdict MAL (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Praetori_Samurai` | Saison 1 | Recommended (8/10) | **Mixte (style de combat)** | Melie’s defense and offense bipolarity acts as an excellent compliment to Seth’s bullheaded brawler style. | `S1-19` |
| 2 | `charliechuckle` | Saison 1 | Not Recommended (3/10) | **Réserve (règles du pouvoir)** | The training is completely out of place, badly paced, and the power ups are awkward boring. […] His mana gives him God powers randomly and it doesn't even make sense. […] He should be able to use his God powers all the time; but plot dictates when he can or cannot use them. | `S1-12` |
| 3 | `Stark700` | Saison 1 | Not Recommended (4/10) | **Réserve (variété des combats)** | The only move in the boy’s arsenal that makes a difference is his signature “Titan Punch”. […] The battle choreography in the show remains fluid on some levels although it’s nothing spectacular. […] Trust me, once you’ve seen the first fight, it almost feels like you’ve seen them all. | `S1-1` |
| 4 | `ZB_Blades` | Saison 1 | Mixed Feelings (6/10) | **Réserve (créativité)** | His power isn't very creative either so its not like he stands out from the crowd very much. | `S1-26` |
| 5 | `KyomaBritannia` | Saison 2 | Mixed Feelings (6/10) | **Mixte (comparaison à HxH)** | Characters with extensive backgrounds and complex motives, adventures and fights on the level of Naruto, maybe even HxH if there was enough care put into its making. | `S2-6` |

## 2. Seth qui se bat sans réfléchir (3)
*Le style « bullheaded brawler » de Seth est aussi relevé dans le tableau 1 (`S1-19`).*

| # | Auteur | Saison | Verdict MAL (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Stark700` | Saison 1 | Not Recommended (4/10) | **Réserve** | His recklessness and daredevil personality from the start makes him hard to follow. | `S1-1` |
| 2 | `Flexstyle` | Saison 1 | Not Recommended (3/10) | **Réserve** | Seth is dense, dumb as bricks, reckless, childish, loud and annoying. | `S1-3` |
| 3 | `aoikimahri` | Saison 1 | Not Recommended (1/10) | **Réserve** | an utterly detestable and braindead protagonist that blindly runs around and screams nonstop like a crying toddle[r] | `S1-35` |

## 3. Les combats : jugés ou commentés (19 avis)
| # | Auteur | Saison | Verdict MAL (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Stark700` | Saison 1 | Not Recommended (4/10) | **Réserve** | The battle choreography in the show remains fluid on some levels although it’s nothing spectacular. […] Trust me, once you’ve seen the first fight, it almost feels like you’ve seen them all. | `S1-1` |
| 2 | `Zerity` | Saison 1 | Recommended (9/10) | **Éloge** | The fight scenes are so fucking beautiful which makes the show even more of a blast to watch. | `S1-2` |
| 3 | `Astagami` | Saison 1 | Recommended (8/10) | **Mixte** | This whole arc is filled to the brim with amazing character development and action. […] The animation lacks the intensity and fluidity that you want in a fight scene in anime. […] The best fight in this season has to be Seth vs Konrad, the choreography was very well done, but it lacked the fluidity it needed to truly shine. | `S1-10` |
| 4 | `FishMAL` | Saison 1 | Recommended (7/10) | **Mixte** | Other than that the anime has not the best fighting scenes but it's doing enough to make it look interesting and flashy, if not always polished. | `S1-13` |
| 5 | `CrumbleGarden` | Saison 1 | Recommended (7/10) | **Mixte** | The spell effects are nice and clear, the animation during fight scenes is pretty good, there's not too many flubs I could spot but it's nothing spectacular. | `S1-14` |
| 6 | `Praetori_Samurai` | Saison 1 | Recommended (8/10) | **Éloge** | Grimm has excellent style, a cool aesthetic and badass combat abilities. | `S1-19` |
| 7 | `therealab` | Saison 1 | Recommended (9/10) | **Éloge** | Animation and fights - 8/10 Being an action adventure anime, it has decent fight scenes. | `S1-20` |
| 8 | `nnidorion` | Saison 1 | Recommended (9/10) | **Éloge** | This is honestly a great anime with amazing artwork and good story with actually decent comedy moments mixed with heart felt betrayal and great fighting scenes. | `S1-24` |
| 9 | `ZB_Blades` | Saison 1 | Mixed Feelings (6/10) | **Éloge** | Action scenes are decently handled as well. | `S1-26` |
| 10 | `demetri_123` | Saison 1 | Recommended (7/10) | **Réserve** | Radiant is very much like fairy tail in that there is a lot of unnecessary dialogue with not enough action. | `S1-27` |
| 11 | `Zonticore` | Saison 1 | Recommended (8/10) | **Réserve** | The animation was pretty good in everything besides when the action picks up. they do this stupid animation technique where they blink past and forward frames really fast to try and make it look like something is moving fast. it just end up looking lazy and bad. | `S1-32` |
| 12 | `aoikimahri` | Saison 1 | Not Recommended (1/10) | **Réserve** | cheap animation, cheap fight scenes, bland art and sound | `S1-35` |
| 13 | `KANLen09` | Saison 2 | Recommended (8/10) | **Éloge** | *(extrait masqué : il dévoile des événements de la fin de la saison 2)* | `S2-0` |
| 14 | `Tenkay` | Saison 2 | Recommended (10/10) | **Éloge** | Tons of great colorful characters make their introduction and the battles continue to amp up and get more epic. | `S2-2` |
| 15 | `SCUBAST3V3N` | Saison 2 | Recommended (8/10) | **Mixte** | Personally, I think the first season, and the rumble town arc, namely, had better action scenes. | `S2-4` |
| 16 | `KyomaBritannia` | Saison 2 | Mixed Feelings (6/10) | **Mixte** | Characters with extensive backgrounds and complex motives, adventures and fights on the level of Naruto, maybe even HxH if there was enough care put into its making. | `S2-6` |
| 17 | `Jpk8` | Saison 2 | Recommended (10/10) | **Éloge** | The fight scenes were not half bad at all I love the animation and the art style loved every second of it art\animation I give it a 10\10. | `S2-7` |
| 18 | `therealab` | Saison 2 | Recommended (8/10) | **Éloge** | Animation and fights - 8/10 Being an action adventure anime, it has decent fight scenes. | `S2-9` |
| 19 | `Teddys92` | Saison 2 | Not Recommended (4/10) | **Réserve** | Too much talk […] than action, plot = decent, dont feel really hype for the next episode | `S2-11` |

**Mentionnent les combats sans les juger (6)** : `Karhu` (`S1-0`), `Flexstyle` (`S1-3`), `Kipo0007` (`S1-4`), `KingShnebs` (`S1-6`), `Jpk8` (`S1-21`), `WDUNE` (`S1-22`).

## 4. Le système de pouvoir : jugé ou commenté (13 avis)
| # | Auteur | Saison | Verdict MAL (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Stark700` | Saison 1 | Not Recommended (4/10) | **Neutre** | On the other hand, Melie does make a valuable asset for the team as she seems to be a skilled Sorcerer with defensive abilities. | `S1-1` |
| 2 | `Flexstyle` | Saison 1 | Not Recommended (3/10) | **Réserve** | Animation (5/10): The animation is pretty medicore, however I despise how bland all the spells look like green sparkles. | `S1-3` |
| 3 | `charliechuckle` | Saison 1 | Not Recommended (3/10) | **Réserve** | The training is completely out of place, badly paced, and the power ups are awkward boring. […] His mana gives him God powers randomly and it doesn't even make sense. […] He should be able to use his God powers all the time; but plot dictates when he can or cannot use them. | `S1-12` |
| 4 | `FishMAL` | Saison 1 | Recommended (7/10) | **Éloge** | It has a solid magic system and, what I personally always enjoy, a political hierarchy with a couple plot twists here and there. | `S1-13` |
| 5 | `CrumbleGarden` | Saison 1 | Recommended (7/10) | **Éloge** | The spell effects are nice and clear, the animation during fight scenes is pretty good, there's not too many flubs I could spot but it's nothing spectacular. | `S1-14` |
| 6 | `Praetori_Samurai` | Saison 1 | Recommended (8/10) | **Éloge** | the curses are unique and inventive | `S1-19` |
| 7 | `Blueruby24` | Saison 1 | Recommended (8/10) | **Éloge** | it isn't the whole I'm a over powered mc that has too much magic off the bat | `S1-23` |
| 8 | `ZB_Blades` | Saison 1 | Mixed Feelings (6/10) | **Réserve** | His power isn't very creative either so its not like he stands out from the crowd very much. | `S1-26` |
| 9 | `maougha` | Saison 1 | Mixed Feelings (6/10) | **Éloge** | A fantasy world, magic systems - and a pretty cool magic system at that. | `S1-31` |
| 10 | `Disfemisef` | Saison 1 | Recommended (7/10) | **Réserve** | For instance, sorcerers are hated for the powers they possess, however, the inquisitors (the team that hunts them) also have weird powers, but aren't feared by the people... | `S1-33` |
| 11 | `MidniteAndBeyond` | Saison 1 | Not Recommended (5/10) | **Réserve** | I do like the overall premise and message its focused on, but the similar plot points, story beats, running gags, character tropes, friend dynamics, magic macguffins, and so many other details just kept One Piece in the back of my mind all throughout this show. | `S1-34` |
| 12 | `aoikimahri` | Saison 1 | Not Recommended (1/10) | **Réserve** | It doesn't really matter since the whole show is no different than your typical Japanese fantasy shounen with an overpowered MC, magic, monsters, and flying ships. | `S1-35` |
| 13 | `KyomaBritannia` | Saison 2 | Mixed Feelings (6/10) | **Mixte** | The characters all have varied powers that are interesting or exciting, and open up plenty of avenues for deeper lore, but are usually just large blobs of color in passable animation work. […] The sorcerers' spells are usually green or blue while the inquisitors are gold. | `S2-6` |

**Mentionnent la magie, les sorciers ou l'infection sans les juger (17)** : surtout des résumés du pitch (`Karhu`, `Zerity`, `Kipo0007`, `KingShnebs`, `Astagami`, `nokinoks`, `TheDiv`, `Oriotiar`, `Hyouron`, `therealab`, `Jpk8`, `WDUNE`…).

## 5. Lecture rapide (observations)
- **Combats** : l'animation est le sujet principal (fluidité, chorégraphie « correcte mais pas spectaculaire », images sautées). Les éloges portent sur les scènes de combat en général, avec plus de nuances sur l'intensité. Les deux saisons sont citées ; un avis de la saison 2 trouve que la saison 1 (arc de Rumble Town) avait de meilleures scènes d'action.
- **Système de pouvoir** : les éloges sont brefs (« solid magic system », « curses are unique and inventive », héros pas surpuissant d'entrée) ; les réserves visent les règles jugées arbitraires, le manque de créativité du pouvoir de Seth et la ressemblance avec d'autres shōnens. **Un point propre à l'anime** : la couleur et le rendu des sorts (« green sparkles », « blobs of color »).
- **Tactique** : même constat que pour le manga, mais avec 48 avis seulement, donc encore moins de matière.
