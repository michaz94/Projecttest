# *Radiant* (manga) — avis qui parlent des tactiques de combat

**Source** : le corpus de 303 avis de l'analyse manga (Goodreads, Babelio, Manga-News, SensCritique, presse). Extraits exacts ; les traductions sont de moi (*trad.*).

## Réponse courte
**Presque aucun avis ne parle de tactique de combat.** Un seul avis évoque explicitement la **stratégie** dans les combats (`Tmor`, Babelio T3 : une phrase de huit mots). Un avis ukrainien parle de la **tactique du méchant** dans un résumé, et un avis suédois dit que l'impulsivité de Seth n'est pas une qualité au combat. Les autres avis ci-dessous touchent le sujet **de biais** : ils décrivent un héros qui fonce sans réfléchir, ou jugent les combats « pas innovants ».

**Précision sur mon analyse précédente** : dans le MD d'analyse, le sous-pôle `E2` (tactique, stratégie, créativité) sort à 2,3 % (5 avis). C'est **un repérage par mots-clés qui contient 4 faux positifs** (« bluffé » ×2, « cleverly » à propos d'un titre de chapitre, « pas très intelligent » à propos du héros). Au sens strict, **un seul avis** parle de stratégie de combat : le MD corrigé en tient compte.

**Méthode et limites** : repérage par mots-clés (tactique, stratégie, ruse, astucieux, intelligent, réfléchir, plan, bourrin, impulsif, sans réfléchir…) en anglais, français et quelques autres langues, puis lecture de chaque résultat. Un avis qui évoque la tactique avec d'autres mots, ou dans une langue non couverte, a pu m'échapper. Le classement en trois niveaux et la colonne « Sens » sont ma lecture.

## 1. Avis qui parlent de stratégie ou de tactique en combat (3)
| # | Auteur | Source | Verdict dérivé (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Tmor` | Babelio T3 | Non noté (sans note) | **Éloge (bref)** | Combats, stratégie et manipulations s'enchaînent sur plusieurs fronts. | `BB3-4969284` |
| 2 | `Roman Zarichnyi` | Goodreads T3 | Positif (4/5) | **Neutre (tactique du méchant, dans un résumé)** | Однак, оскільки йому доводиться балансувати в боротьбі між лиходієм, який використовує ненависну тактику, порятунком друзів та мешканців цього літаючого міста, стає очевидним, що врятувати Гуркітянськ буде непростим завданням. — *trad. : « Mais comme il doit jongler entre le combat contre le méchant, qui emploie une tactique odieuse, le sauvetage de ses amis et des habitants de cette ville volante, il devient évident que sauver Rumble Town ne sera pas une tâche facile. »* | `GR3-mSIVBw` |
| 3 | `Jessica` | Goodreads T1 | Mitigé (3/5) | **Réserve légère** | Seth är impulsiv, vilket inte alltid är en bra egenskap i strid. — *trad. : « Seth est impulsif, ce qui n'est pas toujours une bonne qualité au combat. »* | `GR1-4BOmcQ` |

## 2. Avis sur la façon dont Seth se bat : foncer sans réfléchir (14)
*Ce n'est pas de la tactique au sens strict : ces avis décrivent un héros puissant mais impulsif, ce qui indique indirectement l'absence d'approche réfléchie du combat dans les premiers chapitres. Le plus souvent, c'est un trait de personnalité ou une source d'humour, pas un jugement sur les combats.*

| # | Auteur | Source | Verdict dérivé (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `Bakakappa` | SensCritique T1 | Mitigé (7/10) | **Neutre/réserve** | Le héros est un gros bourrin plein de bonnes intention mais qui n'apporte que la destruction là où il passe. | `AS004` |
| 2 | `Kiraa7` | Manga-News T1 | Positif (15/20) | **Neutre** | Ce garçon intrépide est en manque d'action et rêve seulement d'affronter les Némésis, chose que lui interdit Alma à cause de son caractère bourrin. | `AS021` |
| 3 | `Helen` | TheOASG T1 | Négatif (note 2, échelle non précisée) | **Réserve** | Seth’s tiny horns mark him as an infected but, despite his boasts to the contrary, he doesn’t seem to be very good at doing anything related to hunting down nemeses, both because of his own skills and because of his brash, hot-headedness. | `AS051` |
| 4 | `anonyme` | Nerdbot T1 | Mitigé (3,5/5) | **Neutre** | It’ll take more than brute strength—although it’ll take that too—to get Seth’s quest out of the boonies and into the big time! | `AS052` |
| 5 | `Selena Pigoni` | Goodreads T1 | Mitigé (3/5) | **Neutre** | He's powerful, but not too bright and prone to causing mass destruction. | `GR1-HlqQvA` |
| 6 | `Nick` | Goodreads T1 | Mitigé (3/5) | **Réserve** | The characters are weird and different in some ways, but the main character is just the traditional "tough, spunky and a bit stupid" kid who is powerful but incompetent at the start. | `GR1-rwG-nA` |
| 7 | `Cornerofmadness` | Goodreads T1 | Mitigé (3/5) | **Réserve** | Seth is a young wizard who's never actually seen a nemeses but is sure he's going to be great at fighting them in that overconfident screaming shonen manga boy-hero style. | `GR1-4uyxZA` |
| 8 | `Andre` | Goodreads T1 | Mitigé (3/5) | **Réserve** | Albeit these people down there don´t look particularly frightened." And here is our protagonist, a teenage idiot named Seth who cannot differentiate between a herd of peaceful cattle and giant city destroying monsters. […] Alma (his teacher) got a point: with all the destruction Seth caused with his recklessness, what makes him then different from the Nemesis? | `GR1-4564513442` |
| 9 | `Sunread26` | Goodreads T1 | Positif (4/5) | **Neutre (humour)** | On enchaîne ensuite avec le vif du sujet, à savoir, le protagoniste Seth qui semble assez… maladroit et bourrin. | `GR1-6015687397` |
| 10 | `Sunread26` | Goodreads T2 | Positif (4/5) | **Neutre (humour)** | Seth n’est pas au bout de ses surprises et de ses combats, quant à la ville, si elle ne finit pas détruite par tous ses bourrins ça sera un gros coup de bol ! | `GR2-jxS83w` |
| 11 | `ebardin` | Babelio T1 | Positif (4/5) | **Neutre (humour)** | Ainsi, au début de ce tome 1, il confond de paisibles pachydermes avec des Némésis, et s'attire les foudres des habitants dont il a brutalisé les bêtes. […] Son impulsivité est source de comique car elle lui fait accumuler les âneries mais elle est compensée par sa probité et son dévouement. | `BB1-905930` |
| 12 | `LesLecturesdO...` | Babelio T1 | Positif (5/5) | **Mixte** | Il y a de l'action, des ennemis imposant et intriguant, un héros qui a tout à faire pour s'améliorer mais qui a plus d'un tour dans son sac, des personnages qui gravite autour de lui et qui ont sûrement tous des secrets et un univers qui a encore beaucoup de chose à nous apprendre. […] Il est intrépide donc c'est sans surprise qu'il fonce souvent dans le tas sans avoir réfléchir à la situation avant. | `BB1-1729510` |
| 13 | `Saiwhisper` | Babelio T1 | Positif (4/5) | **Neutre** | Dans la lignée de Naruto, l'adolescent est du genre tout feu tout flamme : naïf, il fonce tête baissée, utilise ses poings, se montre insouciant et se met parfois dans des galères incroyables. | `BB1-2309307` |
| 14 | `Drine Psylook (Babelio : LeManegeDePsy…)` | Babelio T1 | Positif (5/5) | **Neutre (humour)** | Il rêve d'affronter un Némésis, de redoutables monstres, sans pour autant connaître leur apparence… donc il tape sur tout ce qui lui semble un peu menaçant comme les vachidermes (oui, vous avez bien lu, ce n'est pas une erreur de frappe. | `BB1-2417233` |

## 3. Avis qui jugent l'originalité ou la créativité des combats (2)
| # | Auteur | Source | Verdict dérivé (note) | Sens | Extrait | id |
| :-: | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `alanparish` | SensCritique T1 | Mitigé (7/10) | **Mixte** | Tous les éléments du shonen sont présents : jeune garçon avec un grand pouvoir, univers vaste et mystérieux, combats dynamiques, personnages varié, humour... […] Pas de grande innovation niveau combat mais le job est fait de façon efficace. | `AS009` |
| 2 | `Tachan` | Goodreads T2 | Mitigé (3/5) | **Mixte** | C’est très vivant et varié en prime, avec de belles explosions de pouvoirs, même s’il reste encore des progrès à faire de ce côté pour avoir des choses originales. | `GR2-ddccda` |

## 4. Lecture rapide (observations)
- **Les combats sont jugés surtout sur le rythme, la lisibilité et l'intensité** (voir `Radiant_manga_avis_combats_et_systeme_de_pouvoir.md`), pas sur leur logique ni sur l'intelligence des affrontements.
- **Les avis du niveau 2 viennent presque tous du tome 1** : le héros y est décrit comme « bourrin », « impulsif » ou « puissant mais incompétent ». Un seul avis du tome 2 (`Sunread26`, « bourrins ») et aucun du tome 3 en parlent. Aucun avis ne dit que les combats deviennent plus tactiques, ni le contraire : c'est une absence de commentaire, pas une preuve.
- **Comparaison** : dans le corpus HxH analysé précédemment, la tactique/stratégie (`E2`) ressortait à 17,2 % (repérage par mots-clés). Ici, ce sujet n'existe pour ainsi dire pas dans la réception de *Radiant*.
