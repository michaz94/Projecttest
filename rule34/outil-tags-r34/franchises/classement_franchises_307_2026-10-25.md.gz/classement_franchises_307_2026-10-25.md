# Franchises les plus représentées (personnages féminins, rule34.xxx)

*Relevés des 24 et 25 octobre 2026. Base : les 307 personnages féminins de `doublons/selection_307_dedupliquee_audit_2026-10-25.csv`, c'est-à-dire tous les tags de personnage féminin à au moins 6 264 publications (liste des tags, pages 1 à 340). Les publications incluent les gains d'union de l'audit des doublons.*

**121 franchises** au total, dont 63 avec un seul personnage.

**Regroupements :** Sonic + Sonic the Hedgehog ; Resident Evil + RE4 + RE Village ; Naruto + Naruto / Boruto ; Avatar + La Légende de Korra (suite officielle) ; Marvel inclut la Femme invisible ; League of Legends inclut Jinx (Arcane). Gardées séparées : Hazbin Hotel et Helluva Boss (même univers de Vivziepop, mais séries distinctes) ; Undertale et Deltarune ; Vocaloid et UTAU. Marvel et DC sont des univers partagés qui regroupent beaucoup de séries.

**Limite :** seules les filles sont comptées ; une franchise riche en personnages masculins populaires (Naruto, Genshin Impact…) est donc sous-représentée par rapport à son poids total. Pour le poids total d'une franchise (tous personnages et images sans personnage), voir le Top 20 des tags Copyright (`copyright/top20_franchises_rule34_2026-10-24.csv`).

## 1. Par nombre de personnages

Départage à égalité : publications cumulées.

| # | Franchise | Personnages | Publications cumulées | Moyenne | Médium | Personnages (publications) |
|---|---|---|---|---|---|---|
| 1 | Pokémon | 17 | 196 191 | 11 541 | Jeux vidéo 16 / Animanga 1 | Cynthia (22 058), May (Flora en VF) (18 104), Misty (Ondine en VF) (18 082), Rosa (15 546), Hilda (15 539), Dawn (Aurore en VF) (14 047), Jessie (Team Rocket) (11 620), Nessa (Donna en VF) (10 470), Rosemary (Marnie) (9 208), Serena (9 105), Elsa-Mina (Lusamine) (9 049), Lilie (Lillie) (8 651), Sonia (7 693), Mère de Lana (Néphie en VF) (6 923), Bea (Faïza en VF) (6 916), Nemona (6 592), Skyla (Carolina en VF) (6 588) |
| 2 | Genshin Impact | 15 | 178 949 | 11 930 | Jeux vidéo | Raiden Shogun (25 757), Yae Miko (16 483), Ganyu (16 468), Lumine (15 314), Mona (14 667), Hu Tao (14 055), Eula (10 554), Furina (10 424), Arlecchino (9 440), Yelan (8 929), Shenhe (8 671), Keqing (7 793), Kamisato Ayaka (7 125), Lisa (6 659), Jean Gunnhildr (6 610) |
| 3 | League of Legends | 12 | 125 000 | 10 417 | Jeux vidéo 11 / Furry 1 | Ahri (29 877), Jinx (18 144), Akali (9 947), Sona (9 097), Agneau (Lamb, moitié féminine de Kindred) (8 777), Lux (7 671), Soraka (7 538), Caitlyn Kiramman (7 117), Poppy (6 933), Miss Fortune (Sarah Fortune) (6 820), Evelynn (6 637), Tristana (6 442) |
| 4 | My Little Pony | 10 | 189 893 | 18 989 | Furry | Twilight Sparkle (30 892), Fluttershy (26 448), Rainbow Dash (23 923), Rarity (22 555), Pinkie Pie (19 483), Applejack (18 411), Princesse Celestia (17 047), Princesse Luna (16 864), Reine Chrysalis (7 334), Princesse Cadance (6 936) |
| 5 | Overwatch | 10 | 184 564 | 18 456 | Jeux vidéo | D.Va (35 763), Widowmaker (31 976), Mercy (30 462), Tracer (23 060), Pharah (15 243), Mei (13 901), Sombra (10 224), Kiriko (9 985), Brigitte (7 504), Ashe (6 446) |
| 6 | Marvel | 10 | 120 306 | 12 031 | Comics | Emma Frost (20 269), Gwen Stacy (19 716), Black Cat (Felicia Hardy) (15 119), Femme invisible (Sue Storm) (10 816), Black Widow (Natasha Romanoff) (10 379), Squirrel Girl (10 093), Psylocke (Betsy Braddock / Kwannon) (10 006), Malicia (Rogue) (8 641), She-Hulk (7 675), Mary Jane Watson (7 592) |
| 7 | DC Comics | 9 | 166 602 | 18 511 | Comics 6 / Cartoons 3 | Raven (39 707), Harley Quinn (26 362), Wonder Woman (22 974), Starfire (21 791), Supergirl (16 375), Power Girl (13 942), Catwoman (Selina Kyle) (10 167), Batgirl (Barbara Gordon) (7 875), Poison Ivy (7 409) |
| 8 | Naruto | 8 | 179 200 | 22 400 | Animanga | Hinata Hyûga (44 141), Tsunade (40 786), Sakura Haruno (40 018), Ino Yamanaka (16 449), Sarada Uchiha (13 790), Kushina Uzumaki (10 657), Temari (7 018), Hanabi Hyūga (6 341) |
| 9 | My Hero Academia | 8 | 146 593 | 18 324 | Animanga | Ochako Uraraka (35 111), Miruko (31 266), Momo Yaoyorozu (18 872), Mina Ashido (17 795), Himiko Toga (15 704), Tsuyu Asui (13 349), Kyoka Jiro (7 493), Nejire Hado (7 003) |
| 10 | Zenless Zone Zero | 8 | 66 163 | 8 270 | Jeux vidéo | Jane Doe (10 356), Ellen Joe (9 754), Belle (9 531), Nicole Demara (9 149), Zhu Yuan (7 274), Evelyn Chevalier (6 964), Burnice White (6 871), Miyabi Hoshimi (6 264) |
| 11 | Dragon Ball | 7 | 100 263 | 14 323 | Animanga 6 / Jeux vidéo 1 | C-18 (30 868), Bulma (22 100), Chichi (14 479), Videl (9 996), C-21 (Android 21) (8 209), Kefla (7 491), Caulifla (7 120) |
| 12 | Sonic | 6 | 133 745 | 22 291 | Furry | Rouge the Bat (45 414), Amy Rose (41 846), Blaze the Cat (15 169), Vanilla (11 235), Cream the Rabbit (10 519), Sally Acorn (9 562) |
| 13 | Resident Evil | 5 | 84 364 | 16 873 | Jeux vidéo | Jill Valentine (25 551), Ada Wong (23 269), Claire Redfield (12 505), Lady Dimitrescu (11 846), Ashley Graham (11 193) |
| 14 | One Piece | 4 | 124 925 | 31 231 | Animanga | Nami (58 263), Nico Robin (35 080), Boa Hancock (19 886), Yamato (11 696) |
| 15 | Super Mario | 4 | 104 718 | 26 180 | Jeux vidéo | Princesse Peach (50 552), Harmonie (Rosalina) (24 442), Daisy (20 747), Bowsette (version féminine de Bowser, création de fans, 2018) (8 977) |
| 16 | Bleach | 4 | 71 499 | 17 875 | Animanga | Yoruichi (21 936), Orihime Inoue (19 208), Rangiku Matsumoto (17 804), Rukia Kuchiki (12 551) |
| 17 | Chainsaw Man | 4 | 69 045 | 17 261 | Animanga | Makima (34 383), Power (16 185), Reze (9 293), Kobeni Higashiyama (9 184) |
| 18 | RWBY | 4 | 58 660 | 14 665 | Cartoons | Yang Xiao Long (17 965), Ruby Rose (15 701), Weiss Schnee (14 113), Blake Belladonna (10 881) |
| 19 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 4 | 48 070 | 12 018 | Cartoons | Korra (13 757), Azula (12 587), Katara (12 083), Toph Beifong (9 643) |
| 20 | Fate | 4 | 46 774 | 11 694 | Jeux vidéo | Artoria Pendragon (20 563), Minamoto no Raikou (8 975), Mash Kyrielight (8 624), Rin Tohsaka (8 612) |
| 21 | Dead or Alive | 4 | 29 666 | 7 416 | Jeux vidéo | Kasumi (8 751), Marie Rose (8 052), Ayane (6 531), Honoka (6 332) |
| 22 | Street Fighter | 3 | 76 872 | 25 624 | Jeux vidéo | Chun-Li (41 013), Cammy (18 735), Juri Han (17 124) |
| 23 | KonoSuba | 3 | 46 821 | 15 607 | Animanga | Aqua (19 839), Megumin (15 208), Darkness (11 774) |
| 24 | The Witcher | 3 | 44 334 | 14 778 | Jeux vidéo | Ciri (20 518), Yennefer (12 861), Triss Merigold (10 955) |
| 25 | Demon Slayer | 3 | 40 978 | 13 659 | Animanga | Mitsuri Kanroji (16 655), Shinobu Kocho (14 569), Nezuko Kamado (9 754) |
| 26 | Five Nights at Freddy's | 3 | 33 301 | 11 100 | Furry | Toy Chica (14 905), Roxanne Wolf (11 401), Chica (6 995) |
| 27 | Doki Doki Literature Club | 3 | 29 896 | 9 965 | Jeux vidéo | Monika (12 511), Natsuki (8 919), Yuri (8 466) |
| 28 | Fire Emblem | 3 | 27 757 | 9 252 | Jeux vidéo | Byleth (version féminine) (10 952), Lucina (8 865), Camilla (7 940) |
| 29 | Blue Archive | 3 | 26 006 | 8 669 | Jeux vidéo | Asuna (11 612), Karin (Kakudate Karin) (7 334), Rio (Tsukatsuki Rio) (7 060) |
| 30 | Mass Effect | 3 | 25 684 | 8 561 | Jeux vidéo | Liara T'Soni (10 343), Commandant Shepard (version féminine) (7 700), Miranda Lawson (7 641) |
| 31 | Persona 5 | 3 | 25 538 | 8 513 | Jeux vidéo | Ann Takamaki (10 521), Makoto Niijima (8 698), Futaba Sakura (6 319) |
| 32 | Splatoon | 3 | 25 067 | 8 356 | Jeux vidéo | Marina (10 291), Marie (7 911), Callie (6 865) |
| 33 | Touhou Project | 3 | 24 971 | 8 324 | Jeux vidéo | Reimu Hakurei (10 571), Sanae Kochiya (7 227), Sakuya Izayoi (7 173) |
| 34 | Hololive | 3 | 22 178 | 7 393 | Autres | Ouro Kronii (7 959), Mori Calliope (7 114), Houshou Marine (7 105) |
| 35 | Final Fantasy VII | 2 | 70 304 | 35 152 | Jeux vidéo | Tifa Lockhart (54 505), Aerith Gainsborough (15 799) |
| 36 | The Legend of Zelda | 2 | 54 877 | 27 438 | Jeux vidéo | Princesse Zelda (39 792), Midna (15 085) |
| 37 | Helluva Boss | 2 | 52 106 | 26 053 | Furry | Loona (43 049), Millie (9 057) |
| 38 | Frieren | 2 | 48 331 | 24 166 | Animanga | Frieren (28 757), Fern (19 574) |
| 39 | One Punch Man | 2 | 38 633 | 19 316 | Animanga | Tatsumaki (24 182), Fubuki (14 451) |
| 40 | Animal Crossing | 2 | 38 555 | 19 278 | Furry | Marie (Isabelle) (20 826), Ankha (17 729) |
| 41 | Fairy Tail | 2 | 35 618 | 17 809 | Animanga | Lucy Heartfilia (18 255), Erza Scarlet (17 363) |
| 42 | Evangelion | 2 | 29 197 | 14 598 | Animanga | Asuka Langley (19 150), Rei Ayanami (10 047) |
| 43 | High School DxD | 2 | 28 374 | 14 187 | Animanga | Rias Gremory (17 248), Akeno Himejima (11 126) |
| 44 | Xenoblade Chronicles 2 | 2 | 24 861 | 12 430 | Jeux vidéo | Pyra (14 259), Mythra (Homura, autre forme de Pyra) (10 602) |
| 45 | Les Indestructibles | 2 | 23 600 | 11 800 | Cartoons | Helen Parr (Elastigirl) (15 935), Violette Parr (7 665) |
| 46 | Kill la Kill | 2 | 22 916 | 11 458 | Animanga | Ryuko Matoi (13 701), Satsuki Kiryuin (9 215) |
| 47 | Jujutsu Kaisen | 2 | 22 252 | 11 126 | Animanga | Nobara Kugisaki (14 940), Maki Zen’in (7 312) |
| 48 | Scooby-Doo | 2 | 21 898 | 10 949 | Cartoons | Velma Dinkley (14 935), Daphné Blake (6 963) |
| 49 | Re:Zero | 2 | 21 438 | 10 719 | Animanga | Emilia (11 705), Rem (9 733) |
| 50 | La Reine des neiges | 2 | 21 273 | 10 636 | Cartoons | Elsa (14 890), Anna (6 383) |
| 51 | Kim Possible | 2 | 20 295 | 10 148 | Cartoons | Kim Possible (12 439), Shego (7 856) |
| 52 | The Amazing Digital Circus | 2 | 18 878 | 9 439 | Cartoons | Pomni (12 589), Ragatha (6 289) |
| 53 | Miss Kobayashi's Dragon Maid | 2 | 18 327 | 9 164 | Animanga | Ilulu (9 655), Lucoa (Quetzalcoatl) (8 672) |
| 54 | Adventure Time | 2 | 18 258 | 9 129 | Cartoons | Princesse Chewing-gum (9 974), Marceline (8 284) |
| 55 | Deltarune | 2 | 16 787 | 8 394 | Furry | Susie (9 501), Noelle Holiday (7 286) |
| 56 | Uzaki-chan veut traîner ! | 2 | 15 517 | 7 758 | Animanga | Hana Uzaki (8 621), Tsuki Uzaki (mère de Hana) (6 896) |
| 57 | Cyberpunk 2077 | 2 | 14 574 | 7 287 | Jeux vidéo | Panam Palmer (7 822), Judy Alvarez (6 752) |
| 58 | Luz à Osville (The Owl House) | 2 | 13 639 | 6 820 | Cartoons | Luz Noceda (7 228), Amity Blight (6 411) |

*Les 63 franchises à un seul personnage figurent dans le CSV.*

## 2. Par publications cumulées (top 30)

| # | Franchise | Publications cumulées | Part des 307 | Personnages | Rang par nombre |
|---|---|---|---|---|---|
| 1 | Pokémon | 196 191 | 4,5 % | 17 | 1 |
| 2 | My Little Pony | 189 893 | 4,3 % | 10 | 4 |
| 3 | Overwatch | 184 564 | 4,2 % | 10 | 5 |
| 4 | Naruto | 179 200 | 4,1 % | 8 | 8 |
| 5 | Genshin Impact | 178 949 | 4,1 % | 15 | 2 |
| 6 | DC Comics | 166 602 | 3,8 % | 9 | 7 |
| 7 | My Hero Academia | 146 593 | 3,3 % | 8 | 9 |
| 8 | Sonic | 133 745 | 3,1 % | 6 | 12 |
| 9 | League of Legends | 125 000 | 2,9 % | 12 | 3 |
| 10 | One Piece | 124 925 | 2,9 % | 4 | 14 |
| 11 | Marvel | 120 306 | 2,7 % | 10 | 6 |
| 12 | Super Mario | 104 718 | 2,4 % | 4 | 15 |
| 13 | Dragon Ball | 100 263 | 2,3 % | 7 | 11 |
| 14 | Resident Evil | 84 364 | 1,9 % | 5 | 13 |
| 15 | Street Fighter | 76 872 | 1,8 % | 3 | 22 |
| 16 | Bleach | 71 499 | 1,6 % | 4 | 16 |
| 17 | Final Fantasy VII | 70 304 | 1,6 % | 2 | 35 |
| 18 | Chainsaw Man | 69 045 | 1,6 % | 4 | 17 |
| 19 | Zenless Zone Zero | 66 163 | 1,5 % | 8 | 10 |
| 20 | RWBY | 58 660 | 1,3 % | 4 | 18 |
| 21 | The Legend of Zelda | 54 877 | 1,3 % | 2 | 36 |
| 22 | Helluva Boss | 52 106 | 1,2 % | 2 | 37 |
| 23 | Frieren | 48 331 | 1,1 % | 2 | 38 |
| 24 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 48 070 | 1,1 % | 4 | 19 |
| 25 | KonoSuba | 46 821 | 1,1 % | 3 | 23 |
| 26 | Fate | 46 774 | 1,1 % | 4 | 20 |
| 27 | The Witcher | 44 334 | 1,0 % | 3 | 24 |
| 28 | NieR: Automata | 43 048 | 1,0 % | 1 | 59 |
| 29 | Vocaloid | 41 506 | 0,9 % | 1 | 60 |
| 30 | Demon Slayer | 40 978 | 0,9 % | 3 | 25 |
