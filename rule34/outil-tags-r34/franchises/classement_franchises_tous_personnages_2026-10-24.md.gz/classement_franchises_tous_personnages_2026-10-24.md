# Franchises les plus représentées sur rule34.xxx — tous personnages (24 octobre 2026)

*Base : les 345 personnages relevés dans les pages 1 à 330 de la liste des tags (au moins ≈ 6 590 publications) : 293 féminins (sélection auditée), 46 masculins (41 de l'application de tri, dont 18 audités pour les doublons ; 5 des pages 311-330 comptés avec leur tag seul : Dick Grayson, Jax, Shining Armor, Ichigo Kurosaki, Ash Ketchum) et 6 au genre non défini ou au choix (Kris, Frisk, Chara, Corrin, MalO, Sensei de Blue Archive). Byleth, le Commandant Shepard et Kindred ne sont pas ajoutés une 2e fois (déjà comptés par leur version féminine). Espèces (Gardevoir, Lucario…), catégories et doublons exclus.*

**120 franchises**, dont 59 avec un seul personnage. ♂ = masculin.

**Limites :** (1) les masculins des pages 1 à 107 ont été notés lors d'un premier relevé moins détaillé ; (2) une image avec deux personnages de la même franchise compte deux fois dans le cumul ; (3) MalO est compté avec un seul de ses 4 tags.

## 1. Par nombre de personnages

| # | Franchise | Personnages | ♀ | ♂ | Autre | Publications cumulées | Rang filles seules | Personnages (publications) |
|---|---|---|---|---|---|---|---|---|
| 1 | Pokémon | 18 | 17 | 1 | 0 | 202 767 | 1 | Cynthia (22 058), May (Flora en VF) (18 104), Misty (Ondine en VF) (18 082), Rosa (15 546), Hilda (15 539), Dawn (Aurore en VF) (14 047), Jessie (Team Rocket) (11 620), Nessa (Donna en VF) (10 470), Rosemary (Marnie) (9 208), Serena (9 105), Elsa-Mina (Lusamine) (9 049), Lilie (Lillie) (8 651), Sonia (7 693), Mère de Lana (Néphie en VF) (6 923), Bea (Faïza en VF) (6 916), Nemona (6 592), Skyla (Carolina en VF) (6 588), Ash Ketchum (Sacha en VF) ♂ (6 576) |
| 2 | Genshin Impact | 17 | 15 | 2 | 0 | 216 687 | 2 | Aether ♂ (29 495), Raiden Shogun (25 757), Yae Miko (16 483), Ganyu (16 468), Lumine (15 314), Mona (14 667), Hu Tao (14 055), Eula (10 554), Furina (10 424), Arlecchino (9 440), Yelan (8 929), Shenhe (8 671), Venti ♂ (8 243), Keqing (7 793), Kamisato Ayaka (7 125), Lisa (6 659), Jean Gunnhildr (6 610) |
| 3 | My Little Pony | 13 | 10 | 3 | 0 | 213 810 | 4 | Twilight Sparkle (30 892), Fluttershy (26 448), Rainbow Dash (23 923), Rarity (22 555), Pinkie Pie (19 483), Applejack (18 411), Princesse Celestia (17 047), Princesse Luna (16 864), Spike ♂ (9 723), Big Macintosh ♂ (7 346), Reine Chrysalis (7 334), Princesse Cadance (6 936), Shining Armor ♂ (6 848) |
| 4 | DC Comics | 12 | 9 | 3 | 0 | 191 532 | 7 | Raven (39 707), Harley Quinn (26 362), Wonder Woman (22 974), Starfire (21 791), Supergirl (16 375), Power Girl (13 942), Catwoman (Selina Kyle) (10 167), Batman ♂ (9 505), Beast Boy ♂ (8 422), Batgirl (Barbara Gordon) (7 875), Poison Ivy (7 409), Dick Grayson (Robin / Nightwing) ♂ (7 003) |
| 5 | Marvel | 12 | 10 | 2 | 0 | 154 357 | 5 | Spider-Man ♂ (20 916), Emma Frost (20 269), Gwen Stacy (19 716), Black Cat (Felicia Hardy) (15 119), Venom ♂ (13 135), Femme invisible (Sue Storm) (10 816), Black Widow (Natasha Romanoff) (10 379), Squirrel Girl (10 093), Psylocke (Betsy Braddock / Kwannon) (10 006), Malicia (Rogue) (8 641), She-Hulk (7 675), Mary Jane Watson (7 592) |
| 6 | League of Legends | 11 | 11 | 0 | 0 | 118 558 | 3 | Ahri (29 877), Jinx (18 144), Akali (9 947), Sona (9 097), Agneau (Lamb, moitié féminine de Kindred) (8 777), Lux (7 671), Soraka (7 538), Caitlyn Kiramman (7 117), Poppy (6 933), Miss Fortune (Sarah Fortune) (6 820), Evelynn (6 637) |
| 7 | Naruto | 10 | 7 | 3 | 0 | 224 524 | 9 | Hinata Hyûga (44 141), Tsunade (40 786), Sakura Haruno (40 018), Naruto Uzumaki ♂ (35 637), Ino Yamanaka (16 449), Sarada Uchiha (13 790), Kushina Uzumaki (10 657), Sasuke Uchiha ♂ (8 773), Raikage (A) ♂ (7 255), Temari (7 018) |
| 8 | Sonic | 10 | 6 | 4 | 0 | 220 467 | 12 | Rouge the Bat (45 414), Amy Rose (41 846), Sonic ♂ (37 386), Tails ♂ (27 698), Blaze the Cat (15 169), Shadow ♂ (13 410), Vanilla (11 235), Cream the Rabbit (10 519), Sally Acorn (9 562), Knuckles ♂ (8 228) |
| 9 | My Hero Academia | 10 | 8 | 2 | 0 | 185 943 | 8 | Ochako Uraraka (35 111), Miruko (31 266), Izuku Midoriya ♂ (28 498), Momo Yaoyorozu (18 872), Mina Ashido (17 795), Himiko Toga (15 704), Tsuyu Asui (13 349), Katsuki Bakugo ♂ (10 852), Kyoka Jiro (7 493), Nejire Hado (7 003) |
| 10 | Overwatch | 9 | 9 | 0 | 0 | 178 118 | 6 | D.Va (35 763), Widowmaker (31 976), Mercy (30 462), Tracer (23 060), Pharah (15 243), Mei (13 901), Sombra (10 224), Kiriko (9 985), Brigitte (7 504) |
| 11 | Dragon Ball | 8 | 7 | 1 | 0 | 115 265 | 10 | C-18 (30 868), Bulma (22 100), Son Goku ♂ (15 002), Chichi (14 479), Videl (9 996), C-21 (Android 21) (8 209), Kefla (7 491), Caulifla (7 120) |
| 12 | Zenless Zone Zero | 8 | 7 | 1 | 0 | 70 940 | 11 | Wise ♂ (11 041), Jane Doe (10 356), Ellen Joe (9 754), Belle (9 531), Nicole Demara (9 149), Zhu Yuan (7 274), Evelyn Chevalier (6 964), Burnice White (6 871) |
| 13 | Super Mario | 6 | 4 | 2 | 0 | 137 126 | 15 | Princesse Peach (50 552), Harmonie (Rosalina) (24 442), Bowser ♂ (21 353), Daisy (20 747), Mario ♂ (11 055), Bowsette (version féminine de Bowser, création de fans, 2018) (8 977) |
| 14 | Resident Evil | 6 | 5 | 1 | 0 | 92 741 | 13 | Jill Valentine (25 551), Ada Wong (23 269), Claire Redfield (12 505), Lady Dimitrescu (11 846), Ashley Graham (11 193), Leon S. Kennedy ♂ (8 377) |
| 15 | Fate | 6 | 4 | 2 | 0 | 73 177 | 20 | Artoria Pendragon (20 563), Astolfo ♂ (17 065), Ritsuka Fujimaru (version masculine) ♂ (9 338), Minamoto no Raikou (8 975), Mash Kyrielight (8 624), Rin Tohsaka (8 612) |
| 16 | Five Nights at Freddy's | 6 | 3 | 3 | 0 | 63 044 | 25 | Toy Chica (14 905), Foxy ♂ (12 879), Roxanne Wolf (11 401), Freddy Fazbear ♂ (8 525), Bonnie ♂ (8 339), Chica (6 995) |
| 17 | One Piece | 5 | 4 | 1 | 0 | 137 985 | 14 | Nami (58 263), Nico Robin (35 080), Boa Hancock (19 886), Monkey D. Luffy ♂ (13 060), Yamato (11 696) |
| 18 | Bleach | 5 | 4 | 1 | 0 | 78 109 | 16 | Yoruichi (21 936), Orihime Inoue (19 208), Rangiku Matsumoto (17 804), Rukia Kuchiki (12 551), Ichigo Kurosaki ♂ (6 610) |
| 19 | Chainsaw Man | 5 | 4 | 1 | 0 | 76 393 | 17 | Makima (34 383), Power (16 185), Reze (9 293), Kobeni Higashiyama (9 184), Denji ♂ (7 348) |
| 20 | RWBY | 4 | 4 | 0 | 0 | 58 660 | 18 | Yang Xiao Long (17 965), Ruby Rose (15 701), Weiss Schnee (14 113), Blake Belladonna (10 881) |
| 21 | Undertale | 4 | 1 | 1 | 2 | 49 189 | 63 | Toriel (24 145), Asriel Dreemurr ♂ (9 224), Frisk (genre non défini) (8 006), Chara (genre non défini) (7 814) |
| 22 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 4 | 4 | 0 | 0 | 48 070 | 19 | Korra (13 757), Azula (12 587), Katara (12 083), Toph Beifong (9 643) |
| 23 | Deltarune | 4 | 2 | 1 | 1 | 37 365 | 53 | Kris (genre non défini) (10 733), Ralsei ♂ (9 845), Susie (9 501), Noelle Holiday (7 286) |
| 24 | Fire Emblem | 4 | 3 | 0 | 1 | 35 487 | 27 | Byleth (version féminine) (10 952), Lucina (8 865), Camilla (7 940), Corrin (genre non défini) (7 730) |
| 25 | Blue Archive | 4 | 3 | 0 | 1 | 32 959 | 28 | Asuna (11 612), Karin (Kakudate Karin) (7 334), Rio (Tsukatsuki Rio) (7 060), Sensei (genre non défini) (6 953) |
| 26 | The Legend of Zelda | 3 | 2 | 1 | 0 | 88 048 | 34 | Princesse Zelda (39 792), Link ♂ (33 171), Midna (15 085) |
| 27 | Final Fantasy VII | 3 | 2 | 1 | 0 | 82 314 | 33 | Tifa Lockhart (54 505), Aerith Gainsborough (15 799), Cloud Strife ♂ (12 010) |
| 28 | Street Fighter | 3 | 3 | 0 | 0 | 76 872 | 21 | Chun-Li (41 013), Cammy (18 735), Juri Han (17 124) |
| 29 | Helluva Boss | 3 | 2 | 1 | 0 | 60 705 | 35 | Loona (43 049), Millie (9 057), Moxxie ♂ (8 599) |
| 30 | KonoSuba | 3 | 3 | 0 | 0 | 46 821 | 22 | Aqua (19 839), Megumin (15 208), Darkness (11 774) |
| 31 | The Witcher | 3 | 3 | 0 | 0 | 44 334 | 23 | Ciri (20 518), Yennefer (12 861), Triss Merigold (10 955) |
| 32 | Demon Slayer | 3 | 3 | 0 | 0 | 40 978 | 24 | Mitsuri Kanroji (16 655), Shinobu Kocho (14 569), Nezuko Kamado (9 754) |
| 33 | Doki Doki Literature Club | 3 | 3 | 0 | 0 | 29 896 | 26 | Monika (12 511), Natsuki (8 919), Yuri (8 466) |
| 34 | Mass Effect | 3 | 3 | 0 | 0 | 25 684 | 29 | Liara T'Soni (10 343), Commandant Shepard (version féminine) (7 700), Miranda Lawson (7 641) |
| 35 | Adventure Time | 3 | 2 | 1 | 0 | 25 517 | 51 | Princesse Chewing-gum (9 974), Marceline (8 284), Finn ♂ (7 259) |
| 36 | Splatoon | 3 | 3 | 0 | 0 | 25 067 | 30 | Marina (10 291), Marie (7 911), Callie (6 865) |
| 37 | Touhou Project | 3 | 3 | 0 | 0 | 24 971 | 31 | Reimu Hakurei (10 571), Sanae Kochiya (7 227), Sakuya Izayoi (7 173) |
| 38 | Hololive | 3 | 3 | 0 | 0 | 22 178 | 32 | Ouro Kronii (7 959), Mori Calliope (7 114), Houshou Marine (7 105) |

*Les franchises à 1 ou 2 personnages figurent dans le CSV.*

## 2. Par publications cumulées (top 30)

| # | Franchise | Publications cumulées | Part | Personnages | dont ♂ |
|---|---|---|---|---|---|
| 1 | Naruto | 224 524 | 4,5 % | 10 | 3 |
| 2 | Sonic | 220 467 | 4,5 % | 10 | 4 |
| 3 | Genshin Impact | 216 687 | 4,4 % | 17 | 2 |
| 4 | My Little Pony | 213 810 | 4,3 % | 13 | 3 |
| 5 | Pokémon | 202 767 | 4,1 % | 18 | 1 |
| 6 | DC Comics | 191 532 | 3,9 % | 12 | 3 |
| 7 | My Hero Academia | 185 943 | 3,8 % | 10 | 2 |
| 8 | Overwatch | 178 118 | 3,6 % | 9 | 0 |
| 9 | Marvel | 154 357 | 3,1 % | 12 | 2 |
| 10 | One Piece | 137 985 | 2,8 % | 5 | 1 |
| 11 | Super Mario | 137 126 | 2,8 % | 6 | 2 |
| 12 | League of Legends | 118 558 | 2,4 % | 11 | 0 |
| 13 | Dragon Ball | 115 265 | 2,3 % | 8 | 1 |
| 14 | Resident Evil | 92 741 | 1,9 % | 6 | 1 |
| 15 | The Legend of Zelda | 88 048 | 1,8 % | 3 | 1 |
| 16 | Final Fantasy VII | 82 314 | 1,7 % | 3 | 1 |
| 17 | Bleach | 78 109 | 1,6 % | 5 | 1 |
| 18 | Street Fighter | 76 872 | 1,6 % | 3 | 0 |
| 19 | Chainsaw Man | 76 393 | 1,5 % | 5 | 1 |
| 20 | Fate | 73 177 | 1,5 % | 6 | 2 |
| 21 | Zenless Zone Zero | 70 940 | 1,4 % | 8 | 1 |
| 22 | Five Nights at Freddy's | 63 044 | 1,3 % | 6 | 3 |
| 23 | Helluva Boss | 60 705 | 1,2 % | 3 | 1 |
| 24 | RWBY | 58 660 | 1,2 % | 4 | 0 |
| 25 | NieR: Automata | 50 283 | 1,0 % | 2 | 1 |
| 26 | Undertale | 49 189 | 1,0 % | 4 | 1 |
| 27 | Frieren | 48 331 | 1,0 % | 2 | 0 |
| 28 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 48 070 | 1,0 % | 4 | 0 |
| 29 | KonoSuba | 46 821 | 0,9 % | 3 | 0 |
| 30 | The Witcher | 44 334 | 0,9 % | 3 | 0 |
