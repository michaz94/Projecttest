# Franchises les plus représentées sur Danbooru (personnages féminins)

*Relevé du 24 octobre 2026 (API Danbooru). Base : sélection propre à Danbooru, c'est-à-dire les **293 personnages féminins les plus fréquents** (même effectif que la sélection rule34), soit tous les tags de personnage féminin à au moins **6 892 images**. Danbooru compte toutes les images, pas seulement les explicites.*

**Méthode :**
- Top 600 des tags de personnage Danbooru (catégorie 4) triés par nombre d'images.
- Genre : part des images du personnage taguées `1girl` parmi `1girl` + `1boy` (seuil 0,55), vérifiée à la main ; Anya (Spy×Family) est comptée fille malgré un ratio de 0,52 (souvent avec Loid ou Damian).
- Exclus : personnages masculins ; avatars du joueur au genre au choix (Sensei de Blue Archive, Amiral de KanColle, Dresseur d'Uma Musume, Producteur d'Idolmaster, Docteur d'Arknights, Rover, Trailblazer, Guerrier de la Lumière FF14, Inkling/Octoling joueur, Commandant d'Azur Lane) ; Kris (Deltarune) et Paimon (genre non précisé) ; espèces et créatures (Gardevoir, Pikachu, Évoli, Motisma, Kyubey, Manjuu, Kirby, Boo Tao) ; objets animés (poupée Shanghai, Rensouhou-chan, Senketsu).
- **Pas de doublons à additionner** : sur Danbooru, un tag de version (Saber, Madoka en magical girl, Shigure Kai Ni, costumes…) ajoute automatiquement le tag parent (implication), donc le parent compte déjà ces images. Les versions sont retirées pour ne pas compter deux fois. Exception : Stelle et Rover (féminin) sont gardées, car leur parent est un avatar sans genre.
- Franchise : tag Copyright le plus associé au personnage (`related_tag`). Danbooru regroupe les sous-séries sous un tag parent (Fate, The Idolmaster, Love Live!, BanG Dream!, Gundam, Final Fantasy) ; seul Honkai est séparé entre Star Rail et Impact 3rd, comme pour rule34.
- **À trancher :** Mahiro Oyama (Onimai, garçon transformé en fille, 8 008 images) est classé ambigu et non compté ; s'il est compté fille, il entre à la place de Ishmael (Project Moon (Limbus Company), 6 892). Les VTubers Hololive/Nijisanji sont comptées : Danbooru les classe comme personnages.

**54 franchises**, dont 20 avec un seul personnage. Fichiers de détail : `danbooru/selection_293_personnages_feminins_danbooru_2026-10-24.csv`, `danbooru/tri_top600_personnages_danbooru_2026-10-24.csv` (chaque exclusion avec son motif).

## 1. Par nombre de personnages

Départage à égalité : images cumulées. Colonne rule34 = nombre de personnages de la franchise dans la sélection rule34 des 293.

| # | Franchise | Personnages | Images cumulées | Moyenne | rule34 | Personnages (images) |
|---|---|---|---|---|---|---|
| 1 | Touhou Project | 66 | 1 508 560 | 22 857 | 3 | Hakurei Reimu (102 567), Kirisame Marisa (88 697), Flandre Scarlet (64 114), Remilia Scarlet (63 424), Izayoi Sakuya (53 945), Komeiji Koishi (46 052), Kochiya Sanae (41 529), Konpaku Youmu (41 307), Cirno (41 297), Alice Margatroid (40 243), Patchouli Knowledge (39 339), Yakumo Yukari (39 002), Shameimaru Aya (34 655), Reisen Udongein Inaba (31 584), Komeiji Satori (31 407), Fujiwara No Mokou (30 991), Hong Meiling (28 523), Saigyouji Yuyuko (28 322), Inubashiri Momiji (26 361), Yakumo Ran (23 136), Kaenbyou Rin (23 007), Rumia (22 669), Moriya Suwako (22 258), Reiuji Utsuho (20 847), Chen (20 815), Kazami Yuuka (20 461), Tatara Kogasa (18 855), Kawashiro Nitori (18 831), Houraisan Kaguya (18 244), Hinanawi Tenshi (18 102), Kamishirasawa Keine (17 991), Koakuma (16 386), Mystia Lorelei (16 327), Nazrin (16 292), Ibuki Suika (16 203), Inaba Tewi (15 908), Usami Renko (15 726), Maribel Hearn (15 348), Hijiri Byakuren (14 790), Houjuu Nue (14 247), Yagokoro Eirin (13 507), Mizuhashi Parsee (13 328), Yasaka Kanako (13 304), Kagiyama Hina (12 344), Toyosatomimi No Miko (11 539), Daiyousei (11 526), Hoshiguma Yuugi (10 694), Mononobe No Futo (10 675), Shiki Eiki (10 655), Wriggle Nightbug (10 485), Onozuka Komachi (10 406), Imaizumi Kagerou (10 234), Toramaru Shou (9 024), Himekaidou Hatate (8 960), Murasa Minamitsu (8 758), Kaku Seiga (8 490), Hata No Kokoro (8 133), Ibaraki Kasen (7 760), Nagae Iku (7 715), Miyako Yoshika (7 600), Clownpiece (7 467), Junko (7 330), Kasodani Kyouko (7 252), Soga No Tojiko (7 248), Kumoi Ichirin (7 166), Kurodani Yamame (7 158) |
| 2 | Kantai Collection | 28 | 317 631 | 11 344 | 0 | Kaga (22 236), Shimakaze (20 841), Hibiki (18 106), Shigure (17 858), Kongou (14 084), Inazuma (13 583), Akagi (13 023), Fubuki (12 988), Yuudachi (12 210), Tenryuu (12 042), Ikazuchi (11 471), Hamakaze (10 954), Zuikaku (10 785), Akatsuki (10 697), Haruna (10 502), Kashima (10 077), Nagato (9 842), Suzuya (9 665), Ryuujou (8 981), Houshou (8 366), Murakumo (7 801), Amatsukaze (7 791), Yamato (7 593), Yukikaze (7 478), Ushio (7 453), Atago (7 220), Akebono (6 994), Shoukaku (6 990) |
| 3 | Blue Archive | 26 | 297 391 | 11 438 | 3 | Hina (20 083), Yuuka (19 286), Asuna (18 944), Mika (16 615), Hoshino (15 525), Rio (15 201), Kisaki (13 473), Toki (12 368), Aris (12 132), Kayoko (11 919), Mari (11 820), Shiroko (11 667), Kazusa (11 403), Koharu (10 418), Seia (9 726), Noa (8 748), Karin (8 717), Plana (8 621), Kei (8 030), Arona (8 011), Momoi (7 945), Aru (7 810), Hanako (7 685), Ako (7 150), Hasumi (7 122), Nozomi (6 972) |
| 4 | Hololive (VTubers) | 25 | 267 056 | 10 682 | 3 | Houshou Marine (18 122), Gawr Gura (16 569), Shirakami Fubuki (16 277), Hoshimachi Suisei (15 473), Ouro Kronii (14 872), Ninomae Ina'nis (12 973), Mori Calliope (12 884), Usada Pekora (12 086), Nekomata Okayu (11 897), Takanashi Kiara (10 659), Sakura Miko (10 372), Tokoyami Towa (10 052), Nanashi Mumei (9 742), Minato Aqua (9 686), Ookami Mio (8 685), Oozora Subaru (8 074), Shiori Novella (7 989), Amane Kanata (7 895), Nerissa Ravencroft (7 811), Hakos Baelz (7 773), Yukihana Lamy (7 746), Watson Amelia (7 473), Inugami Korone (7 432), Shirogane Noel (7 428), Sakamata Chloe (7 086) |
| 5 | Fate | 15 | 203 037 | 13 536 | 4 | Artoria Pendragon (46 589), Mash Kyrielight (21 101), Fujimaru Ritsuka (version féminine) (16 648), Jeanne d'Arc Alter (13 896), Abigail Williams (12 776), Nero Claudius (11 477), Illyasviel von Einzbern (11 232), Tohsaka Rin (11 022), Scathach (9 553), Tamamo no Mae (9 232), Jeanne d'Arc (8 810), Okita Souji (7 997), Baobhan Sith (7 909), Shuten Douji (7 868), Matou Sakura (6 927) |
| 6 | Genshin Impact | 13 | 170 699 | 13 131 | 15 | Lumine (22 526), Raiden Shogun (22 191), Ganyu (20 301), Hu Tao (14 677), Furina (14 220), Nahida (13 637), Yae Miko (12 564), Columbina (10 163), Mona (10 025), Keqing (8 469), Kamisato Ayaka (7 422), Klee (7 279), Sandrone (7 225) |
| 7 | Love Live! | 10 | 77 941 | 7 794 | 0 | Hinoshita Kaho (9 217), Nishikino Maki (8 441), Yazawa Nico (7 875), Tojo Nozomi (7 838), Sonoda Umi (7 764), Fujishima Megumi (7 619), Momose Ginko (7 447), Otomune Kozue (7 306), Ayase Eli (7 286), Murano Sayaka (7 148) |
| 8 | Uma Musume | 8 | 82 352 | 10 294 | 0 | Agnes Tachyon (14 682), Manhattan Cafe (13 668), Gold Ship (11 256), Rice Shower (10 302), Daiwa Scarlet (9 151), Mejiro McQueen (8 921), Tokai Teio (7 366), Oguri Cap (7 006) |
| 9 | Honkai: Star Rail | 7 | 72 659 | 10 380 | 1 | Firefly (16 858), Stelle (13 482), March 7th (9 803), Cyrene (9 293), Kafka (8 223), Sparkle (8 093), Acheron (6 907) |
| 10 | BanG Dream! | 7 | 63 876 | 9 125 | 0 | Togawa Sakiko (11 951), Chihaya Anon (11 037), Nagasaki Soyo (9 641), Misumi Uika (8 143), Shiina Taki (8 028), Wakaba Mutsumi (7 765), Yahata Umiri (7 311) |
| 11 | Pokémon | 7 | 61 554 | 8 793 | 17 | Dawn (9 689), Lillie (9 471), Rosa (9 091), May (8 947), Hilda (8 285), Marnie (8 247), Cynthia (7 824) |
| 12 | Madoka Magica | 5 | 115 273 | 23 055 | 0 | Akemi Homura (30 350), Kaname Madoka (30 338), Miki Sayaka (20 387), Sakura Kyoko (17 230), Tomoe Mami (16 968) |
| 13 | Arknights | 5 | 42 463 | 8 493 | 0 | Amiya (12 466), Texas (8 753), Lappland (7 346), Skadi (6 972), Suzuran (6 926) |
| 14 | Vocaloid | 4 | 196 077 | 49 019 | 1 | Hatsune Miku (148 218), Kagamine Rin (26 700), Megurine Luka (14 069), Meiko (7 090) |
| 15 | Zenless Zone Zero | 4 | 37 084 | 9 271 | 7 | Belle (10 422), Ellen Joe (9 830), Remielle Dan (8 672), Hoshimi Miyabi (8 160) |
| 16 | K-On! | 4 | 36 525 | 9 131 | 0 | Akiyama Mio (10 612), Nakano Azusa (9 313), Hirasawa Yui (8 991), Tainaka Ritsu (7 609) |
| 17 | Bocchi the Rock! | 3 | 35 549 | 11 850 | 1 | Gotoh Hitori (18 203), Kita Ikuyo (9 488), Ijichi Nijika (7 858) |
| 18 | Cho Kaguya-hime! | 3 | 26 022 | 8 674 | 0 | Sakayori Iroha (10 852), Kaguya (7 966), Runami Yachiyo (7 204) |
| 19 | The Idolmaster | 3 | 21 735 | 7 245 | 0 | Shibuya Rin (7 495), Shinosawa Hiro (7 218), Kisaragi Chihaya (7 022) |
| 20 | Final Fantasy | 2 | 29 492 | 14 746 | 2 | Tifa Lockhart (17 346), Aerith Gainsborough (12 146) |
| 21 | Evangelion | 2 | 28 318 | 14 159 | 2 | Souryuu Asuka Langley (17 707), Ayanami Rei (10 611) |
| 22 | UTAU / Synthesizer V | 2 | 27 047 | 13 524 | 1 | Kasane Teto (18 996), Adachi Rei (8 051) |
| 23 | Frieren | 2 | 26 354 | 13 177 | 2 | Frieren (16 473), Fern (9 881) |
| 24 | Honkai Impact 3rd | 2 | 22 041 | 11 020 | 0 | Elysia (13 901), Kiana Kaslana (8 140) |
| 25 | Chainsaw Man | 2 | 21 522 | 10 761 | 4 | Makima (11 208), Reze (10 314) |
| 26 | La Mélancolie de Haruhi Suzumiya | 2 | 20 484 | 10 242 | 0 | Suzumiya Haruhi (11 191), Nagato Yuki (9 293) |
| 27 | One Piece | 2 | 19 240 | 9 620 | 4 | Nami (11 332), Nico Robin (7 908) |
| 28 | Magical Girl Lyrical Nanoha | 2 | 18 479 | 9 240 | 0 | Fate Testarossa (10 093), Takamachi Nanoha (8 386) |
| 29 | Xenoblade Chronicles | 2 | 18 101 | 9 050 | 2 | Pyra (9 603), Mythra (8 498) |
| 30 | Girls und Panzer | 2 | 17 876 | 8 938 | 0 | Nishizumi Miho (10 781), Nishizumi Maho (7 095) |
| 31 | Lycoris Recoil | 2 | 15 522 | 7 761 | 0 | Nishikigi Chisato (8 609), Inoue Takina (6 913) |
| 32 | Gundam | 2 | 15 439 | 7 720 | 0 | Suletta Mercury (8 112), Miorine Rembran (7 327) |
| 33 | Alien Stage | 2 | 15 380 | 7 690 | 0 | Sua (7 840), Mizi (7 540) |
| 34 | Girls Band Cry | 2 | 15 358 | 7 679 | 0 | Iseri Nina (7 928), Kawaragi Momoka (7 430) |

*Franchises à un seul personnage : The Legend of Zelda (Princess Zelda (17 092)), Danganronpa (Nanami Chiaki (14 101)), NieR (2B (12 524)), Spy×Family (Yor Briar (11 618)), KonoSuba (Megumin (10 967)), A Certain Magical Index / Railgun (Misaka Mikoto (10 943)), Re:Zero (Rem (10 404)), VOICEROID (Yuzuki Yukari (9 956)), Street Fighter (Chun-li (9 312)), Card Captor Sakura (Kinomoto Sakura (9 119)), Kill la Kill (Matoi Ryuuko (8 835)), Super Mario (Princess Peach (8 759)), Kemono Friends (Serval (8 411)), Gochūmon wa Usagi Desu ka? (Kafuu Chino (8 324)), Metroid (Samus Aran (8 252)), Fire Emblem (Byleth (version féminine) (7 496)), Darkstalkers (Morrigan Aensland (7 320)), Tsukihime (Arcueid Brunestud (7 077)), Sailor Moon (Tsukino Usagi (6 915)), Project Moon (Limbus Company) (Ishmael (6 892)).*

## 2. Par images cumulées (top 25)

| # | Franchise | Images cumulées | Part des 293 | Personnages |
|---|---|---|---|---|
| 1 | Touhou Project | 1 508 560 | 36,5 % | 66 |
| 2 | Kantai Collection | 317 631 | 7,7 % | 28 |
| 3 | Blue Archive | 297 391 | 7,2 % | 26 |
| 4 | Hololive (VTubers) | 267 056 | 6,5 % | 25 |
| 5 | Fate | 203 037 | 4,9 % | 15 |
| 6 | Vocaloid | 196 077 | 4,7 % | 4 |
| 7 | Genshin Impact | 170 699 | 4,1 % | 13 |
| 8 | Madoka Magica | 115 273 | 2,8 % | 5 |
| 9 | Uma Musume | 82 352 | 2,0 % | 8 |
| 10 | Love Live! | 77 941 | 1,9 % | 10 |
| 11 | Honkai: Star Rail | 72 659 | 1,8 % | 7 |
| 12 | BanG Dream! | 63 876 | 1,5 % | 7 |
| 13 | Pokémon | 61 554 | 1,5 % | 7 |
| 14 | Arknights | 42 463 | 1,0 % | 5 |
| 15 | Zenless Zone Zero | 37 084 | 0,9 % | 4 |
| 16 | K-On! | 36 525 | 0,9 % | 4 |
| 17 | Bocchi the Rock! | 35 549 | 0,9 % | 3 |
| 18 | Final Fantasy | 29 492 | 0,7 % | 2 |
| 19 | Evangelion | 28 318 | 0,7 % | 2 |
| 20 | UTAU / Synthesizer V | 27 047 | 0,7 % | 2 |
| 21 | Frieren | 26 354 | 0,6 % | 2 |
| 22 | Cho Kaguya-hime! | 26 022 | 0,6 % | 3 |
| 23 | Honkai Impact 3rd | 22 041 | 0,5 % | 2 |
| 24 | The Idolmaster | 21 735 | 0,5 % | 3 |
| 25 | Chainsaw Man | 21 522 | 0,5 % | 2 |

## 3. Comparaison avec la sélection rule34

- **58 personnages sur 293** figurent dans les deux sélections : Hatsune Miku, Hakurei Reimu, Izayoi Sakuya, Artoria Pendragon, Kochiya Sanae, Lumine, Raiden Shogun, Mash Kyrielight, Ganyu, Kasane Teto, Asuna, Gotoh Hitori, Houshou Marine, Souryuu Asuka Langley, Tifa Lockhart, Princess Zelda, Frieren, Rio, Ouro Kronii, Hu Tao, Furina, Mori Calliope, Yae Miko, 2B, Aerith Gainsborough, Yor Briar, Nami, Makima, Tohsaka Rin, Megumin, Ayanami Rei, Belle, Rem, Reze, Mona, Fern, Ellen Joe, Dawn, Pyra, Lillie, Chun-li, Rosa, May, Matoi Ryuuko, Princess Peach, Karin, Mythra, Keqing, Hilda, Samus Aran, Marnie, Kafka, Nico Robin, Cynthia, Byleth (version féminine), Kamisato Ayaka, Morrigan Aensland, Tsukino Usagi.
- Franchises à au moins 3 personnages dans la sélection rule34 mais **absentes** des 293 de Danbooru : League of Legends (11), My Little Pony (10), Marvel (10), Overwatch (9), DC Comics (9), My Hero Academia (8), Naruto (7), Dragon Ball (7), Sonic (6), Resident Evil (5), Bleach (4), RWBY (4), Avatar (Le Dernier Maître de l'air + La Légende de Korra) (4), The Witcher (3), Demon Slayer (3), Five Nights at Freddy's (3), Doki Doki Literature Club (3), Mass Effect (3), Splatoon (3), Hololive (3). Leurs personnages ont moins de 6 892 images sur Danbooru, par exemple Raven (39 707 publications sur rule34, 1 954 images sur Danbooru) ou Loona (43 049 contre 592).
- Franchises très présentes sur Danbooru mais (presque) absentes de rule34 : Kantai Collection (28 contre 0), Love Live! (10 contre 0), Uma Musume (8 contre 0), Honkai: Star Rail (7 contre 1), BanG Dream! (7 contre 0), Madoka Magica (5 contre 0), Arknights (5 contre 0).
- Interprétation (non mesurée) : Danbooru est une base d'illustrations surtout japonaises (fan art, doujin, tout public compris) ; rule34.xxx est un site explicite avec une forte part occidentale (comics, cartoons, furry, jeux occidentaux). Les deux classements mesurent donc deux publics différents.
