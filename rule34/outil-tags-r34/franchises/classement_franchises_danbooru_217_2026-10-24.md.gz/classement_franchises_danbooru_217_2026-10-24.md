# Franchises les plus représentées sur Danbooru (personnages féminins)

*Relevé du 24 octobre 2026 (API Danbooru). Base : sélection propre à Danbooru, c'est-à-dire les **217 personnages féminins les plus fréquents** (même effectif que la sélection rule34), soit tous les tags de personnage féminin à au moins **7 997 images**. Danbooru compte toutes les images, pas seulement les explicites.*

**Méthode :**
- Top 600 des tags de personnage Danbooru (catégorie 4) triés par nombre d'images.
- Genre : part des images du personnage taguées `1girl` parmi `1girl` + `1boy` (seuil 0,55), vérifiée à la main ; Anya (Spy×Family) est comptée fille malgré un ratio de 0,52 (souvent avec Loid ou Damian).
- Exclus : personnages masculins ; avatars du joueur au genre au choix (Sensei de Blue Archive, Amiral de KanColle, Dresseur d'Uma Musume, Producteur d'Idolmaster, Docteur d'Arknights, Rover, Trailblazer, Guerrier de la Lumière FF14, Inkling/Octoling joueur, Commandant d'Azur Lane) ; Kris (Deltarune) et Paimon (genre non précisé) ; espèces et créatures (Gardevoir, Pikachu, Évoli, Motisma, Kyubey, Manjuu, Kirby, Boo Tao) ; objets animés (poupée Shanghai, Rensouhou-chan, Senketsu).
- **Pas de doublons à additionner** : sur Danbooru, un tag de version (Saber, Madoka en magical girl, Shigure Kai Ni, costumes…) ajoute automatiquement le tag parent (implication), donc le parent compte déjà ces images. Les versions sont retirées pour ne pas compter deux fois. Exception : Stelle et Rover (féminin) sont gardées, car leur parent est un avatar sans genre.
- Franchise : tag Copyright le plus associé au personnage (`related_tag`). Danbooru regroupe les sous-séries sous un tag parent (Fate, The Idolmaster, Love Live!, BanG Dream!, Gundam, Final Fantasy) ; seul Honkai est séparé entre Star Rail et Impact 3rd, comme pour rule34.
- **À trancher :** Mahiro Oyama (Onimai, garçon transformé en fille, 8 008 images) est classé ambigu et non compté ; s'il est compté fille, il entre à la place d'Okita Sōji (Fate, 7 997). Les VTubers Hololive/Nijisanji sont comptées : Danbooru les classe comme personnages.

**46 franchises**, dont 20 avec un seul personnage. Fichiers de détail : `danbooru/selection_217_personnages_feminins_danbooru_2026-10-24.csv`, `danbooru/tri_top600_personnages_danbooru_2026-10-24.csv` (chaque exclusion avec son motif).

## 1. Par nombre de personnages

Départage à égalité : images cumulées. Colonne rule34 = nombre de personnages de la franchise dans la sélection rule34 des 217.

| # | Franchise | Personnages | Images cumulées | Moyenne | rule34 | Personnages (images) |
|---|---|---|---|---|---|---|
| 1 | Touhou Project | 57 | 1 441 864 | 25 296 | 1 | Hakurei Reimu (102 567), Kirisame Marisa (88 697), Flandre Scarlet (64 114), Remilia Scarlet (63 424), Izayoi Sakuya (53 945), Komeiji Koishi (46 052), Kochiya Sanae (41 529), Konpaku Youmu (41 307), Cirno (41 297), Alice Margatroid (40 243), Patchouli Knowledge (39 339), Yakumo Yukari (39 002), Shameimaru Aya (34 655), Reisen Udongein Inaba (31 584), Komeiji Satori (31 407), Fujiwara No Mokou (30 991), Hong Meiling (28 523), Saigyouji Yuyuko (28 322), Inubashiri Momiji (26 361), Yakumo Ran (23 136), Kaenbyou Rin (23 007), Rumia (22 669), Moriya Suwako (22 258), Reiuji Utsuho (20 847), Chen (20 815), Kazami Yuuka (20 461), Tatara Kogasa (18 855), Kawashiro Nitori (18 831), Houraisan Kaguya (18 244), Hinanawi Tenshi (18 102), Kamishirasawa Keine (17 991), Koakuma (16 386), Mystia Lorelei (16 327), Nazrin (16 292), Ibuki Suika (16 203), Inaba Tewi (15 908), Usami Renko (15 726), Maribel Hearn (15 348), Hijiri Byakuren (14 790), Houjuu Nue (14 247), Yagokoro Eirin (13 507), Mizuhashi Parsee (13 328), Yasaka Kanako (13 304), Kagiyama Hina (12 344), Toyosatomimi No Miko (11 539), Daiyousei (11 526), Hoshiguma Yuugi (10 694), Mononobe No Futo (10 675), Shiki Eiki (10 655), Wriggle Nightbug (10 485), Onozuka Komachi (10 406), Imaizumi Kagerou (10 234), Toramaru Shou (9 024), Himekaidou Hatate (8 960), Murasa Minamitsu (8 758), Kaku Seiga (8 490), Hata No Kokoro (8 133) |
| 2 | Kantai Collection | 20 | 258 311 | 12 916 | 0 | Kaga (22 236), Shimakaze (20 841), Hibiki (18 106), Shigure (17 858), Kongou (14 084), Inazuma (13 583), Akagi (13 023), Fubuki (12 988), Yuudachi (12 210), Tenryuu (12 042), Ikazuchi (11 471), Hamakaze (10 954), Zuikaku (10 785), Akatsuki (10 697), Haruna (10 502), Kashima (10 077), Nagato (9 842), Suzuya (9 665), Ryuujou (8 981), Houshou (8 366) |
| 3 | Blue Archive | 20 | 252 707 | 12 635 | 1 | Hina (20 083), Yuuka (19 286), Asuna (18 944), Mika (16 615), Hoshino (15 525), Rio (15 201), Kisaki (13 473), Toki (12 368), Aris (12 132), Kayoko (11 919), Mari (11 820), Shiroko (11 667), Kazusa (11 403), Koharu (10 418), Seia (9 726), Noa (8 748), Karin (8 717), Plana (8 621), Kei (8 030), Arona (8 011) |
| 4 | Hololive (VTubers) | 16 | 198 423 | 12 401 | 0 | Houshou Marine (18 122), Gawr Gura (16 569), Shirakami Fubuki (16 277), Hoshimachi Suisei (15 473), Ouro Kronii (14 872), Ninomae Ina'nis (12 973), Mori Calliope (12 884), Usada Pekora (12 086), Nekomata Okayu (11 897), Takanashi Kiara (10 659), Sakura Miko (10 372), Tokoyami Towa (10 052), Nanashi Mumei (9 742), Minato Aqua (9 686), Ookami Mio (8 685), Oozora Subaru (8 074) |
| 5 | Fate | 12 | 180 333 | 15 028 | 3 | Artoria Pendragon (46 589), Mash Kyrielight (21 101), Fujimaru Ritsuka (version féminine) (16 648), Jeanne d'Arc Alter (13 896), Abigail Williams (12 776), Nero Claudius (11 477), Illyasviel von Einzbern (11 232), Tohsaka Rin (11 022), Scathach (9 553), Tamamo no Mae (9 232), Jeanne d'Arc (8 810), Okita Souji (7 997) |
| 6 | Genshin Impact | 10 | 148 773 | 14 877 | 11 | Lumine (22 526), Raiden Shogun (22 191), Ganyu (20 301), Hu Tao (14 677), Furina (14 220), Nahida (13 637), Yae Miko (12 564), Columbina (10 163), Mona (10 025), Keqing (8 469) |
| 7 | Uma Musume | 6 | 67 980 | 11 330 | 0 | Agnes Tachyon (14 682), Manhattan Cafe (13 668), Gold Ship (11 256), Rice Shower (10 302), Daiwa Scarlet (9 151), Mejiro McQueen (8 921) |
| 8 | Honkai: Star Rail | 6 | 65 752 | 10 959 | 1 | Firefly (16 858), Stelle (13 482), March 7th (9 803), Cyrene (9 293), Kafka (8 223), Sparkle (8 093) |
| 9 | Pokémon | 6 | 53 730 | 8 955 | 12 | Dawn (9 689), Lillie (9 471), Rosa (9 091), May (8 947), Hilda (8 285), Marnie (8 247) |
| 10 | Madoka Magica | 5 | 115 273 | 23 055 | 0 | Akemi Homura (30 350), Kaname Madoka (30 338), Miki Sayaka (20 387), Sakura Kyoko (17 230), Tomoe Mami (16 968) |
| 11 | BanG Dream! | 5 | 48 800 | 9 760 | 0 | Togawa Sakiko (11 951), Chihaya Anon (11 037), Nagasaki Soyo (9 641), Misumi Uika (8 143), Shiina Taki (8 028) |
| 12 | Zenless Zone Zero | 4 | 37 084 | 9 271 | 4 | Belle (10 422), Ellen Joe (9 830), Remielle Dan (8 672), Hoshimi Miyabi (8 160) |
| 13 | Vocaloid | 3 | 188 987 | 62 996 | 1 | Hatsune Miku (148 218), Kagamine Rin (26 700), Megurine Luka (14 069) |
| 14 | K-On! | 3 | 28 916 | 9 639 | 0 | Akiyama Mio (10 612), Nakano Azusa (9 313), Hirasawa Yui (8 991) |
| 15 | Final Fantasy | 2 | 29 492 | 14 746 | 2 | Tifa Lockhart (17 346), Aerith Gainsborough (12 146) |
| 16 | Evangelion | 2 | 28 318 | 14 159 | 2 | Souryuu Asuka Langley (17 707), Ayanami Rei (10 611) |
| 17 | Bocchi the Rock! | 2 | 27 691 | 13 846 | 0 | Gotoh Hitori (18 203), Kita Ikuyo (9 488) |
| 18 | UTAU / Synthesizer V | 2 | 27 047 | 13 524 | 1 | Kasane Teto (18 996), Adachi Rei (8 051) |
| 19 | Frieren | 2 | 26 354 | 13 177 | 2 | Frieren (16 473), Fern (9 881) |
| 20 | Honkai Impact 3rd | 2 | 22 041 | 11 020 | 0 | Elysia (13 901), Kiana Kaslana (8 140) |
| 21 | Chainsaw Man | 2 | 21 522 | 10 761 | 4 | Makima (11 208), Reze (10 314) |
| 22 | Arknights | 2 | 21 219 | 10 610 | 0 | Amiya (12 466), Texas (8 753) |
| 23 | La Mélancolie de Haruhi Suzumiya | 2 | 20 484 | 10 242 | 0 | Suzumiya Haruhi (11 191), Nagato Yuki (9 293) |
| 24 | Magical Girl Lyrical Nanoha | 2 | 18 479 | 9 240 | 0 | Fate Testarossa (10 093), Takamachi Nanoha (8 386) |
| 25 | Xenoblade Chronicles | 2 | 18 101 | 9 050 | 2 | Pyra (9 603), Mythra (8 498) |
| 26 | Love Live! | 2 | 17 658 | 8 829 | 0 | Hinoshita Kaho (9 217), Nishikino Maki (8 441) |

*Franchises à un seul personnage : The Legend of Zelda (Princess Zelda (17 092)), Danganronpa (Nanami Chiaki (14 101)), NieR (2B (12 524)), Spy×Family (Yor Briar (11 618)), One Piece (Nami (11 332)), KonoSuba (Megumin (10 967)), A Certain Magical Index / Railgun (Misaka Mikoto (10 943)), Cho Kaguya-hime! (Sakayori Iroha (10 852)), Girls und Panzer (Nishizumi Miho (10 781)), Re:Zero (Rem (10 404)), VOICEROID (Yuzuki Yukari (9 956)), Street Fighter (Chun-li (9 312)), Card Captor Sakura (Kinomoto Sakura (9 119)), Kill la Kill (Matoi Ryuuko (8 835)), Super Mario (Princess Peach (8 759)), Lycoris Recoil (Nishikigi Chisato (8 609)), Kemono Friends (Serval (8 411)), Gochūmon wa Usagi Desu ka? (Kafuu Chino (8 324)), Metroid (Samus Aran (8 252)), Gundam (Suletta Mercury (8 112)).*

## 2. Par images cumulées (top 25)

| # | Franchise | Images cumulées | Part des 217 | Personnages |
|---|---|---|---|---|
| 1 | Touhou Project | 1 441 864 | 40,3 % | 57 |
| 2 | Kantai Collection | 258 311 | 7,2 % | 20 |
| 3 | Blue Archive | 252 707 | 7,1 % | 20 |
| 4 | Hololive (VTubers) | 198 423 | 5,6 % | 16 |
| 5 | Vocaloid | 188 987 | 5,3 % | 3 |
| 6 | Fate | 180 333 | 5,0 % | 12 |
| 7 | Genshin Impact | 148 773 | 4,2 % | 10 |
| 8 | Madoka Magica | 115 273 | 3,2 % | 5 |
| 9 | Uma Musume | 67 980 | 1,9 % | 6 |
| 10 | Honkai: Star Rail | 65 752 | 1,8 % | 6 |
| 11 | Pokémon | 53 730 | 1,5 % | 6 |
| 12 | BanG Dream! | 48 800 | 1,4 % | 5 |
| 13 | Zenless Zone Zero | 37 084 | 1,0 % | 4 |
| 14 | Final Fantasy | 29 492 | 0,8 % | 2 |
| 15 | K-On! | 28 916 | 0,8 % | 3 |
| 16 | Evangelion | 28 318 | 0,8 % | 2 |
| 17 | Bocchi the Rock! | 27 691 | 0,8 % | 2 |
| 18 | UTAU / Synthesizer V | 27 047 | 0,8 % | 2 |
| 19 | Frieren | 26 354 | 0,7 % | 2 |
| 20 | Honkai Impact 3rd | 22 041 | 0,6 % | 2 |
| 21 | Chainsaw Man | 21 522 | 0,6 % | 2 |
| 22 | Arknights | 21 219 | 0,6 % | 2 |
| 23 | La Mélancolie de Haruhi Suzumiya | 20 484 | 0,6 % | 2 |
| 24 | Magical Girl Lyrical Nanoha | 18 479 | 0,5 % | 2 |
| 25 | Xenoblade Chronicles | 18 101 | 0,5 % | 2 |

## 3. Comparaison avec la sélection rule34

- **42 personnages sur 217** figurent dans les deux sélections : Hatsune Miku, Hakurei Reimu, Artoria Pendragon, Lumine, Raiden Shogun, Ganyu, Kasane Teto, Asuna, Souryuu Asuka Langley, Tifa Lockhart, Princess Zelda, Frieren, Hu Tao, Furina, Yae Miko, 2B, Aerith Gainsborough, Yor Briar, Nami, Makima, Tohsaka Rin, Megumin, Ayanami Rei, Belle, Rem, Reze, Mona, Fern, Ellen Joe, Dawn, Pyra, Lillie, Chun-li, Rosa, May, Matoi Ryuuko, Princess Peach, Mythra, Hilda, Samus Aran, Marnie, Kafka.
- Franchises à au moins 3 personnages dans la sélection rule34 mais **absentes** des 217 de Danbooru : My Little Pony (8), Overwatch (8), DC Comics (7), Marvel (7), Naruto (6), Sonic (6), My Hero Academia (6), Dragon Ball (5), Resident Evil (5), League of Legends (5), Bleach (4), RWBY (4), Avatar (Le Dernier Maître de l'air + La Légende de Korra) (4), The Witcher (3), Demon Slayer (3), Doki Doki Literature Club (3). Leurs personnages ont moins de 7 997 images sur Danbooru, par exemple Raven (39 707 publications sur rule34, 1 954 images sur Danbooru) ou Loona (43 049 contre 592).
- Franchises très présentes sur Danbooru mais (presque) absentes de rule34 : Touhou (57 contre 1), Kantai Collection (20 contre 0), Blue Archive (20 contre 1), Hololive (16 contre 0), Uma Musume (6 contre 0), Madoka Magica (5 contre 0), BanG Dream! (5 contre 0).
- Interprétation (non mesurée) : Danbooru est une base d'illustrations surtout japonaises (fan art, doujin, tout public compris) ; rule34.xxx est un site explicite avec une forte part occidentale (comics, cartoons, furry, jeux occidentaux). Les deux classements mesurent donc deux publics différents.
