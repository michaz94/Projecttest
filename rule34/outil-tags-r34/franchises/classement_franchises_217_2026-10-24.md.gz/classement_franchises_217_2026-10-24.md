# Franchises les plus représentées (personnages féminins, rule34.xxx)

*Relevé du 24 octobre 2026. Base : les 217 personnages féminins de `doublons/selection_217_dedupliquee_audit_2026-10-24.csv`, c'est-à-dire tous les tags de personnage féminin à au moins 8 209 publications (liste des tags, pages 1 à 280). Les publications incluent les gains d'union de l'audit des doublons.*

**94 franchises** au total, dont 53 avec un seul personnage.

**Regroupements :** Sonic + Sonic the Hedgehog ; Resident Evil + RE4 + RE Village ; Naruto + Naruto / Boruto ; Avatar + La Légende de Korra (suite officielle) ; Marvel inclut la Femme invisible ; League of Legends inclut Jinx (Arcane). Gardées séparées : Hazbin Hotel et Helluva Boss (même univers de Vivziepop, mais séries distinctes) ; Undertale et Deltarune ; Vocaloid et UTAU. Marvel et DC sont des univers partagés qui regroupent beaucoup de séries.

**Limite :** seules les filles sont comptées ; une franchise riche en personnages masculins populaires (Naruto, Genshin Impact…) est donc sous-représentée par rapport à son poids total. Pour le poids total d'une franchise (tous personnages et images sans personnage), voir le Top 20 des tags Copyright (`copyright/top20_franchises_rule34_2026-10-24.csv`).

## 1. Par nombre de personnages

Départage à égalité : publications cumulées.

| # | Franchise | Personnages | Publications cumulées | Moyenne | Médium | Personnages (publications) |
|---|---|---|---|---|---|---|
| 1 | Pokémon | 12 | 161 479 | 13 457 | Jeux vidéo 11 / Animanga 1 | Cynthia (22 058), May (Flora en VF) (18 104), Misty (Ondine en VF) (18 082), Rosa (15 546), Hilda (15 539), Dawn (Aurore en VF) (14 047), Jessie (Team Rocket) (11 620), Nessa (Donna en VF) (10 470), Rosemary (Marnie) (9 208), Serena (9 105), Elsa-Mina (Lusamine) (9 049), Lilie (Lillie) (8 651) |
| 2 | Genshin Impact | 11 | 150 762 | 13 706 | Jeux vidéo | Raiden Shogun (25 757), Yae Miko (16 483), Ganyu (16 468), Lumine (15 314), Mona (14 667), Hu Tao (14 055), Eula (10 554), Furina (10 424), Arlecchino (9 440), Yelan (8 929), Shenhe (8 671) |
| 3 | My Little Pony | 8 | 175 623 | 21 953 | Furry | Twilight Sparkle (30 892), Fluttershy (26 448), Rainbow Dash (23 923), Rarity (22 555), Pinkie Pie (19 483), Applejack (18 411), Princesse Celestia (17 047), Princesse Luna (16 864) |
| 4 | Overwatch | 8 | 170 614 | 21 327 | Jeux vidéo | D.Va (35 763), Widowmaker (31 976), Mercy (30 462), Tracer (23 060), Pharah (15 243), Mei (13 901), Sombra (10 224), Kiriko (9 985) |
| 5 | DC Comics | 7 | 151 318 | 21 617 | Comics 4 / Cartoons 3 | Raven (39 707), Harley Quinn (26 362), Wonder Woman (22 974), Starfire (21 791), Supergirl (16 375), Power Girl (13 942), Catwoman (Selina Kyle) (10 167) |
| 6 | Marvel | 7 | 94 946 | 13 564 | Comics | Emma Frost (20 269), Gwen Stacy (19 716), Black Cat (Felicia Hardy) (15 119), Femme invisible (Sue Storm) (10 816), Black Widow (Natasha Romanoff) (10 379), Psylocke (Betsy Braddock / Kwannon) (10 006), Malicia (Rogue) (8 641) |
| 7 | Naruto | 6 | 165 841 | 27 640 | Animanga | Hinata Hyûga (44 141), Tsunade (40 786), Sakura Haruno (40 018), Ino Yamanaka (16 449), Sarada Uchiha (13 790), Kushina Uzumaki (10 657) |
| 8 | Sonic | 6 | 133 745 | 22 291 | Furry | Rouge the Bat (45 414), Amy Rose (41 846), Blaze the Cat (15 169), Vanilla (11 235), Cream the Rabbit (10 519), Sally Acorn (9 562) |
| 9 | My Hero Academia | 6 | 132 097 | 22 016 | Animanga | Ochako Uraraka (35 111), Miruko (31 266), Momo Yaoyorozu (18 872), Mina Ashido (17 795), Himiko Toga (15 704), Tsuyu Asui (13 349) |
| 10 | Dragon Ball | 5 | 85 652 | 17 130 | Animanga 4 / Jeux vidéo 1 | C-18 (30 868), Bulma (22 100), Chichi (14 479), Videl (9 996), C-21 (Android 21) (8 209) |
| 11 | Resident Evil | 5 | 84 364 | 16 873 | Jeux vidéo | Jill Valentine (25 551), Ada Wong (23 269), Claire Redfield (12 505), Lady Dimitrescu (11 846), Ashley Graham (11 193) |
| 12 | League of Legends | 5 | 75 842 | 15 168 | Jeux vidéo 4 / Furry 1 | Ahri (29 877), Jinx (18 144), Akali (9 947), Sona (9 097), Agneau (Lamb, moitié féminine de Kindred) (8 777) |
| 13 | One Piece | 4 | 124 925 | 31 231 | Animanga | Nami (58 263), Nico Robin (35 080), Boa Hancock (19 886), Yamato (11 696) |
| 14 | Super Mario | 4 | 104 718 | 26 180 | Jeux vidéo | Princesse Peach (50 552), Harmonie (Rosalina) (24 442), Daisy (20 747), Bowsette (version féminine de Bowser, création de fans, 2018) (8 977) |
| 15 | Bleach | 4 | 71 499 | 17 875 | Animanga | Yoruichi (21 936), Orihime Inoue (19 208), Rangiku Matsumoto (17 804), Rukia Kuchiki (12 551) |
| 16 | Chainsaw Man | 4 | 69 045 | 17 261 | Animanga | Makima (34 383), Power (16 185), Reze (9 293), Kobeni Higashiyama (9 184) |
| 17 | RWBY | 4 | 58 660 | 14 665 | Cartoons | Yang Xiao Long (17 965), Ruby Rose (15 701), Weiss Schnee (14 113), Blake Belladonna (10 881) |
| 18 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 4 | 48 070 | 12 018 | Cartoons | Korra (13 757), Azula (12 587), Katara (12 083), Toph Beifong (9 643) |
| 19 | Zenless Zone Zero | 4 | 38 790 | 9 698 | Jeux vidéo | Jane Doe (10 356), Ellen Joe (9 754), Belle (9 531), Nicole Demara (9 149) |
| 20 | Street Fighter | 3 | 76 872 | 25 624 | Jeux vidéo | Chun-Li (41 013), Cammy (18 735), Juri Han (17 124) |
| 21 | KonoSuba | 3 | 46 821 | 15 607 | Animanga | Aqua (19 839), Megumin (15 208), Darkness (11 774) |
| 22 | The Witcher | 3 | 44 334 | 14 778 | Jeux vidéo | Ciri (20 518), Yennefer (12 861), Triss Merigold (10 955) |
| 23 | Demon Slayer | 3 | 40 978 | 13 659 | Animanga | Mitsuri Kanroji (16 655), Shinobu Kocho (14 569), Nezuko Kamado (9 754) |
| 24 | Fate | 3 | 38 150 | 12 717 | Jeux vidéo | Artoria Pendragon (20 563), Minamoto no Raikou (8 975), Rin Tohsaka (8 612) |
| 25 | Doki Doki Literature Club | 3 | 29 896 | 9 965 | Jeux vidéo | Monika (12 511), Natsuki (8 919), Yuri (8 466) |
| 26 | Final Fantasy VII | 2 | 70 304 | 35 152 | Jeux vidéo | Tifa Lockhart (54 505), Aerith Gainsborough (15 799) |
| 27 | The Legend of Zelda | 2 | 54 877 | 27 438 | Jeux vidéo | Princesse Zelda (39 792), Midna (15 085) |
| 28 | Helluva Boss | 2 | 52 106 | 26 053 | Furry | Loona (43 049), Millie (9 057) |
| 29 | Frieren | 2 | 48 331 | 24 166 | Animanga | Frieren (28 757), Fern (19 574) |
| 30 | One Punch Man | 2 | 38 633 | 19 316 | Animanga | Tatsumaki (24 182), Fubuki (14 451) |
| 31 | Animal Crossing | 2 | 38 555 | 19 278 | Furry | Marie (Isabelle) (20 826), Ankha (17 729) |
| 32 | Fairy Tail | 2 | 35 618 | 17 809 | Animanga | Lucy Heartfilia (18 255), Erza Scarlet (17 363) |
| 33 | Evangelion | 2 | 29 197 | 14 598 | Animanga | Asuka Langley (19 150), Rei Ayanami (10 047) |
| 34 | High School DxD | 2 | 28 374 | 14 187 | Animanga | Rias Gremory (17 248), Akeno Himejima (11 126) |
| 35 | Five Nights at Freddy's | 2 | 26 306 | 13 153 | Furry | Toy Chica (14 905), Roxanne Wolf (11 401) |
| 36 | Xenoblade Chronicles 2 | 2 | 24 861 | 12 430 | Jeux vidéo | Pyra (14 259), Mythra (Homura, autre forme de Pyra) (10 602) |
| 37 | Kill la Kill | 2 | 22 916 | 11 458 | Animanga | Ryuko Matoi (13 701), Satsuki Kiryuin (9 215) |
| 38 | Re:Zero | 2 | 21 438 | 10 719 | Animanga | Emilia (11 705), Rem (9 733) |
| 39 | Fire Emblem | 2 | 19 817 | 9 908 | Jeux vidéo | Byleth (version féminine) (10 952), Lucina (8 865) |
| 40 | Persona 5 | 2 | 19 219 | 9 610 | Jeux vidéo | Ann Takamaki (10 521), Makoto Niijima (8 698) |
| 41 | Adventure Time | 2 | 18 258 | 9 129 | Cartoons | Princesse Chewing-gum (9 974), Marceline (8 284) |

*Les 53 franchises à un seul personnage figurent dans le CSV.*

## 2. Par publications cumulées (top 30)

| # | Franchise | Publications cumulées | Part des 217 | Personnages | Rang par nombre |
|---|---|---|---|---|---|
| 1 | My Little Pony | 175 623 | 4,7 % | 8 | 3 |
| 2 | Overwatch | 170 614 | 4,6 % | 8 | 4 |
| 3 | Naruto | 165 841 | 4,4 % | 6 | 7 |
| 4 | Pokémon | 161 479 | 4,3 % | 12 | 1 |
| 5 | DC Comics | 151 318 | 4,1 % | 7 | 5 |
| 6 | Genshin Impact | 150 762 | 4,0 % | 11 | 2 |
| 7 | Sonic | 133 745 | 3,6 % | 6 | 8 |
| 8 | My Hero Academia | 132 097 | 3,5 % | 6 | 9 |
| 9 | One Piece | 124 925 | 3,3 % | 4 | 13 |
| 10 | Super Mario | 104 718 | 2,8 % | 4 | 14 |
| 11 | Marvel | 94 946 | 2,5 % | 7 | 6 |
| 12 | Dragon Ball | 85 652 | 2,3 % | 5 | 10 |
| 13 | Resident Evil | 84 364 | 2,3 % | 5 | 11 |
| 14 | Street Fighter | 76 872 | 2,1 % | 3 | 20 |
| 15 | League of Legends | 75 842 | 2,0 % | 5 | 12 |
| 16 | Bleach | 71 499 | 1,9 % | 4 | 15 |
| 17 | Final Fantasy VII | 70 304 | 1,9 % | 2 | 26 |
| 18 | Chainsaw Man | 69 045 | 1,8 % | 4 | 16 |
| 19 | RWBY | 58 660 | 1,6 % | 4 | 17 |
| 20 | The Legend of Zelda | 54 877 | 1,5 % | 2 | 27 |
| 21 | Helluva Boss | 52 106 | 1,4 % | 2 | 28 |
| 22 | Frieren | 48 331 | 1,3 % | 2 | 29 |
| 23 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 48 070 | 1,3 % | 4 | 18 |
| 24 | KonoSuba | 46 821 | 1,3 % | 3 | 21 |
| 25 | The Witcher | 44 334 | 1,2 % | 3 | 22 |
| 26 | NieR: Automata | 43 048 | 1,2 % | 1 | 42 |
| 27 | Vocaloid | 41 506 | 1,1 % | 1 | 43 |
| 28 | Demon Slayer | 40 978 | 1,1 % | 3 | 23 |
| 29 | Zenless Zone Zero | 38 790 | 1,0 % | 4 | 19 |
| 30 | One Punch Man | 38 633 | 1,0 % | 2 | 30 |
