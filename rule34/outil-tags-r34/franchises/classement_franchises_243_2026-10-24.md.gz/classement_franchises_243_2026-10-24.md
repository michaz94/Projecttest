# Franchises les plus représentées (personnages féminins, rule34.xxx)

*Relevé du 24 octobre 2026. Base : les 243 personnages féminins de `doublons/selection_243_dedupliquee_audit_2026-10-24.csv`, c'est-à-dire tous les tags de personnage féminin à au moins 7 491 publications (liste des tags, pages 1 à 300). Les publications incluent les gains d'union de l'audit des doublons.*

**100 franchises** au total, dont 53 avec un seul personnage.

**Regroupements :** Sonic + Sonic the Hedgehog ; Resident Evil + RE4 + RE Village ; Naruto + Naruto / Boruto ; Avatar + La Légende de Korra (suite officielle) ; Marvel inclut la Femme invisible ; League of Legends inclut Jinx (Arcane). Gardées séparées : Hazbin Hotel et Helluva Boss (même univers de Vivziepop, mais séries distinctes) ; Undertale et Deltarune ; Vocaloid et UTAU. Marvel et DC sont des univers partagés qui regroupent beaucoup de séries.

**Limite :** seules les filles sont comptées ; une franchise riche en personnages masculins populaires (Naruto, Genshin Impact…) est donc sous-représentée par rapport à son poids total. Pour le poids total d'une franchise (tous personnages et images sans personnage), voir le Top 20 des tags Copyright (`copyright/top20_franchises_rule34_2026-10-24.csv`).

## 1. Par nombre de personnages

Départage à égalité : publications cumulées.

| # | Franchise | Personnages | Publications cumulées | Moyenne | Médium | Personnages (publications) |
|---|---|---|---|---|---|---|
| 1 | Pokémon | 13 | 169 172 | 13 013 | Jeux vidéo 12 / Animanga 1 | Cynthia (22 058), May (Flora en VF) (18 104), Misty (Ondine en VF) (18 082), Rosa (15 546), Hilda (15 539), Dawn (Aurore en VF) (14 047), Jessie (Team Rocket) (11 620), Nessa (Donna en VF) (10 470), Rosemary (Marnie) (9 208), Serena (9 105), Elsa-Mina (Lusamine) (9 049), Lilie (Lillie) (8 651), Sonia (7 693) |
| 2 | Genshin Impact | 12 | 158 555 | 13 213 | Jeux vidéo | Raiden Shogun (25 757), Yae Miko (16 483), Ganyu (16 468), Lumine (15 314), Mona (14 667), Hu Tao (14 055), Eula (10 554), Furina (10 424), Arlecchino (9 440), Yelan (8 929), Shenhe (8 671), Keqing (7 793) |
| 3 | Marvel | 10 | 120 306 | 12 031 | Comics | Emma Frost (20 269), Gwen Stacy (19 716), Black Cat (Felicia Hardy) (15 119), Femme invisible (Sue Storm) (10 816), Black Widow (Natasha Romanoff) (10 379), Squirrel Girl (10 093), Psylocke (Betsy Braddock / Kwannon) (10 006), Malicia (Rogue) (8 641), She-Hulk (7 675), Mary Jane Watson (7 592) |
| 4 | Overwatch | 9 | 178 118 | 19 791 | Jeux vidéo | D.Va (35 763), Widowmaker (31 976), Mercy (30 462), Tracer (23 060), Pharah (15 243), Mei (13 901), Sombra (10 224), Kiriko (9 985), Brigitte (7 504) |
| 5 | My Little Pony | 8 | 175 623 | 21 953 | Furry | Twilight Sparkle (30 892), Fluttershy (26 448), Rainbow Dash (23 923), Rarity (22 555), Pinkie Pie (19 483), Applejack (18 411), Princesse Celestia (17 047), Princesse Luna (16 864) |
| 6 | DC Comics | 8 | 160 500 | 20 062 | Comics 5 / Cartoons 3 | Raven (39 707), Harley Quinn (26 362), Wonder Woman (22 974), Starfire (21 791), Supergirl (16 375), Power Girl (13 942), Catwoman (Selina Kyle) (10 167), Batgirl (9 182) |
| 7 | My Hero Academia | 7 | 139 590 | 19 941 | Animanga | Ochako Uraraka (35 111), Miruko (31 266), Momo Yaoyorozu (18 872), Mina Ashido (17 795), Himiko Toga (15 704), Tsuyu Asui (13 349), Kyoka Jiro (7 493) |
| 8 | League of Legends | 7 | 91 051 | 13 007 | Jeux vidéo 6 / Furry 1 | Ahri (29 877), Jinx (18 144), Akali (9 947), Sona (9 097), Agneau (Lamb, moitié féminine de Kindred) (8 777), Lux (7 671), Soraka (7 538) |
| 9 | Naruto | 6 | 165 841 | 27 640 | Animanga | Hinata Hyûga (44 141), Tsunade (40 786), Sakura Haruno (40 018), Ino Yamanaka (16 449), Sarada Uchiha (13 790), Kushina Uzumaki (10 657) |
| 10 | Sonic | 6 | 133 745 | 22 291 | Furry | Rouge the Bat (45 414), Amy Rose (41 846), Blaze the Cat (15 169), Vanilla (11 235), Cream the Rabbit (10 519), Sally Acorn (9 562) |
| 11 | Dragon Ball | 6 | 93 143 | 15 524 | Animanga 5 / Jeux vidéo 1 | C-18 (30 868), Bulma (22 100), Chichi (14 479), Videl (9 996), C-21 (Android 21) (8 209), Kefla (7 491) |
| 12 | Resident Evil | 5 | 84 364 | 16 873 | Jeux vidéo | Jill Valentine (25 551), Ada Wong (23 269), Claire Redfield (12 505), Lady Dimitrescu (11 846), Ashley Graham (11 193) |
| 13 | One Piece | 4 | 124 925 | 31 231 | Animanga | Nami (58 263), Nico Robin (35 080), Boa Hancock (19 886), Yamato (11 696) |
| 14 | Super Mario | 4 | 104 718 | 26 180 | Jeux vidéo | Princesse Peach (50 552), Harmonie (Rosalina) (24 442), Daisy (20 747), Bowsette (version féminine de Bowser, création de fans, 2018) (8 977) |
| 15 | Bleach | 4 | 71 499 | 17 875 | Animanga | Yoruichi (21 936), Orihime Inoue (19 208), Rangiku Matsumoto (17 804), Rukia Kuchiki (12 551) |
| 16 | Chainsaw Man | 4 | 69 045 | 17 261 | Animanga | Makima (34 383), Power (16 185), Reze (9 293), Kobeni Higashiyama (9 184) |
| 17 | RWBY | 4 | 58 660 | 14 665 | Cartoons | Yang Xiao Long (17 965), Ruby Rose (15 701), Weiss Schnee (14 113), Blake Belladonna (10 881) |
| 18 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 4 | 48 070 | 12 018 | Cartoons | Korra (13 757), Azula (12 587), Katara (12 083), Toph Beifong (9 643) |
| 19 | Fate | 4 | 46 774 | 11 694 | Jeux vidéo | Artoria Pendragon (20 563), Minamoto no Raikou (8 975), Mash Kyrielight (8 624), Rin Tohsaka (8 612) |
| 20 | Zenless Zone Zero | 4 | 38 790 | 9 698 | Jeux vidéo | Jane Doe (10 356), Ellen Joe (9 754), Belle (9 531), Nicole Demara (9 149) |
| 21 | Street Fighter | 3 | 76 872 | 25 624 | Jeux vidéo | Chun-Li (41 013), Cammy (18 735), Juri Han (17 124) |
| 22 | KonoSuba | 3 | 46 821 | 15 607 | Animanga | Aqua (19 839), Megumin (15 208), Darkness (11 774) |
| 23 | The Witcher | 3 | 44 334 | 14 778 | Jeux vidéo | Ciri (20 518), Yennefer (12 861), Triss Merigold (10 955) |
| 24 | Demon Slayer | 3 | 40 978 | 13 659 | Animanga | Mitsuri Kanroji (16 655), Shinobu Kocho (14 569), Nezuko Kamado (9 754) |
| 25 | Doki Doki Literature Club | 3 | 29 896 | 9 965 | Jeux vidéo | Monika (12 511), Natsuki (8 919), Yuri (8 466) |
| 26 | Fire Emblem | 3 | 27 757 | 9 252 | Jeux vidéo | Byleth (version féminine) (10 952), Lucina (8 865), Camilla (7 940) |
| 27 | Mass Effect | 3 | 25 684 | 8 561 | Jeux vidéo | Liara T'Soni (10 343), Commandant Shepard (version féminine) (7 700), Miranda Lawson (7 641) |
| 28 | Final Fantasy VII | 2 | 70 304 | 35 152 | Jeux vidéo | Tifa Lockhart (54 505), Aerith Gainsborough (15 799) |
| 29 | The Legend of Zelda | 2 | 54 877 | 27 438 | Jeux vidéo | Princesse Zelda (39 792), Midna (15 085) |
| 30 | Helluva Boss | 2 | 52 106 | 26 053 | Furry | Loona (43 049), Millie (9 057) |
| 31 | Frieren | 2 | 48 331 | 24 166 | Animanga | Frieren (28 757), Fern (19 574) |
| 32 | One Punch Man | 2 | 38 633 | 19 316 | Animanga | Tatsumaki (24 182), Fubuki (14 451) |
| 33 | Animal Crossing | 2 | 38 555 | 19 278 | Furry | Marie (Isabelle) (20 826), Ankha (17 729) |
| 34 | Fairy Tail | 2 | 35 618 | 17 809 | Animanga | Lucy Heartfilia (18 255), Erza Scarlet (17 363) |
| 35 | Evangelion | 2 | 29 197 | 14 598 | Animanga | Asuka Langley (19 150), Rei Ayanami (10 047) |
| 36 | High School DxD | 2 | 28 374 | 14 187 | Animanga | Rias Gremory (17 248), Akeno Himejima (11 126) |
| 37 | Five Nights at Freddy's | 2 | 26 306 | 13 153 | Furry | Toy Chica (14 905), Roxanne Wolf (11 401) |
| 38 | Xenoblade Chronicles 2 | 2 | 24 861 | 12 430 | Jeux vidéo | Pyra (14 259), Mythra (Homura, autre forme de Pyra) (10 602) |
| 39 | Les Indestructibles | 2 | 23 600 | 11 800 | Cartoons | Helen Parr (Elastigirl) (15 935), Violette Parr (7 665) |
| 40 | Kill la Kill | 2 | 22 916 | 11 458 | Animanga | Ryuko Matoi (13 701), Satsuki Kiryuin (9 215) |
| 41 | Re:Zero | 2 | 21 438 | 10 719 | Animanga | Emilia (11 705), Rem (9 733) |
| 42 | Kim Possible | 2 | 20 295 | 10 148 | Cartoons | Kim Possible (12 439), Shego (7 856) |
| 43 | Persona 5 | 2 | 19 219 | 9 610 | Jeux vidéo | Ann Takamaki (10 521), Makoto Niijima (8 698) |
| 44 | Miss Kobayashi's Dragon Maid | 2 | 18 327 | 9 164 | Animanga | Ilulu (9 655), Lucoa (Quetzalcoatl) (8 672) |
| 45 | Adventure Time | 2 | 18 258 | 9 129 | Cartoons | Princesse Chewing-gum (9 974), Marceline (8 284) |
| 46 | Splatoon | 2 | 18 202 | 9 101 | Jeux vidéo | Marina (10 291), Marie (7 911) |
| 47 | Dead or Alive | 2 | 16 803 | 8 402 | Jeux vidéo | Kasumi (8 751), Marie Rose (8 052) |

*Les 53 franchises à un seul personnage figurent dans le CSV.*

## 2. Par publications cumulées (top 30)

| # | Franchise | Publications cumulées | Part des 243 | Personnages | Rang par nombre |
|---|---|---|---|---|---|
| 1 | Overwatch | 178 118 | 4,5 % | 9 | 4 |
| 2 | My Little Pony | 175 623 | 4,5 % | 8 | 5 |
| 3 | Pokémon | 169 172 | 4,3 % | 13 | 1 |
| 4 | Naruto | 165 841 | 4,2 % | 6 | 9 |
| 5 | DC Comics | 160 500 | 4,1 % | 8 | 6 |
| 6 | Genshin Impact | 158 555 | 4,0 % | 12 | 2 |
| 7 | My Hero Academia | 139 590 | 3,5 % | 7 | 7 |
| 8 | Sonic | 133 745 | 3,4 % | 6 | 10 |
| 9 | One Piece | 124 925 | 3,2 % | 4 | 13 |
| 10 | Marvel | 120 306 | 3,1 % | 10 | 3 |
| 11 | Super Mario | 104 718 | 2,7 % | 4 | 14 |
| 12 | Dragon Ball | 93 143 | 2,4 % | 6 | 11 |
| 13 | League of Legends | 91 051 | 2,3 % | 7 | 8 |
| 14 | Resident Evil | 84 364 | 2,1 % | 5 | 12 |
| 15 | Street Fighter | 76 872 | 2,0 % | 3 | 21 |
| 16 | Bleach | 71 499 | 1,8 % | 4 | 15 |
| 17 | Final Fantasy VII | 70 304 | 1,8 % | 2 | 28 |
| 18 | Chainsaw Man | 69 045 | 1,8 % | 4 | 16 |
| 19 | RWBY | 58 660 | 1,5 % | 4 | 17 |
| 20 | The Legend of Zelda | 54 877 | 1,4 % | 2 | 29 |
| 21 | Helluva Boss | 52 106 | 1,3 % | 2 | 30 |
| 22 | Frieren | 48 331 | 1,2 % | 2 | 31 |
| 23 | Avatar (Le Dernier Maître de l'air + La Légende de Korra) | 48 070 | 1,2 % | 4 | 18 |
| 24 | KonoSuba | 46 821 | 1,2 % | 3 | 22 |
| 25 | Fate | 46 774 | 1,2 % | 4 | 19 |
| 26 | The Witcher | 44 334 | 1,1 % | 3 | 23 |
| 27 | NieR: Automata | 43 048 | 1,1 % | 1 | 48 |
| 28 | Vocaloid | 41 506 | 1,1 % | 1 | 49 |
| 29 | Demon Slayer | 40 978 | 1,0 % | 3 | 24 |
| 30 | Zenless Zone Zero | 38 790 | 1,0 % | 4 | 20 |
